package Config;

import java.io.IOException;
import java.sql.SQLException;

import org.omg.CORBA.ORBPackage.InvalidName;
import org.omg.CosNaming.NamingContextPackage.CannotProceed;
import org.omg.CosNaming.NamingContextPackage.NotFound;
import org.omg.PortableServer.POAManagerPackage.AdapterInactive;
import org.omg.PortableServer.POAPackage.ServantNotActive;
import org.omg.PortableServer.POAPackage.WrongPolicy;

import CamServer.CamCorbaServer;
import LMSServer.LMSPolice;
import LMSServer.RMCServer;
/*
 * Implement a runnable to open required GUI
 * please note that the GUI will open simultaneously ---if you prefer you may open sequentially in the order specified
 * in the README.TXT
 * 
 * 
 */
public class showGUI {

	public static void main(String []args) throws InvalidName, NotFound, CannotProceed, org.omg.CosNaming.NamingContextPackage.InvalidName, ServantNotActive, WrongPolicy, AdapterInactive, IOException, SQLException, InterruptedException
	{
		
		Runnable rRMC=new Runnable() {
			
			@Override
			public void run() {
				try {
					RMCServer.main(args);
				} catch (InvalidName | NotFound | CannotProceed
						| org.omg.CosNaming.NamingContextPackage.InvalidName
						| ServantNotActive | WrongPolicy | AdapterInactive
						| IOException | SQLException e) {
					
					e.printStackTrace();
				}
				
			}
		};

Runnable rLMS=new Runnable() {
			
			@Override
			public void run() {
				try {
					LMSPolice.main(args);
				} catch (InvalidName | AdapterInactive | ServantNotActive
						| WrongPolicy
						| org.omg.CosNaming.NamingContextPackage.InvalidName
						| NotFound | CannotProceed | IOException e) {
				
					e.printStackTrace();
				}
				
			}
		};
Runnable rCCS=new Runnable() {
			
			@Override
			public void run() {
				try {
					CamCorbaServer.main(args);
				} catch (InvalidName | AdapterInactive | ServantNotActive
						| WrongPolicy
						| org.omg.CosNaming.NamingContextPackage.InvalidName
						| NotFound | CannotProceed e) {
			
					e.printStackTrace();
				}
				
			}
		};
		Thread tRMC=new Thread(rRMC);
		tRMC.start();
		Thread tLMS=new Thread(rLMS);
		tLMS.start();
		Thread tCCS = new Thread(rCCS);
		tCCS.start();
		
	}
	
}
