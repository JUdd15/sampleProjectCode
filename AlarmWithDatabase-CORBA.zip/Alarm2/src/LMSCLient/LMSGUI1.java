package LMSCLient;

import java.awt.EventQueue;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import javax.swing.JButton;








import LMSServer.RMCServer;
import Police.Alarm;
import Police.LMS;
import Police.LMSHelper;






import Police.RMC;
import Police.RMCHelper;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.io.IOException;
import java.awt.Color;

import javax.swing.JScrollPane;

import org.omg.CORBA.ORB;
import org.omg.CosNaming.NamingContextExt;
import org.omg.CosNaming.NamingContextExtHelper;
import org.omg.CosNaming.NamingContextPackage.CannotProceed;
import org.omg.CosNaming.NamingContextPackage.InvalidName;
import org.omg.CosNaming.NamingContextPackage.NotFound;

import javax.swing.JComboBox;

public class LMSGUI1 {

	private JFrame frame;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		LMSGUI1.args=args;
		EventQueue.invokeLater(new Runnable() {
			@Override
			public void run() {
				try {
					LMSGUI1 window = new LMSGUI1();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	// get orb and rmc 
	ORB orb;
	RMC rmc;
	public void connectLMS(String namelms) throws NotFound, CannotProceed, InvalidName, org.omg.CORBA.ORBPackage.InvalidName
	{
		 org.omg.CORBA.Object nameServiceObj = orb.resolve_initial_references ("NameService");
         if (nameServiceObj == null) {
              System.out.println("nameServiceObj = null");
              return;
         }
         	
         // Use NamingContextExt instead of NamingContext. This is 
         // part of the Interoperable naming Service.  
         NamingContextExt nameService = NamingContextExtHelper.narrow(nameServiceObj);
         if (nameService == null) {
              System.out.println("nameService = null");
              return;
         }
    
         // resolve the Count object reference in the Naming service
       
          lms = LMSHelper.narrow(nameService.resolve_str(namelms));
	}
	/**
	 * Create the application.
	 */
	public static String[] args;
	public static LMS lms;
	private JTextArea textArea;
	private JComboBox lmsBox;
	private JLabel conSucess;
	private JTextField imageField;
	public LMSGUI1() throws IOException, NotFound, CannotProceed, InvalidName, org.omg.CORBA.ORBPackage.InvalidName {
		super();
		initialize();
		
		 System.out.println("Initializing the ORB");
         orb = ORB.init(args, null);
         
         org.omg.CORBA.Object nameServiceObj = orb.resolve_initial_references ("NameService");
         if (nameServiceObj == null) {
              System.out.println("nameServiceObj = null");
              return;
         }
         	
         // Use NamingContextExt instead of NamingContext. This is 
         // part of the Interoperable naming Service.  
         NamingContextExt nameService = NamingContextExtHelper.narrow(nameServiceObj);
         if (nameService == null) {
              System.out.println("nameService = null");
              return;
         }
    
         // resolve the Count object reference in the Naming service
       
          rmc =RMCHelper.narrow(nameService.resolve_str("serverRMC"));
          JComboBox lmsb=getLmsBox();
          String[] list=rmc.ListLMS();
          
          
         
         // dlm.
          lmsb.setModel(new DefaultComboBoxModel(list));
          
          conSucess = new JLabel("");
          conSucess.setBounds(322, 76, 102, 14);
          frame.getContentPane().add(conSucess);
          
          imageField = new JTextField();
          imageField.setBounds(263, 123, 86, 20);
          frame.getContentPane().add(imageField);
          imageField.setColumns(10);
          
          JLabel lblImage = new JLabel("image");
          lblImage.setBounds(223, 126, 46, 14);
          frame.getContentPane().add(lblImage);
         // Get a reference to the Naming service
        
	
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel TimeField = new JLabel("Time");
		TimeField.setBounds(20, 49, 46, 14);
		frame.getContentPane().add(TimeField);
		
		JLabel DateField = new JLabel("Date");
		DateField.setBounds(20, 76, 46, 14);
		frame.getContentPane().add(DateField);
		
		 JLabel SensorField = new JLabel("Sensor");
		SensorField.setBounds(20, 101, 46, 14);
		frame.getContentPane().add(SensorField);
		
		 JLabel Zonefield = new JLabel("Zone");
		Zonefield.setBounds(20, 126, 46, 14);
		frame.getContentPane().add(Zonefield);
		
		textField = new JTextField();
		textField.setBounds(76, 46, 86, 20);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBounds(76, 73, 86, 20);
		frame.getContentPane().add(textField_1);
		textField_1.setColumns(10);
		
		textField_2 = new JTextField();
		textField_2.setBounds(76, 98, 86, 20);
		frame.getContentPane().add(textField_2);
		textField_2.setColumns(10);
		
		textField_3 = new JTextField();
		textField_3.setBounds(76, 121, 86, 20);
		frame.getContentPane().add(textField_3);
		textField_3.setColumns(10);
		
		JLabel LogField = new JLabel("Log");
		LogField.setBounds(20, 222, 46, 14);
		frame.getContentPane().add(LogField);
		
		
		// submits data to raise alarm in LMS Server
		JButton SubmitButton = new JButton("Submit");
		SubmitButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				int timeInt,dateInt;
				String sensorText,zoneText;
				JTextField TimeField=getTimeField();
				JTextField DateField=getDateField();
				JTextField SensorField=getSensorField();
				JTextField ZoneField=getZoneField();
				//JTextField ImageField=getImageField();
				timeInt=Integer.parseInt(TimeField.getText());
				dateInt=Integer.parseInt(DateField.getText());
				sensorText=SensorField.getText();
				zoneText=ZoneField.getText();
				//imageText=ImageField.getText();
				Alarm [] log = lms.theLog();
				
				
				lms.raise_Alarm(new Alarm(timeInt,dateInt,sensorText,zoneText,""));
				//alerted.setText("Alarm raised");
				
				
				//RMCServer rm = new RMCServer();
				
			}
		});
		SubmitButton.setBounds(73, 170, 89, 23);
		frame.getContentPane().add(SubmitButton);
		
		
		//gets the log from LMS server to update GUI
		JButton GetLog = new JButton("Get Log");
		GetLog.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e)
			{
				JTextArea LogText=getLogArea();
				LogText.setText(" ");
				System.out.println(lms==null);
				Alarm []log = lms.theLog();//get log from LMS server
				System.out.println(log);
				// update log on textarea
				int i;
				for(i=0;i<log.length;i++)
					LogText.setText(LogText.getText()+"\ntime:"+log[i].time+" date:"+log[i].date+" sensor:"+log[i].sensor+" zone:"+log[i].zone +" Image:"+log[i].image+"\n");
			}
		});
		GetLog.setBounds(290, 218, 89, 23);
		
		frame.getContentPane().add(GetLog);
		
		JLabel lblNewLabel = new JLabel("Raise Alarm");
		lblNewLabel.setBounds(177, 11, 96, 20);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel alerted = new JLabel("");
		alerted.setBounds(172, 174, 170, 14);
		frame.getContentPane().add(alerted);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(76, 202, 183, 48);
		frame.getContentPane().add(scrollPane);
		
		textArea = new JTextArea();
		scrollPane.setViewportView(textArea);
		textArea.setBackground(Color.PINK);
		
		lmsBox = new JComboBox();
		lmsBox.setBounds(302, 46, 77, 20);
		frame.getContentPane().add(lmsBox);
		
		JLabel lblLmsService = new JLabel("lms service");
		lblLmsService.setBounds(223, 49, 69, 14);
		frame.getContentPane().add(lblLmsService);
		
		
		// connect to specified LMS 
		JButton btnConnect = new JButton("connect");
		btnConnect.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				try {
					connectLMS(getLmsBox().getSelectedItem().toString());
					// connection success to specified LMS in drop menu
					conSucess.setText("Connected");
					
					
				} catch (NotFound e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (CannotProceed e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (InvalidName e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (org.omg.CORBA.ORBPackage.InvalidName e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
		btnConnect.setBounds(223, 72, 89, 23);
		frame.getContentPane().add(btnConnect);
	}
	public JTextField getTimeField() {
		return textField;
	}
	public JTextField getDateField() {
		return textField_1;
	}
	public JTextField getSensorField() {
		return textField_2;
	}
	public JTextField getZoneField() {
		return textField_3;
	}
	public JTextArea getLogArea() {
		return textArea;
	}
	public JComboBox getLmsBox() {
		return lmsBox;
	}
	public JLabel getConSucess() {
		return conSucess;
	}
	public JTextField getImageField() {
		return imageField;
	}
}
