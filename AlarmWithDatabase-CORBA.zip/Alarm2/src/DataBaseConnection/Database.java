package DataBaseConnection;

import java.lang.Thread.State;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
/*The database connection for the user data to be passed when registering to the SQL database 
 * 
 * 
 */
public class Database {
	// database connection fields
	public final static String URL="jdbc:mysql://localhost";
	public final static String USER="root";
	public final static String PASSWORD="";
	
	//connection init
	public static Connection init() throws SQLException
	{
		Connection con=DriverManager.getConnection(URL, USER,PASSWORD);  // get a drive manager object
	
		
		Statement stmt = con.createStatement();// set a prepared statement
		
		stmt.execute("CREATE DATABASE IF NOT EXISTS CORBA_POLICE");// if database does not exist create it..
		stmt.close();  // closes connection
		stmt=con.createStatement();  // create statement again
		stmt.execute("USE CORBA_POLICE");  // execute above 
		stmt.close();  // close statament
		stmt=con.createStatement();  // submit all the s=data from the RMC users to table
		stmt.execute("CREATE TABLE IF NOT EXISTS PERSON (id int AUTO_INCREMENT,name varchar(20),contact varchar(300),password varchar(64),PRIMARY KEY(id))");
		stmt.close();// close connection
		return con;
	}
}


