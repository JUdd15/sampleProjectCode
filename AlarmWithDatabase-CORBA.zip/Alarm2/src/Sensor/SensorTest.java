package Sensor;

import junit.framework.Assert;

import org.junit.Test;
import org.omg.CORBA.ORB;
import org.omg.CORBA.ORBPackage.InvalidName;
import org.omg.PortableServer.POA;
import org.omg.PortableServer.POAHelper;
import org.omg.PortableServer.POAManagerPackage.AdapterInactive;
import org.omg.PortableServer.POAPackage.ServantNotActive;
import org.omg.PortableServer.POAPackage.WrongPolicy;

import CamServer.CamCorbaServer;
import Police.CamCorba;
import Police.CamCorbaHelper;


/*/ testing the reference to the object if they are stord in memory by reference then we can 
 * create new object and reference them check if they do call the  server by the client
 * this reduces the need to import the framework into the test suite and just assumes that the cached references will
 * still work with additional data.
 * This is all theoretical based on the materials that have been read it is assumed that there must be residual
 * data references in memory.
 * 
 * 
 */
public class SensorTest {

	@Test
	public void test() throws InvalidName, AdapterInactive, ServantNotActive, WrongPolicy {
		
		
		String []arg={"ORBInitialPort","1050"};  // access name service registry
		ORB orb=ORB.init(arg,null);
		 POA rootpoa = POAHelper.narrow(orb.resolve_initial_references("RootPOA"));
	        rootpoa.the_POAManager().activate();
	        
	        
	        
	        String name="nameEx";
		// Create the Count servant object
	       CamCorbaServer ccs = new CamCorbaServer(name);  // create mock object
	 
	       org.omg.CORBA.Object ref = rootpoa.servant_to_reference(ccs);
	       CamCorba cref = CamCorbaHelper.narrow(ref);
	       Assert.assertEquals(name, cref.name());  // checks if we get name
	       
	       System.out.println(cref.name());  // confirmation if we do get name
	}
	

}
