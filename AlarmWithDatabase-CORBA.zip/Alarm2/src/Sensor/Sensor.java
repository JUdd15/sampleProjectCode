package Sensor;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

import org.omg.CORBA.ORB;
import org.omg.CORBA.ORBPackage.InvalidName;
import org.omg.CosNaming.NamingContextExt;
import org.omg.CosNaming.NamingContextExtHelper;
import org.omg.CosNaming.NamingContextPackage.CannotProceed;
import org.omg.CosNaming.NamingContextPackage.NotFound;
import Police.Alarm;
import Police.CamCorba;
import Police.CamCorbaHelper;
import Police.WarningLevel;

import javax.swing.JCheckBox;
import javax.swing.JTextField;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.util.Date;




/**
* This code was edited or generated using CloudGarden's Jigloo
* SWT/Swing GUI Builder, which is free for non-commercial
* use. If Jigloo is being used commercially (ie, by a corporation,
* company or business for any purpose whatever) then you
* should purchase a license for each developer using Jigloo.
* Please visit www.cloudgarden.com for details.
* Use of Jigloo implies acceptance of these licensing terms.
* A COMMERCIAL LICENSE HAS NOT BEEN PURCHASED FOR
* THIS MACHINE, SO JIGLOO OR THIS CODE CANNOT BE USED
* LEGALLY FOR ANY CORPORATE OR COMMERCIAL PURPOSE.
*/


// Sensor class sensor is at default off when active until checkbox is activated
public class Sensor extends javax.swing.JFrame {
	static CamCorba cc;
	private JTextField sensorField;
	private JTextField zoneField;
	private JCheckBox turnedOn;
	private JTextField textField;
	/**
	* Auto-generated main method to display this JFrame
	 * @throws InvalidName 
	 * @throws org.omg.CosNaming.NamingContextPackage.InvalidName 
	 * @throws CannotProceed 
	 * @throws NotFound 
	*/
	public static void main(String[] args) throws InvalidName, NotFound, CannotProceed, org.omg.CosNaming.NamingContextPackage.InvalidName {
		
		
		ORB orb = ORB.init(args, null);
	    org.omg.CORBA.Object objRef =   orb.resolve_initial_references("NameService");
	    NamingContextExt ncRef = NamingContextExtHelper.narrow(objRef);
	    cc= CamCorbaHelper.narrow(ncRef.resolve_str(JOptionPane.showInputDialog("Enter the cam corba server name")));
 
	    
		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				Sensor inst = new Sensor();
				inst.setLocationRelativeTo(null);
				inst.setVisible(true);
				
			}
		});
	}
	// 
	public Sensor() {
		super();
		getContentPane().setLayout(null);
		
		turnedOn = new JCheckBox("Sensor ON");
		turnedOn.setBounds(248, 46, 97, 23);
		getContentPane().add(turnedOn);
		
		JButton btnNewButton = new JButton("Alarm");
		btnNewButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				
				JOptionPane.showMessageDialog(null,"Please confirm if alarm is REAL!", "", JOptionPane.INFORMATION_MESSAGE);

			}
		});
		btnNewButton.setBounds(22, 203, 89, 23);
		getContentPane().add(btnNewButton);
		
		sensorField = new JTextField();
		sensorField.setBounds(114, 47, 86, 20);
		getContentPane().add(sensorField);
		sensorField.setColumns(10);
		
		JButton btnCon = new JButton("Confirm");
		btnCon.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				String sensor=getSensorField().getText();
				String zone=getZoneField().getText();
				String img = getImageField().getText();
				Date d=new Date();
				
				boolean ton=getTurnedOn().isSelected();
				if(ton)
				{
					@SuppressWarnings("deprecation")
					Alarm alm=new Alarm(d.getHours()*60+d.getMinutes(),d.getDate(),sensor, zone,getImageField().getText());
					img=d.toGMTString();
					WarningLevel wl=new WarningLevel(3, "a message",getImageField().getText());
					cc.receieveAlarm(alm,wl);
				}
				else
				{
					JOptionPane.showMessageDialog(null, "switch on the alarm",null,JOptionPane.ERROR_MESSAGE);
				}
				//start a thread that anounce presense to camcorba
				
			}
		});
		btnCon.setBounds(121, 203, 89, 23);
		getContentPane().add(btnCon);
		
		JLabel lblAlarm = new JLabel("Alarm");
		lblAlarm.setBounds(146, 0, 89, 36);
		getContentPane().add(lblAlarm);
		
		JLabel lblSensor = new JLabel("Sensor");
		lblSensor.setBounds(22, 50, 46, 14);
		getContentPane().add(lblSensor);
		
		JLabel lblNewZonelabel = new JLabel("Zone");
		lblNewZonelabel.setBounds(22, 85, 46, 14);
		getContentPane().add(lblNewZonelabel);
		
		zoneField = new JTextField();
		zoneField.setBounds(114, 82, 86, 20);
		getContentPane().add(zoneField);
		zoneField.setColumns(10);
		
		textField = new JTextField();
		textField.setBounds(114, 115, 86, 20);
		getContentPane().add(textField);
		textField.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("Image");
		lblNewLabel.setBounds(22, 118, 46, 14);
		getContentPane().add(lblNewLabel);
		initGUI();
	}
	
	private void initGUI() {
		try {
		} catch (Exception e) {
		    //add your error handling code here
			e.printStackTrace();
		}
	}
	public JTextField getSensorField() {
		return sensorField;
	}
	public JTextField getZoneField() {
		return zoneField;
	}
	public JCheckBox getTurnedOn() {
		return turnedOn;
	}

	public JTextField getImageField() {
		return textField;
	}
}
