package CamServer;

import java.util.ArrayList;
import javax.swing.JOptionPane;

import org.omg.CORBA.ORB;
import org.omg.CORBA.ORBPackage.InvalidName;
import org.omg.CosNaming.NameComponent;
import org.omg.CosNaming.NamingContextExt;
import org.omg.CosNaming.NamingContextExtHelper;
import org.omg.CosNaming.NamingContextPackage.CannotProceed;
import org.omg.CosNaming.NamingContextPackage.NotFound;
import org.omg.PortableServer.POA;
import org.omg.PortableServer.POAHelper;
import org.omg.PortableServer.POAManagerPackage.AdapterInactive;
import org.omg.PortableServer.POAPackage.ServantNotActive;
import org.omg.PortableServer.POAPackage.WrongPolicy;

import Police.Alarm;
import Police.CamCorba;
import Police.CamCorbaHelper;
import Police.CamCorbaPOA;
import Police.Image;
import Police.LMSHelper;
import Police.WarningLevel;

public class CamCorbaServer extends CamCorbaPOA{

	// camcorba server fields
	protected String name;
	ArrayList<Image> limg=new ArrayList<Image>();
	private WarningLevel wl;
	public static Police.LMS lms;
	private static String []zone;
	
	
	public CamCorbaServer(String name)
	{
		this.name=name;
		
		
	}
	@Override
	public String name() {
		// define name of cam
		return name;
	}

	@Override
	public WarningLevel current() {
	//get current warning level
		return wl;
	}

	@Override
	public void current(WarningLevel newCurrent) {
		// get new current warning level
		wl=newCurrent;
		
	}

	@Override
	public Image CurrentImage() {
	
		return limg.get(limg.size()-1); // get last image.
	}
	public static void main(String []args) throws InvalidName, AdapterInactive, ServantNotActive, WrongPolicy, org.omg.CosNaming.NamingContextPackage.InvalidName, NotFound, CannotProceed
	{
		ORB orb=ORB.init(args,null);
		 POA rootpoa = POAHelper.narrow(orb.resolve_initial_references("RootPOA"));
	        rootpoa.the_POAManager().activate();
	        String name = JOptionPane.showInputDialog("Write the name of CameraCorba Server");
	        
	        
	        // Create the Count servant object
	       CamCorbaServer ccs = new CamCorbaServer(name);
	       String z=JOptionPane.showInputDialog("Enter Zones(comma separated)");  // comma separate to take more data rather than one
	        zone=z.split(",");
	       org.omg.CORBA.Object ref = rootpoa.servant_to_reference(ccs);
	       CamCorba cref = CamCorbaHelper.narrow(ref);
	       org.omg.CORBA.Object nameServiceObj = orb.resolve_initial_references ("NameService");
	        if (nameServiceObj == null) {
	             System.out.println("nameServiceObj = null");
	             return;
	        }

	        // Use NamingContextExt which is part of the Interoperable
	        // Naming Service (INS) specification.
	        NamingContextExt nameService = NamingContextExtHelper.narrow(nameServiceObj);
	        if (nameService == null) {
	             System.out.println("nameService = null");
	             return;
	        }
	      
	        //isolates the LMS to reference
	        NameComponent[] countName = nameService.to_name(name);
	        nameService.rebind(countName, cref);  //bind to cref
	        String namelms=JOptionPane.showInputDialog("Specify the LMS");
	       lms =LMSHelper.narrow(nameService.resolve_str(namelms)); // isolate the name
	       lms.add_Camera(cref, zone);  // add camera to zone
	     
		     orb.run();
	}
	@Override
	public void receieveAlarm(Alarm alm, WarningLevel wl) {
		current(wl);
		if(wl.level>2)   // 2 is an arbitrary figure of minimum level of threat
		{	
			
			lms.raise_Alarm(alm); //data passed to alarm
		}
		
		
	}

}
