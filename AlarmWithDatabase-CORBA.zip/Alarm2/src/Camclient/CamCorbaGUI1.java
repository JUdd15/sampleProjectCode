
package Camclient;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import javax.swing.JButton;

import org.omg.CORBA.ORB;
import org.omg.CORBA.ORBPackage.InvalidName;
import org.omg.CosNaming.NamingContextExt;
import org.omg.CosNaming.NamingContextExtHelper;
import org.omg.CosNaming.NamingContextPackage.CannotProceed;
import org.omg.CosNaming.NamingContextPackage.NotFound;

import Police.CamCorba;
import Police.CamCorbaHelper;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import java.io.IOException;
import java.security.Policy;

public class CamCorbaGUI1 {
static ORB orb;
	private JFrame frame;
	private JTextField textField;
	private JTextField LevelField;
	private JTextArea MessageField;
	private JTextField Imagefield;
	/**
	 * Launch the application.
	 */
	static CamCorba cam;
	private JLabel warnlabel;
	private JButton btnReset;
	
	public static void main(String[] args) throws IOException {
		   orb = ORB.init(args, null);

		EventQueue.invokeLater(new Runnable() {
			@Override
			public void run() {
				try {
					CamCorbaGUI1 window = new CamCorbaGUI1();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public CamCorbaGUI1() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		
		// Gui fields
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("CamCorba");
		lblNewLabel.setBounds(148, 11, 83, 14);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel NameCam = new JLabel("CamName");
		NameCam.setBounds(10, 59, 83, 14);
		frame.getContentPane().add(NameCam);
		
		JLabel WarningLevel = new JLabel("Warning Level");
		WarningLevel.setBounds(10, 92, 78, 14);
		frame.getContentPane().add(WarningLevel);
		
		JLabel Message = new JLabel("Message");
		Message.setBounds(10, 131, 46, 14);
		frame.getContentPane().add(Message);
		
		textField = new JTextField();
		textField.setBounds(82, 56, 86, 20);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		LevelField = new JTextField();
		LevelField.setBounds(82, 89, 86, 20);
		frame.getContentPane().add(LevelField);
		LevelField.setColumns(10);
		
		MessageField = new JTextArea();
		MessageField.setBackground(Color.LIGHT_GRAY);
		MessageField.setBounds(82, 126, 86, 28);
		frame.getContentPane().add(MessageField);
		
		
		//Send data as warning level to camcorba 
		JButton SendData = new JButton("Send Data");
		SendData.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				
				int wl=Integer.parseInt(getLevelField().getText());
				String mes=getMessageField().getText();
				String img = getImageField().getText();
				 Police.WarningLevel wll= new Police.WarningLevel (wl, mes,img);
				 cam.current(wll);// pass all field data including image to camcorba
			
				
			}
		});
		SendData.setBounds(82, 214, 89, 23);
		frame.getContentPane().add(SendData);
		
		JButton btnNewButton = new JButton("Connect to CamcCorba");
		btnNewButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				String camname=getNameField().getText();
				System.out.println("Initializing the ORB");
		      
		   
		        // Get a reference to the Naming service
		        org.omg.CORBA.Object nameServiceObj = null;
				try {
					nameServiceObj = orb.resolve_initial_references ("NameService");
				} catch (InvalidName e) {
					
					e.printStackTrace();
				}
		        if (nameServiceObj == null) {
		             System.out.println("nameServiceObj = null");
		             return;
		        }

		        // Use NamingContextExt instead of NamingContext. This is 
		        // part of the Interoperable naming Service.  
		        NamingContextExt nameService = NamingContextExtHelper.narrow(nameServiceObj);
		        if (nameService == null) {
		             System.out.println("nameService = null");
		             return;
		        }
		   
		        // resolve the Count object reference in the Naming service
		        
		        try {
					cam=CamCorbaHelper.narrow(nameService.resolve_str(camname));
				} catch (NotFound | CannotProceed
						| org.omg.CosNaming.NamingContextPackage.InvalidName e) {
					
					e.printStackTrace();
				}
				
				 
			
			
			}	  
			
		});
		btnNewButton.setBounds(217, 55, 195, 23);
		frame.getContentPane().add(btnNewButton);
		
		warnlabel = new JLabel("");
		warnlabel.setBounds(227, 92, 154, 14);
		frame.getContentPane().add(warnlabel);
		
		Imagefield = new JTextField();
		Imagefield.setBounds(82, 165, 86, 20);
		frame.getContentPane().add(Imagefield);
		Imagefield.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("Image");
		lblNewLabel_1.setBounds(10, 168, 46, 14);
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel lblThreat = new JLabel("5 = Severe Threat");
		lblThreat.setBounds(243, 117, 104, 14);
		frame.getContentPane().add(lblThreat);
		
		JLabel lblNewLabel_2 = new JLabel("4 = Medium Threat");
		lblNewLabel_2.setBounds(243, 142, 138, 14);
		frame.getContentPane().add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("3= Minimal Threat");
		lblNewLabel_3.setBounds(243, 168, 169, 14);
		frame.getContentPane().add(lblNewLabel_3);
		
		JLabel lblWarninglevels = new JLabel("WarningLevels");
		lblWarninglevels.setBounds(239, 92, 118, 14);
		frame.getContentPane().add(lblWarninglevels);
		
		JLabel lblEnterDataAnd = new JLabel("Enter Data and press connect before pressing send");
		lblEnterDataAnd.setBounds(86, 31, 326, 14);
		frame.getContentPane().add(lblEnterDataAnd);
		
		btnReset = new JButton("Reset");
		btnReset.setBounds(191, 214, 89, 23);
		frame.getContentPane().add(btnReset);
		
		btnReset.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				if(e.getSource()==null){
					
					
					Imagefield.setText("");
					
					LevelField.setText("");
					
					MessageField.setText("");
					
					
				}
			}
				
	
		});
			
		
		

	public JTextField getNameField() {
		return textField;
	}
	public JTextField getLevelField() {
		return LevelField;
	}
	public JTextArea getMessageField() {
		return MessageField;
	}
	
	public JLabel getWarnlabel() {
		return warnlabel;
	}
	public JTextField getImageField() {
		return Imagefield;
	}
	public JButton getBtnReset() {
		return btnReset;
	}
}
