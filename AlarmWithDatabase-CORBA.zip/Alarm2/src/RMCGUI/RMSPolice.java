package RMCGUI;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JTextArea;
import javax.swing.JLabel;
import javax.swing.JScrollPane;

import org.omg.CORBA.ORB;
import org.omg.CORBA.ORBPackage.InvalidName;
import org.omg.CosNaming.NamingContextExt;
import org.omg.CosNaming.NamingContextExtHelper;
import org.omg.CosNaming.NamingContextPackage.CannotProceed;
import org.omg.CosNaming.NamingContextPackage.NotFound;

import Police.RMC;
import Police.RMCHelper;

import java.awt.Font;
/*RMS update class to regional /local police
 * 
 * 
 */
public class RMSPolice {

	private JFrame frame;
	public static RMC rmc;
	private JTextArea alarmArea;
	/**
	 * Launch the application.
	 * @throws InvalidName 
	 * @throws org.omg.CosNaming.NamingContextPackage.InvalidName 
	 * @throws CannotProceed 
	 * @throws NotFound 
	 */
	public static void main(String[] args) throws InvalidName, NotFound, CannotProceed, org.omg.CosNaming.NamingContextPackage.InvalidName {
		System.out.println("Initializing the ORB");
        ORB orb = ORB.init(args, null);
   
        // Get a reference to the Naming service
        org.omg.CORBA.Object nameServiceObj = orb.resolve_initial_references ("NameService");
        if (nameServiceObj == null) {
             System.out.println("nameServiceObj = null");
             return;
        }

        // Use NamingContextExt instead of NamingContext. This is 
        // part of the Interoperable naming Service.  
        NamingContextExt nameService = NamingContextExtHelper.narrow(nameServiceObj);
        if (nameService == null) {
             System.out.println("nameService = null");
             return;
        }
   
        // resolve the Count object reference in the Naming service
        String name = "serverRMC";
       RMSPolice.rmc = RMCHelper.narrow(nameService.resolve_str(name));
		EventQueue.invokeLater(new Runnable() {
			@Override
			public void run() {
				try {
					RMSPolice window = new RMSPolice();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Updates the GUI from the Operator class 
	 */
	public RMSPolice() {
	    
		initialize();
		// operator calls called -- area specified to update and stored in new object this object is now started in the thread for auto updates
		OperatorAlert updater=new OperatorAlert(this.getAlarmArea());
		updater.start();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(45, 72, 141, 123);
		frame.getContentPane().add(scrollPane);
		
		alarmArea = new JTextArea();
		scrollPane.setViewportView(alarmArea);
		
		JLabel lblRegionalPolice = new JLabel("Regional Police ");
		lblRegionalPolice.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblRegionalPolice.setBounds(26, 25, 132, 23);
		frame.getContentPane().add(lblRegionalPolice);
	
			}

		
	
	public JTextArea getAlarmArea() {
		return alarmArea;
	}
	
}
