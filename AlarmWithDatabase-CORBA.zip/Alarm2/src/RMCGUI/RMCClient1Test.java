package RMCGUI;

import junit.framework.Assert;

import org.junit.Test;
import org.omg.CORBA.ORB;
import org.omg.CORBA.ORBPackage.InvalidName;
import org.omg.PortableServer.POA;
import org.omg.PortableServer.POAHelper;
import org.omg.PortableServer.POAManagerPackage.AdapterInactive;
import org.omg.PortableServer.POAPackage.ServantNotActive;
import org.omg.PortableServer.POAPackage.WrongPolicy;

import CamServer.CamCorbaServer;
import LMSServer.LMSPolice;
import LMSServer.RMCServer;
import Police.Alarm;
import Police.AlarmData;
import Police.CamCorba;
import Police.CamCorbaHelper;
import Police.LMS;
import Police.LMSHelper;
import Police.RMC;
import Police.RMCHelper;


/*/ testing the reference to the object if they are stored in memory by reference then we can 
 * create new object and reference them check if they do call the  server by the client
 * this reduces the need to import the framework into the test suite and just assumes that the cached references will
 * still work with additional data.
 * This is all theoretical based on the materials that have been read it is assumed that there must be residual
 * data references in memory.
 * 
 * 
 */
public class RMCClient1Test {

	@Test
	public void test() throws ServantNotActive, WrongPolicy, InvalidName,
			AdapterInactive {
		String[] args = { "ORBInitialPort", "1050" };  // access name service register
		ORB orb = ORB.init(args, null);

		// get reference to rootpoa & activate the POAManager
		POA rootpoa = POAHelper.narrow(orb
				.resolve_initial_references("RootPOA"));
		rootpoa.the_POAManager().activate();

		RMCServer rmcser = new RMCServer();  // create the mock object to test

		LMSPolice lmsser = new LMSPolice();// create the mock object to test

		// get object reference from the servant
		org.omg.CORBA.Object refrmc = rootpoa.servant_to_reference(rmcser);
		RMC crefrmc = RMCHelper.narrow(refrmc);
		LMSPolice.rmc = crefrmc;
		// crefrmc.RegisterLMS("LONDON");
		org.omg.CORBA.Object reflms = rootpoa.servant_to_reference(lmsser);
		LMS creflms = LMSHelper.narrow(reflms);

		CamCorbaServer ccs = new CamCorbaServer("camone");
		org.omg.CORBA.Object refccs = rootpoa.servant_to_reference(ccs);

		CamCorba crefcam = CamCorbaHelper.narrow(refccs);
		String[] zones = { "leeds", "hudd" };
		creflms.add_Camera(crefcam, zones);
		Alarm alm = new Alarm(0, 0, "sensor", "leeds", "image");
		creflms.raise_Alarm(alm);
		AlarmData[] ad = crefrmc.getLogReq();
		Assert.assertEquals("camone", ad[0].aConfirmingCamera);  // assertion on data by index do we get "camone" when called
		
		
		System.out.println(ad[0].aConfirmingCamera); // sysout confirms if we get camone
	}

}
