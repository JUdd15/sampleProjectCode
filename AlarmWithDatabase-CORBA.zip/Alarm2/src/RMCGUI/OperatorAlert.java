package RMCGUI;

import javax.swing.JTextArea;

import Police.AlarmData;
/*
 * 
 * Operates the thread for the update regional/local police updates 
 */
public class OperatorAlert extends Thread {
	// fields of operation
	JTextArea AlertArea;
	String  [] args;
	int llp=0;  // arbitrary variable set to zero..
	
	//specify the area to update
	public OperatorAlert(JTextArea AlertArea)
	{
		this.AlertArea=AlertArea;  //use this to isolate that specific area
		
		
	}
	// Run method and while loop
	@Override
	public void run()
	{
		String output=new String();
		int i;
		// while true it will loop through and get logreq and update that above area specifed
		while(true)
		{
			
			try {
				AlarmData[] UpdateLog=RMSPolice.rmc.getLogReq();
				
				if(UpdateLog.length!=llp)  // checks if equal to zero make sure there is data in the log
				{
					
					output="";  // empty variable
					for(i=0;i<UpdateLog.length;i++)
					{
						output+="confirm camera:"+UpdateLog[i].aConfirmingCamera+" date:"+UpdateLog[i].aReading.date+" time:"+UpdateLog[i].aReading.time+" sensor:"+UpdateLog[i].aReading.sensor+" zone:"+UpdateLog[i].aReading.zone+"\n";
					}
					AlertArea.setText(output); // filling empty variable with parameter data
					llp=UpdateLog.length;  // llp updated with updatelog
				}
				Thread.sleep(3000);
			} catch (InterruptedException e) {
				
				e.printStackTrace();
			}
		}
	
	}
}
