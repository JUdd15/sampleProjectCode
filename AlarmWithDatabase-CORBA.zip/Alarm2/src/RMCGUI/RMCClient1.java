package RMCGUI;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.io.IOException;
import javax.swing.JTextArea;

import Police.Alarm;
import Police.AlarmData;
import Police.RMC;
import Police.RMCHelper;
import java.awt.Color;

import org.omg.CORBA.ORB;
import org.omg.CORBA.ORBPackage.InvalidName;
import org.omg.CosNaming.NamingContextExt;
import org.omg.CosNaming.NamingContextExtHelper;
import org.omg.CosNaming.NamingContextPackage.CannotProceed;
import org.omg.CosNaming.NamingContextPackage.NotFound;

import javax.swing.JScrollPane;

import java.awt.Font;

import javax.swing.JPasswordField;
/*Regional monitoring class
 * 
 * 
 */
public class RMCClient1 {
	// rmc fields for GUI
	private JFrame frame;
	private JTextField ConCamField;
	private JTextField dateField;
	private JTextField timeField;
	private JTextField sensorField;
	private JTextField zoneField;
	private JTextField NameUsr;
	
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			@Override
			public void run() {
				try {
					RMCClient1 window = new RMCClient1(args);
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
    static RMC rmc;
	private JTextArea LogArea;
	private JButton SubmitAlarm;
	private JTextArea Contact;
	private JPasswordField passwordField;
	private JLabel usrAdded;
	private JTextField textField;
	
	// Naming service
	public RMCClient1(String[] args) throws IOException, InvalidName, NotFound, CannotProceed, org.omg.CosNaming.NamingContextPackage.InvalidName {
		
		super();
		System.out.println("Initializing the ORB");
        ORB orb = ORB.init(args, null);
   
        // Get a reference to the Naming service
        org.omg.CORBA.Object nameServiceObj = orb.resolve_initial_references ("NameService");
        if (nameServiceObj == null) {
             System.out.println("nameServiceObj = null");
             return;
        }

        // Use NamingContextExt instead of NamingContext. This is 
        // part of the Interoperable naming Service.  
        NamingContextExt nameService = NamingContextExtHelper.narrow(nameServiceObj);
        if (nameService == null) {
             System.out.println("nameService = null");
             return;
        }
   
        // resolve the Count object reference in the Naming service
        String name = "serverRMC";
        RMCClient1.rmc = RMCHelper.narrow(nameService.resolve_str(name));
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 751, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel ConCam = new JLabel("Confirming Camera");
		ConCam.setBounds(10, 59, 103, 14);
		frame.getContentPane().add(ConCam);
		
		JLabel DateField = new JLabel("Date");
		DateField.setBounds(10, 86, 46, 14);
		frame.getContentPane().add(DateField);
		
		JLabel TimeField = new JLabel("Time");
		TimeField.setBounds(10, 111, 46, 14);
		frame.getContentPane().add(TimeField);
		
		JLabel SensorField = new JLabel("Sensor");
		SensorField.setBounds(10, 144, 46, 14);
		frame.getContentPane().add(SensorField);
		
		JLabel ZoneField = new JLabel("Zone");
		ZoneField.setBounds(10, 175, 46, 14);
		frame.getContentPane().add(ZoneField);
		
		ConCamField = new JTextField();
		ConCamField.setBounds(109, 56, 86, 20);
		frame.getContentPane().add(ConCamField);
		ConCamField.setColumns(10);
		
		dateField = new JTextField();
		dateField.setBounds(109, 84, 86, 20);
		frame.getContentPane().add(dateField);
		dateField.setColumns(10);
		
		timeField = new JTextField();
		timeField.setBounds(109, 109, 86, 20);
		frame.getContentPane().add(timeField);
		timeField.setColumns(10);
		
		sensorField = new JTextField();
		sensorField.setBounds(109, 141, 86, 20);
		frame.getContentPane().add(sensorField);
		sensorField.setColumns(10);
		
		zoneField = new JTextField();
		zoneField.setBounds(109, 172, 86, 20);
		frame.getContentPane().add(zoneField);
		zoneField.setColumns(10);
		
		//submit date to raise alarm in RMC server stored in list
		SubmitAlarm = new JButton("Submit");
		SubmitAlarm.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				JTextField cc=getConCamField(); // get data from fields
				JTextField df=getDateField();
				JTextField tf=getTimeField();
				JTextField sf=getSensorField();
				JTextField zf=getZoneField();
				JTextField im = getImageField();
				Alarm a=new Alarm(Integer.parseInt(tf.getText()),Integer.parseInt(df.getText()),sf.getText(),zf.getText(), im.getText());
				AlarmData ad=new AlarmData(a,cc.getText());
				RMCClient1.rmc.raiseAlarm(ad);  //send to RMC server list raiseAlarm
			
			}
		});
		SubmitAlarm.setBounds(109, 227, 89, 23);
		frame.getContentPane().add(SubmitAlarm);
		
		JLabel lblNewLabel = new JLabel("Raise Alarm Regional Police");
		lblNewLabel.setBounds(28, 11, 185, 14);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblRegisterUser = new JLabel("Register User");
		lblRegisterUser.setBounds(276, 11, 89, 14);
		frame.getContentPane().add(lblRegisterUser);
		
		JLabel UserNameField = new JLabel("Name");
		UserNameField.setBounds(237, 59, 46, 14);
		frame.getContentPane().add(UserNameField);
		
		NameUsr = new JTextField();
		NameUsr.setBounds(293, 56, 86, 20);
		frame.getContentPane().add(NameUsr);
		NameUsr.setColumns(10);
		
		JLabel ContactDetails = new JLabel("Contact Details");
		ContactDetails.setBounds(237, 117, 86, 14);
		frame.getContentPane().add(ContactDetails);
		
		Contact = new JTextArea();
		Contact.setBackground(new Color(220, 220, 220));
		Contact.setBounds(235, 137, 144, 50);
		frame.getContentPane().add(Contact);
		
		
		// register user then stored in RMC server via registeruser method
		JButton ReguisterUser = new JButton("Register");
		ReguisterUser.addActionListener(new ActionListener() {
			@Override
			@SuppressWarnings("deprecation")
			public void actionPerformed(ActionEvent e) {
				JTextField name=getNameUsr();
				JTextArea con=getContact();
				JPasswordField pass=getPasswordField();
				RMCClient1.rmc.registerUser(name.getText(), con.getText(),pass.getText());
			
				usrAdded.setText("User Added");  // returns user added as update when a user is added to system
			
				
			}
		});
		ReguisterUser.setBounds(290, 214, 89, 23);
		frame.getContentPane().add(ReguisterUser);
		
		JLabel lblLog = new JLabel("Log");
		lblLog.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblLog.setBounds(453, 70, 80, 18);
		frame.getContentPane().add(lblLog);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(453, 144, 163, 81);
		frame.getContentPane().add(scrollPane);
		
		LogArea = new JTextArea();
		scrollPane.setViewportView(LogArea);
		LogArea.setBackground(new Color(216, 191, 216));
		  
		// the getlog from the RMC server call
		JButton btnNewButton = new JButton("get Log");
		btnNewButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				AlarmData[] log=RMCClient1.rmc.getLogReq();
				// call made to AlarmData in RMC server
				int i;
				String logString="";  // empty variable 
				for(i=0;i<log.length;i++) // iteration for log
				{
					//increment that above empty variable with parameter data
					
					logString+="confirming camera:"+log[i].aConfirmingCamera+" time:"+log[i].aReading.time+" date:"+log[i].aReading.date+" zone:"+log[i].aReading.zone+" sensor : "+log[i].aReading.sensor+"\n";
					
					//getLogArea().setText(getLogArea().getText()+"\ntime:"+log[i].aReading.time+" date:"+log[i].aReading.date+" sensor:"+log[i].aReading.sensor+" zone:"+log[i].aReading.zone+ "\n");
				}
				getLogArea().setText(logString);  // update to text area with log data
			}
		});
		btnNewButton.setBounds(453, 107, 89, 23);
		frame.getContentPane().add(btnNewButton);
		
		JLabel lblPassword = new JLabel("password");
		lblPassword.setBounds(237, 86, 46, 14);
		frame.getContentPane().add(lblPassword);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(293, 83, 86, 20);
		frame.getContentPane().add(passwordField);
		
		usrAdded = new JLabel("");
		usrAdded.setBounds(217, 218, 66, 14);
		frame.getContentPane().add(usrAdded);
		
		textField = new JTextField();
		textField.setBounds(109, 196, 86, 20);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		JLabel lblImage = new JLabel("image");
		lblImage.setBounds(10, 199, 46, 14);
		frame.getContentPane().add(lblImage);
		
		
		
	}
	
	
	public JTextArea getLogArea() {
		return LogArea;
	}

	
	public JTextField getConCamField() {
		return ConCamField;
	}
	public JTextField getDateField() {
		return dateField;
	}
	public JTextField getTimeField() {
		return timeField;
	}
	public JTextField getSensorField() {
		return sensorField;
	}
	public JTextField getZoneField() {
		return zoneField;
	}
	public JButton getSubmitAlarm() {
		return SubmitAlarm;
	}
	public JTextField getNameUsr() {
		return NameUsr;
	}
	public JTextArea getContact() {
		return Contact;
	}
	public JPasswordField getPasswordField() {
		return passwordField;
	}
	public JLabel getUsrAdded() {
		return usrAdded;
	}
	public JTextField getImageField() {
		return textField;
	}
}
