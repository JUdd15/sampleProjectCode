package LMSServer;



import java.io.IOException;
import java.util.ArrayList;

import javax.swing.JOptionPane;

import org.omg.CORBA.ORB;
import org.omg.CORBA.ORBPackage.InvalidName;
import org.omg.CosNaming.NameComponent;
import org.omg.CosNaming.NamingContextExt;
import org.omg.CosNaming.NamingContextExtHelper;
import org.omg.CosNaming.NamingContextPackage.CannotProceed;
import org.omg.CosNaming.NamingContextPackage.NotFound;
import org.omg.PortableServer.POA;
import org.omg.PortableServer.POAHelper;
import org.omg.PortableServer.POAManagerPackage.AdapterInactive;
import org.omg.PortableServer.POAPackage.ServantNotActive;
import org.omg.PortableServer.POAPackage.WrongPolicy;











import Police.Alarm;
import Police.AlarmData;
import Police.CamCorba;
import Police.LMS;
import Police.LMSHelper;
import Police.LMSPOA;
import Police.RMC;
import Police.RMCHelper;
import Police.camPlace;


public class LMSPolice extends LMSPOA {

	/**
	 * @param args
	 * @throws CannotProceed 
	 * @throws NotFound 
	 * @throws org.omg.CosNaming.NamingContextPackage.InvalidName 
	 * @throws WrongPolicy 
	 * @throws ServantNotActive 
	 * @throws AdapterInactive 
	 * @throws InvalidName 
	 * @throws InvalidName 
	 * @throws AdapterInactive 
	 * @throws WrongPolicy 
	 * @throws ServantNotActive 
	 * @throws org.omg.CosNaming.NamingContextPackage.InvalidName 
	 * @throws CannotProceed 
	 * @throws NotFound 
	 */
	Alarm []Alist = new Alarm[1000];  // list to hold number of alarms set to arbitrary value of 1000
	int Ai=0; 
	
	public static RMC rmc;
	// arraylist for camera locations
	public  ArrayList<camPlace> camPlaces=new ArrayList<camPlace>();
	
	public static void main(String []args) throws InvalidName, AdapterInactive, ServantNotActive, WrongPolicy, org.omg.CosNaming.NamingContextPackage.InvalidName, NotFound, CannotProceed, IOException
	{
		
		new LMSPolice(args);
	}
	public LMSPolice(String []args) throws InvalidName//argument from main 
, AdapterInactive, ServantNotActive, WrongPolicy, org.omg.CosNaming.NamingContextPackage.InvalidName, NotFound, CannotProceed, IOException
	{
		
		 ORB orb = ORB.init(args, null);
	        
         // get reference to rootpoa & activate the POAManager
         POA rootpoa = POAHelper.narrow(orb.resolve_initial_references("RootPOA"));
         rootpoa.the_POAManager().activate();
    
         // Create the Count servant object
         LMSPolice count = new LMSPolice();
        

         // get object reference from the servant
         org.omg.CORBA.Object ref = rootpoa.servant_to_reference(count);
         LMS cref = LMSHelper.narrow(ref);
    
         // Get a reference to the Naming service
         org.omg.CORBA.Object nameServiceObj = orb.resolve_initial_references ("NameService");
         if (nameServiceObj == null) {
              System.out.println("nameServiceObj = null");
              return;
         }

         // Use NamingContextExt which is part of the Interoperable
         // Naming Service (INS) specification.
         NamingContextExt nameService = NamingContextExtHelper.narrow(nameServiceObj);
         if (nameService == null) {
              System.out.println("nameService = null");
              return;
         }
    
         // bind the Count object in the Naming service
         String lmsname ;
         lmsname=JOptionPane.showInputDialog("Write the lms name to register");
      
         NameComponent[] countName = nameService.to_name(lmsname);
         nameService.rebind(countName, cref);
      
     

         // Use NamingContextExt instead of NamingContext. This is 
         // part of the Interoperable naming Service.  
         
      
         // resolve the Count object reference in the Naming service
        String rmcname="serverRMC";
         rmc =RMCHelper.narrow(nameService.resolve_str(rmcname));
         //  wait for invocations from clients
        
         rmc.RegisterLMS(lmsname);
         orb.run();
      
	}
	
	public LMSPolice() {
		
	}
	
	//add camera to list and zone
	@Override
	public void add_Camera(CamCorba camera, String[] zone) {
		
		CamPlaceSource[NumberOfCamPlaces]= new camPlace(camera, zone);
		
	}
	//name of LMS
	@Override
	public String name() {
		
		return "LMSService";
	}
	// raise alarm and takes a reading
	@Override
	public void raise_Alarm(Alarm reading) {
		
	
		Alist[Ai]=reading;
		Ai++;
		int i,j;
		camPlace[] CamPlaceOutput=camPlaces(); //number of cams in a location
		for(i=0;i<CamPlaceOutput.length;i++)  // loop through call cam locations to isolate 
		{
			for(j=0;j<CamPlaceOutput[i].zone.length;j++)  // loop and get the cam location by zone
			if(reading.zone.equals(CamPlaceOutput[i].zone[j]))  // if  cam is in that zone
					{
						AlarmData ad=new AlarmData (reading, CamPlaceOutput[i].cam.name());  // this will action an alarm 
						rmc.raiseAlarm(ad);  // finally raise an alarm
					//raise alarm on RMC
					}
			
		}
	}
	//list for log of alarms
	@Override
	public Alarm[] theLog() {
		
		Alarm []AlistRet=new Alarm[Ai];
		int i;
		for(i=0;i<Ai;i++)
		{
			AlistRet[i]=Alist[i];
		}
		return AlistRet;  // if call is made to Alarm returns the log
	}
	
	// Cam locations list
	camPlace[] CamPlaceSource=new camPlace[1000];
	int NumberOfCamPlaces=0;
	@Override
	public camPlace[] camPlaces() {
		camPlace [] CamPlaceOutput=new camPlace[NumberOfCamPlaces];
		int i;
		for(i=0;i<NumberOfCamPlaces;i++)
			CamPlaceOutput[i]=CamPlaceSource[i];
		return CamPlaceOutput;  // if call is made to cam list it will loop until required camera is found by location and return 
		
		
	}

}

