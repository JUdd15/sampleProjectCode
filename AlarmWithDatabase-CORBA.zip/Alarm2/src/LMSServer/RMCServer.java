package LMSServer;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.management.Query;
import javax.swing.JOptionPane;

import org.omg.CORBA.ORB;
import org.omg.CORBA.ORBPackage.InvalidName;
import org.omg.CosNaming.NameComponent;
import org.omg.CosNaming.NamingContextExt;
import org.omg.CosNaming.NamingContextExtHelper;
import org.omg.CosNaming.NamingContextPackage.CannotProceed;
import org.omg.CosNaming.NamingContextPackage.NotFound;
import org.omg.PortableServer.POA;
import org.omg.PortableServer.POAHelper;
import org.omg.PortableServer.POAManagerPackage.AdapterInactive;
import org.omg.PortableServer.POAPackage.ServantNotActive;
import org.omg.PortableServer.POAPackage.WrongPolicy;











//import com.mysql.jdbc.util.ResultSetUtil;

import DataBaseConnection.Database;
import Police.AlarmData;
import Police.LMS;
import Police.RMC;
import Police.RMCHelper;
import Police.RMCPOA;
import Police.WarningLevel;
import Police.camPlace;
// RMC server extends the RMC operations
public class RMCServer extends RMCPOA {
static LMS lms;
final static String URL="jdbc:mysql://localhost";   // database connection
final static String USER="root";
final static String PASSWORD="";  // please modify to test this part fo the application e.g. user, password

ArrayList<camPlace> camPlaces=new ArrayList<camPlace>();  // arraylist to hold camera places
static Connection con;  // database connection request

	// user fields
	public class User
	{
		
		private String name;
		private String contact;
		private String password;
		public User(String name,String contact)
		{
			this.name=name;
			this.contact=contact;
		}
		public User(String name,String contact,String password)
		{
			this.name=name;
			this.contact=contact;
			this.password=password;		
			}
		// get user info
		public String getInfo(boolean conD)
		{
			if(conD)
				return contact;
			else
				return name;
		}
		
		// verify user using boolean condition
		public boolean verify_pass(String pass)
		{
			//pass=md5(pass);
			return pass.equals(password);
				
		}
		
		//update user contact information
		public void updateContact(String input)
		{
			contact=input;
		}
		// getContact information
		public String getContact()
		{
			
				return contact;
			
			
		}
		

		
	}
	
	// arraylist to hold user data
	ArrayList<User> ul=new ArrayList<User>();
	//list to hold alarm data
	AlarmData[] log=new AlarmData[1000];
	int ilog=0;
	
	// warning level for current alarms by district
	@Override
	public WarningLevel currentAlarms(String district) {
	
		//if we need to get the current camera locations 
		int i,j,k;
		camPlace []CameraPlaceOutput=lms.camPlaces();
		for(i=0;i<ilog;i++)   // loop the ilog
		{
			if(log[i].aReading.zone.equals(district))  // find match for reading in a zone matching district
			{
				for(j=0;j<CameraPlaceOutput.length;j++)  
				{
				
					if(CameraPlaceOutput[j].cam.name().equals(log[i].aConfirmingCamera)) // match the reading and district to a confirming camera
					{
						return CameraPlaceOutput[j].cam.current();  // returns that current camera
					}
					
				}
			}
		}
		return null;
	}
	// this updates the ilog when raise alarm is called
	@Override
	public void raiseAlarm(AlarmData anAlarm) {
		
		log[ilog]=anAlarm;
		ilog++;
		

	}
	/*
	 * (non-Javadoc)
	 * @see Police.RMCOperations#registerUser(java.lang.String, java.lang.String, java.lang.String)
	 * 
	 * when user register they are stored locally as well as in SQL database
	 */
	@Override
	public void registerUser(String who, String contact_details,String password){
		// get the user data
		ul.add(new User(who,contact_details,password));
		// prepared statement and send to new table persons
		PreparedStatement stmt;
	
		try {
			stmt = con.prepareStatement("INSERT INTO PERSON (name,contact,password) VALUES(?,?,?)");
			//ResultSet res=stmt.getGeneratedKeys();
			
			ResultSet rs;
			/*  stmt.getGeneratedKeys();
			int generatedKey=0;
			if (rs.next()) {
			    generatedKey = rs.getInt(1);
			}
			int rid = generatedKey;
			System.out.println("Inserted record's ID: " + rid);
			
			System.out.println("Record Updated");*/
			
		// VALUES set by index will update the data to SQL database in order of index(1,2,3)
		stmt.setString(1, who);
		stmt.setString(2, contact_details);
		stmt.setString(3, password);
		
		
		stmt.execute();
	
		stmt.close();
		stmt=con.prepareStatement("SELECT id from person where name=?");
		stmt.setString(1, who);
		stmt.execute();
		rs=stmt.getResultSet();
		rs.next();
		System.out.println("Inserted Id is:"+rs.getInt(1));
		System.out.println("test");
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
	}

	/**
	 * @param args
	 * @throws SQLException 
	 * @throws InvalidName 
	 * @throws org.omg.CosNaming.NamingContextPackage.InvalidName 
	 * @throws CannotProceed 
	 * @throws NotFound 
	 * @throws WrongPolicy 
	 * @throws ServantNotActive 
	 * @throws AdapterInactive 
	 * @throws IOException 
	 */

			
	// naming service operstions
	public static void main(String[] args) throws InvalidName, NotFound, CannotProceed, org.omg.CosNaming.NamingContextPackage.InvalidName, ServantNotActive, WrongPolicy, AdapterInactive, IOException, SQLException {
		con=Database.init();
		JOptionPane.showMessageDialog(null,"server loading", "", JOptionPane.INFORMATION_MESSAGE);
		
		ORB orb = ORB.init(args, null);
        
        // get reference to rootpoa & activate the POAManager
        POA rootpoa = POAHelper.narrow(orb.resolve_initial_references("RootPOA"));
        rootpoa.the_POAManager().activate();
   
        // Create the Count servant object
        RMCServer count = new RMCServer();
        
        // get object reference from the servant
        org.omg.CORBA.Object ref = rootpoa.servant_to_reference(count);
       RMC cref = RMCHelper.narrow(ref);
   
        // Get a reference to the Naming service
        org.omg.CORBA.Object nameServiceObj = orb.resolve_initial_references ("NameService");
        if (nameServiceObj == null) {
             System.out.println("nameServiceObj = null");
             return;
        }

        // Use NamingContextExt which is part of the Interoperable
        // Naming Service (INS) specification.
        NamingContextExt nameService = NamingContextExtHelper.narrow(nameServiceObj);
        if (nameService == null) {
             System.out.println("nameService = null");
             return;
        }
   
        // bind the Count object in the Naming service
        String name = "serverRMC";
        NameComponent[] countName = nameService.to_name(name);
        nameService.rebind(countName, cref);
        JOptionPane.showMessageDialog(null,"Server connected", "", JOptionPane.INFORMATION_MESSAGE);
	     orb.run();
	   
	  
	   
	     

	}
	// Alarmdata for getlogreq synced (This is a test still checking if it does work)
	@Override
	public synchronized AlarmData[] getLogReq()
	{
		int i;
		System.out.println("get log RMC");
		AlarmData[] out=new AlarmData[ilog];
		for(i=0;i<out.length;i++)
			out[i]=log[i];
		return out;
	}
	// registerered LMS method
	@Override
	public void RegisterLMS(String LMSName) {
		
		lmsList[lmsLength]=LMSName;
		lmsLength++;
		
	}
	String []lmsList=new String[1000];
	int lmsLength=0;
	@Override
	public String[] ListLMS() {
		
		String[] outLms=new String[lmsLength];
		int i;
		for(i=0;i<lmsLength;i++)
		{
			outLms[i]=lmsList[i];
		}
		return outLms;  // returns the current LMS if called 
	}
	// login checks for users username against stored password
	@Override
	public boolean login(String user, String password) {
		for(int i = 0;i<ul.size();i++)
		{
			if(ul.get(i).getInfo(false).equals(user))  // checks the user data 
			{
				if(ul.get(i).verify_pass(password))
				{
					System.out.println("You have access to your account");
					return true;  // access granted
					
				}
			}
		}
		return false;  // not granted access
	}
	// This methods get the user data when reqested
	@Override
	public String getContactUser(String user,String password)
	{
		int i;
		if(login(user,password))
		{
			for(i=0;i<ul.size();i++)
			{
				if(user.equals(ul.get(i).getInfo(false)))  // if false condition 
				{
					return ul.get(i).getInfo(true);  // returns that data when called
				}
			}
		}
		return null;
	}
	
	// set user data for update contact
	@Override
	public void setContactUser(String user,String password,String contact)
	{
		int i;
		if(login(user,password))
		{
			for(i=0;i<ul.size();i++)
			{
				if(user.equals(ul.get(i).getInfo(false)))
				{
					 ul.get(i).updateContact(contact);  // update by index from the arraylist
				}
			}
		}
		
	}


}
