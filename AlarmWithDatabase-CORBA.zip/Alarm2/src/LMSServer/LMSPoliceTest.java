package LMSServer;

import java.io.IOException;

import junit.framework.Assert;

import org.junit.Test;
import org.omg.CORBA.ORB;
import org.omg.CORBA.ORBPackage.InvalidName;
import org.omg.CosNaming.NamingContextPackage.CannotProceed;
import org.omg.CosNaming.NamingContextPackage.NotFound;
import org.omg.PortableServer.POA;
import org.omg.PortableServer.POAHelper;
import org.omg.PortableServer.POAManagerPackage.AdapterInactive;
import org.omg.PortableServer.POAPackage.ServantNotActive;
import org.omg.PortableServer.POAPackage.WrongPolicy;

import CamServer.CamCorbaServer;
import Police.Alarm;
import Police.CamCorba;
import Police.CamCorbaHelper;
import Police.LMS;
import Police.LMSHelper;
import Police.RMC;
import Police.RMCHelper;
import Police.WarningLevel;
import Police.camPlace;

/*/ testing the reference to the object if they are stored in memory by reference then we can 
 * create new object and reference them check if they do call the  server by the client
 * this reduces the need to import the framework into the test suite and just assumes that the cached references will
 * still work with additional data.
 * This is all theoretical based on the materials that have been read it is assumed that there must be residual
 * data references in memory.
 * 
 * 
 */
public class LMSPoliceTest {

	@Test
	public void test() throws InvalidName, ServantNotActive, WrongPolicy,
			AdapterInactive,
			org.omg.CosNaming.NamingContextPackage.InvalidName, NotFound,
			CannotProceed, IOException {

		String[] args = { "O"
				+ "RBInitialPort", "1050" };
		ORB orb = ORB.init(args, null);

		// get reference to rootpoa & activate the POAManager
		POA rootpoa = POAHelper.narrow(orb
				.resolve_initial_references("RootPOA"));
		rootpoa.the_POAManager().activate();
		String namecam = "name";

		String namelms = "namecount";
		// Create the Count servant object
		LMSPolice ccd = new LMSPolice();

		// get object reference from the servant
		org.omg.CORBA.Object reflms = rootpoa.servant_to_reference(ccd);
		LMS creflms = LMSHelper.narrow(reflms);
		String[] zones = { "leeds", "hudd" };

		RMCServer rmcser = new RMCServer();
		// get object reference from the servant
		org.omg.CORBA.Object refrmc = rootpoa.servant_to_reference(rmcser);
		RMC crefrmc = RMCHelper.narrow(refrmc);
	
		CamCorbaServer ccscam = new CamCorbaServer(namecam);
		CamCorbaServer.lms = creflms;
		org.omg.CORBA.Object refcam = rootpoa.servant_to_reference(ccscam);
		CamCorba crefcam = CamCorbaHelper.narrow(refcam);
		crefcam.receieveAlarm(new Alarm(3, 4, "a message", "a sensor",
				"a image"), new WarningLevel(3, "a message wl", "a image ul"));
		Alarm[] Alms = creflms.theLog();
		Assert.assertEquals("a image", Alms[0].image);
		creflms.add_Camera(crefcam, zones);
		camPlace[] cp = creflms.camPlaces();

		Assert.assertEquals("leeds", cp[0].zone[1]); // assertion made at this
													// point

		System.out.println(cp[0].zone[1]);// check if output matches
       
         
	}}



