package Resident;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.JScrollPane;
import javax.swing.JCheckBox;
import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.JTextField;
import javax.swing.JPasswordField;

import org.omg.CORBA.ORB;
import org.omg.CosNaming.NamingContextExt;
import org.omg.CosNaming.NamingContextExtHelper;
import org.omg.CosNaming.NamingContextPackage.CannotProceed;
import org.omg.CosNaming.NamingContextPackage.InvalidName;
import org.omg.CosNaming.NamingContextPackage.NotFound;

import Police.AlarmData;
import Police.RMC;
import Police.RMCHelper;
/*
 * Resident class
 */
public class Resident extends Thread {

	private JFrame frame;
	private JTextField userField;
	private JPasswordField passwordField;
	private JTextArea logResident;
	private JCheckBox updateResident;
	private JTextArea contactResident;

	/**
	 * Launch the application.
	 */
	
	// auto updates for resident class
	@Override
	public void run()
	{
		int i;
		String output="";  // empty variable
		while(true)  // while true forever looping
		{
			if(getUpdateResident().isSelected())  // if checkbox selected
			{
				// updates that specified area in GUI
				output="";
				AlarmData[] att=rmc.getLogReq();// gets data form RMC server
				for(i=0;i<att.length;i++)
				{
					// empty variable filled with parameter data from RMC server
					output+="camera:"+att[i].aConfirmingCamera+" sensor:"+att[i].aReading.sensor+" date:"+att[i].aReading.date+" time:"+att[i].aReading.time+" zone:"+att[i].aReading.zone + "\n";
				}
				getLogResident().setText(output);  // GUI are updated with above data
			}
			try {
				Thread.sleep(3000);  // every 3 seconds
			} catch (InterruptedException e) {
				
				e.printStackTrace();
			}
		}
	}
	
	// naming service
	public static RMC rmc;
	public static void main(String[] args) throws NotFound, CannotProceed, InvalidName, org.omg.CORBA.ORBPackage.InvalidName {
		System.out.println("Initializing the ORB");
        ORB orb = ORB.init(args, null);
   
        // Get a reference to the Naming service
        org.omg.CORBA.Object nameServiceObj = orb.resolve_initial_references ("NameService");
        if (nameServiceObj == null) {
             System.out.println("nameServiceObj = null");
             return;
        }

        // Use NamingContextExt instead of NamingContext. This is 
        // part of the Interoperable naming Service.  
        NamingContextExt nameService = NamingContextExtHelper.narrow(nameServiceObj);
        if (nameService == null) {
             System.out.println("nameService = null");
             return;
        }
   
        // resolve the Count object reference in the Naming service
        String name = "serverRMC";
        rmc = RMCHelper.narrow(nameService.resolve_str(name));
		EventQueue.invokeLater(new Runnable() {
			@Override
			public void run() {
				try {
					Resident window = new Resident();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Resident() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.login
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(31, 107, 166, 70);
		frame.getContentPane().add(scrollPane);
		
		logResident = new JTextArea();
		logResident.setEditable(false);
		scrollPane.setViewportView(logResident);
		
		updateResident = new JCheckBox("Resident Update");
		updateResident.setEnabled(false);
		updateResident.setBounds(41, 77, 149, 23);
		frame.getContentPane().add(updateResident);
		
		JLabel lblLogin = new JLabel("login");
		lblLogin.setBounds(270, 60, 46, 14);
		frame.getContentPane().add(lblLogin);
		
		
		// login for user on the client via CORBA framework
		JButton btnLogin = new JButton("login");
		btnLogin.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				JTextField usrField=getUserField();
				JTextField passField=getPasswordField();
			
				boolean log=rmc.login(usrField.getText(), passField.getText());  // add values to boolean variable
				
				if(log)
				{
				  frame.setTitle(usrField.getText());
  
				  updateResident.setEnabled(true);  // updates enabled
				  getContactResident().setText(rmc.getContactUser(usrField.getText(), passField.getText()));
				  start();
				  getPasswordField().setEnabled(false);  // set to false when access not granted to not show user data for security
				  getUserField().setEnabled(false);	
				  // when access granted fields will be active
				}
				else
				{
					JOptionPane.showMessageDialog(frame,"failed to login", "", JOptionPane.ERROR_MESSAGE);
				}
				
			}
		});
		btnLogin.setBounds(270, 154, 89, 23);
		frame.getContentPane().add(btnLogin);
		
		userField = new JTextField();
		userField.setBounds(310, 85, 86, 20);
		frame.getContentPane().add(userField);
		userField.setColumns(10);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(310, 110, 86, 20);
		frame.getContentPane().add(passwordField);
		
		JLabel lblNewLabel = new JLabel("user name");
		lblNewLabel.setBounds(241, 88, 85, 14);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblPassword = new JLabel("password");
		lblPassword.setBounds(241, 113, 51, 14);
		frame.getContentPane().add(lblPassword);
		
		JLabel lblContactDetails = new JLabel("contact details");
		lblContactDetails.setBounds(41, 188, 128, 14);
		frame.getContentPane().add(lblContactDetails);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(31, 213, 166, 48);
		frame.getContentPane().add(scrollPane_1);
		
		contactResident = new JTextArea();
		scrollPane_1.setViewportView(contactResident);
		
		
		// update uses the set method to change the user data when required
		JButton btnUpdate = new JButton("update");
		btnUpdate.addActionListener(new ActionListener() {
			@Override
			@SuppressWarnings("deprecation")
			public void actionPerformed(ActionEvent arg0) {
				rmc.setContactUser(getUserField().getText(), getPasswordField().getText(), getContactResident().getText()+ "\n");
			}
		});
		btnUpdate.setBounds(207, 227, 89, 23);
		frame.getContentPane().add(btnUpdate);
	}
	public JPasswordField getPasswordField() {
		return passwordField;
	}
	public JTextField getUserField() {
		return userField;
	}
	public JTextArea getLogResident() {
		return logResident;
	}
	public JCheckBox getUpdateResident() {
		return updateResident;
	}
	public JTextArea getContactResident() {
		return contactResident;
	}
}
