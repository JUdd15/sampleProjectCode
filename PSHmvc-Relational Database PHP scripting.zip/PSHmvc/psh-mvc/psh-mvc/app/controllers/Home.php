<?php 
class Home extends Controller{
	public function index()
	{
		$this->views("Home/login", [] );
	}

	public function login()
	{
		$login = $this->models("login");
		if($login->validate_login(["username"=> $_POST["username"], "password"=> $_POST["password"] ]))
		{
			$this->views("home/home", [] );			
		}
		else {
			$this->views("home/login", ["message" => "Login was not successful. Password or Username is incorrect"] );			
		}
	}	
}

?>