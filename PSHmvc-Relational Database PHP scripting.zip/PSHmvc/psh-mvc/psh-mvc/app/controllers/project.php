<?php 
class project extends Controller{
	public function index()
	{
		$project_model = $this->models("project_db");
		$all_projects =  $project_model->select();
		
		$this->views("project/index", $all_projects);
		
	}
	
	public function edit_project($params=[])
	{
		$project_model = $this->models("project_db");
		
		$this->views("project/edit_project", $params);
		
	}
	
	
	public function upload_project($params=[])
	{	
		
		$project_model = $this->models("project_db");	
		
		if(isset($_FILES["fileupload"])){
			$status = $project_model->upload_file($params);
			if( $status == 'success'){
				$this->index();			
			}
		else{
			echo $status;	
			$all_projects =  $project_model->select($params);		
			$this->views("project/upload_project", $all_projects);
		}			
		}else{		
			$all_projects =  $project_model->select($params);		
			$this->views("project/upload_project", $all_projects);
		}
		
	}
	
	public function download_project($params=[]){
		$project_model = $this->models("project_db"); // Create an instance of the project model	
		$project_to_download = $project_model->select($params); // using the instance to get the specific project
		
		$project_to_download = mysqli_fetch_array($project_to_download); // fetch the row from the set returned from the database. 
				
		if(file_exists($project_to_download['project_path'])){ // Checking if the project file exists on the file system of the server
			
			$project_model->save_download($_SESSION['userid'],$params); // Saving that project to the download project table
					
			$file_details = pathinfo($project_to_download['project_path']); // getting the detail parts of the string path
			
			header("Content-Description: Raj Downloading");	
			header("Content-Type: application/octet-stream"	);		
			header("Content-Disposition: attachment; filename=" . $file_details['basename'] );	
			header("Expires: 0");
			header("Content-Length:" . filesize($project_to_download['project_path']));
			readfile($project_to_download['project_path']);		// reading and printing out the file for download	
			
		}
		else{ // if the file does not exists
			echo "Not Found";
			
		}
		
		
		
			
	}
	
	

}

?>