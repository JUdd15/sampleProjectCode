<?php 
class Controller{
	
	public function views($viewpath,$data=[]){
		require_once "../app/views/" . $viewpath . ".php"; // include the required view
			
	}
	
	public function models($model)
	{
		require_once "../app/models/" .$model . ".php"; // include the required model
		return new $model();
	}
	
		
}

?>