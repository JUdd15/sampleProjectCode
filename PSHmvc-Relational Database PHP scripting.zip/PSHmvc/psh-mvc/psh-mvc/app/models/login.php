<?php 

class login{
	
	public function get_userdetails()
	{
		return ["username"=>"raj" , "FirstName"=>"Raj", "Country"=>"UK"];
		
	}	
	
	public function validate_login($user_details){
		global $handle;	
		
	$sql = "SELECT email,name,user_type,user.userid FROM `psh_user` user , 
	(SELECT sub.*, case when dev.userid is not null then 'Developer' when non.userid is not null then 'Non-Developer' end user_type  FROM `psh_subscriber` sub left outer join psh_developer dev
on (sub.userid = dev.userid) left outer join psh_nondeveloper  non 
on (sub.userid = non.userid)) sub
			where user.userid = sub.userid
			and email = '".$user_details["username"]."' and password = '".$user_details["password"]."'";
	
	
	$user = mysqli_query($handle,$sql);  
	
	
	$login_user = mysqli_fetch_array($user);	
	
	if($login_user["email"] == $user_details['username'])
	{
		$_SESSION["userid"] = $login_user["userid"];
		$_SESSION["email"] = $login_user["email"];
		$_SESSION["name"] = $login_user["name"];		
		$_SESSION["user_type"] = $login_user["user_type"];		
	}else {
		return false;
	}
	
	return true;
		
	}
	
}

?>