<?php 

class project_db{

	public function select($project_id=""){
				
		global $handle;
		$WHERE = ($project_id == "" ? "" : "WHERE projectid= '".$project_id . "'");
		
		$sql = "SELECT * FROM psh_project " . $WHERE;		
		return mysqli_query($handle,$sql);
	}
	
	public function update($project_id, $updates){
		global $handle;
		$sql = "UPDATE psh_project SET ";
		foreach( $updates as $key => $value){
			$sql .=  $key . "='" . 	$value . "',";		
		}
		
		$sql = rtrim($sql,',');
		
		$sql .= " WHERE projectid='" . $project_id . "'";
		return mysqli_query($handle,$sql);
	}
	
	
	public function save_download($userid,$projectid)
	{	
		global $handle;	
		$sql = "INSERT INTO psh_download (projectid,userid) VALUES('".$projectid."','".$userid."')";
		
		return mysqli_query($handle,$sql);
	}
	
	
	public function insert($colum){
		
		
	}
	
	
	public function delete(){
		
		
		
	}
	
	public function upload_file($projectid=''){
		
		$project_locations = "projects/";
		$project_file_name = $project_locations .  str_replace(" ","",$_FILES["fileupload"]["name"]);
				
		if($_FILES['fileupload']['size'] > 100000){
			return "FIle Size too large";
		}
		
		
		if(file_exists($project_file_name)){
			return "file already exists";
		}

		$fileExtension = pathinfo($project_file_name, PATHINFO_EXTENSION);
		
		if($fileExtension != 'img' &&  $fileExtension != 'rft')
		{
			echo  $_FILES["fileupload"]["tmp_name"];
			
			if(move_uploaded_file( $_FILES["fileupload"]["tmp_name"], $project_file_name))
			{				
				$this->update($projectid, array("project_path"=>  $project_file_name) );		
				return "success";
			}
			else{
				
				return "error Uploading";
			}			
		}else
		{
			return "Invalid File Extension";			
		}
		
	}
	
	
}


?>