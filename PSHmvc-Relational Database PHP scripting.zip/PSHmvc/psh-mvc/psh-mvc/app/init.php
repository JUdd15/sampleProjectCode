<?php 

session_start();

$host = "localhost";
$user = "root";
$password = "";
$database="psh";

$handle = mysqli_connect($host,$user,$password) or die ("Unable to connect");
mysqli_select_db($handle,$database)or die ("Unable to Select Database connect");
	
require_once "core/App.php";
require_once "core/Controller.php";	

?>