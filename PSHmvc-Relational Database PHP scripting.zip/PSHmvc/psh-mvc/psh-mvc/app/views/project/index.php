<table>
	<tr>
		<th></th>
		<th>Project ID</th>
		<th>Status</th>
		<th>Description</th>
		<th>Owned By</th>
	</tr>
	
	<?php while($project = mysqli_fetch_array($data)){?>
	
	<tr>
		<td><a href = "/psh-mvc/public/project/edit_project/<?php echo $project["projectid"]; ?>">Edit</td>
		<td><a href = "/psh-mvc/public/project/upload_project/<?php echo $project["projectid"]; ?>">Upload</td>
		<td>
			<?php if($project["project_path"] != ""){ ?>
			<a href = "/psh-mvc/public/project/download_project/<?php echo $project["projectid"]; ?>">Download
			<?php } ?>
		</td>
		<td><?php echo $project["projectid"]; ?></td>
		<td><?php echo $project["status"]; ?></td>
		<td><?php echo $project["description"]; ?></td>
		<td><?php echo $project["ownedby"]; ?></td>
	</tr>
	
	<?php } ?>
	
</table>