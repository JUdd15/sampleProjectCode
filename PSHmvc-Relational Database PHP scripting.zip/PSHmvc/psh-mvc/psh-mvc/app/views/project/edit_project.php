<h1>Edit Project<h1>



<?php 

print_r($data[0]);
?>