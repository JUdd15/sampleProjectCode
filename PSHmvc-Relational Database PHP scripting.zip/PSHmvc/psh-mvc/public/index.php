<?php 
	require_once "../app/init.php"; // Calling the init.php file
    $app = new App; // The init.php file calls the app.php as such we can now create an instance of the app class

	/*		
		URL: {http://localhost/psh-mvc/public/project/edit_project/PR0001}
		
		{http://localhost/psh-mvc/public/} 	- Calls index.php
		{project} 							- Determine the controller to call
			{edit_project} 					- Determine the module/function to call
				{PR0001}					- Parameter passed to the module/function
		
		[Order]
		index.php 
			init.php (Connect to database)
				app.php (Determine which controller and module to call and pass the parameter to)
				Controller.php (Class Controller) (Manages the call to the view and model) DAO object are the models
				
				
		[Once the above determine the controller and module to call]
		Controller
			-> Model (DAO) 	- Get or Set data to or from the database
			-> View 		- Gets the data from the model and display to the user 
	*/
	
	
?>


