<?php 

session_start();  // Enabling sessions

/////////// Database details //////////
$host = "localhost";
$user = "root";
$password = "";
$database="psh";
////////////////////////////////////////

$handle = mysqli_connect($host,$user,$password) or die ("Unable to connect"); // Connecting to the server with the database (eg. Mysql Server)
mysqli_select_db($handle,$database)or die ("Unable to Select Database connect"); // Connect to one of the database on the server
	
require_once "core/App.php"; 
require_once "core/Controller.php";	

?>