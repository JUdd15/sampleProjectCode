<?php 
class Controller{
	
	public function views($viewpath,$data){ // Calls a specific view
		require_once "../app/views/" . $viewpath . ".php"; // include the required view			
	}
	
	public function models($model) // Calls a specific model / DAO 
	{
		require_once "../app/models/" .$model . ".php"; // include the required model
		return new $model(); // Returning the model to the controller
	}	
}

?>