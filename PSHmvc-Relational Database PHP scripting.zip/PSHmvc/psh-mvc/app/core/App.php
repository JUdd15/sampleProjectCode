<?php
class App {
	
	protected $controller = "home";
	protected $method = "index";
	protected $parameters = [];
// Calls the constructor  >> parse the url >> determinies the contreoller and >> determines the method>> 		
	public function __construct() // Default function
	{
		$url = $this->parseurl();
		if(file_exists('../app/controllers/'. $url[0]. '.php')) // Checks if the file for the requested controller exists
		{			
			$this->controller	= $url[0]; // save the requested controller name in the variable
			unset($url[0]);
		}		
		require_once '../app/controllers/'. $this->controller. '.php'; //include the file for the requested controller
 	 	
		$this->controller = new $this->controller; // Created an instance of the controller. Eg. instance = new Home
				
		if(isset($url[1])){
			if(method_exists($this->controller, $url[1])) // check if the requested method exists in the controller. 
			{
				$this->method = $url[1]; // save the requested method in variable
				unset($url[1]);				
			}
		}
				
		// GET PARAMETERS			
		 $this->parameters = (is_array($url) ? array_values($url) : []) ;
		
		call_user_func_array([$this->controller,$this->method], $this->parameters ); // call the specific method within the controller and passing an array of parameters
			
	}
	
	public function parseurl(){  // Parses the URL to determine the controller, module and parameters
		if(isset($_GET['raj'])){			
				return explode('/', rtrim($_GET['raj'], '/') );				
		}
}
}
?>