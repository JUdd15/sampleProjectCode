<?php 
class project extends Controller{
	public function index()// Default function 
	{
		$project_model = $this->models("project_db"); // Creating an instance of the project db DAO
		$all_projects =  $project_model->select(); // Calling the select function from the project db DAO to get a listing of all project
		
		$this->views("project/index", $all_projects); //Calling the project view to display all the projects
		
	}
	
	// NOT FULLY IMPLEMENTED
	public function edit_project($params=[]) // Used to update/edit a project
	{
		$project_model = $this->models("project_db");  // Creating an instance of the project db DAO
		
		// Call the update function in the project_model instance and pass the params. 
		
		$this->views("project/edit_project", $params); // Call the project view to allow used to modify project		
	}
	
	
	public function upload_project($params=[])
	{	
		
		$project_model = $this->models("project_db"); // Creating an instance of the project db DAO
		
		// Testing if a file was submitted to upload
		if(isset($_FILES["fileupload"])){  // if file was submitted to upload
			$status = $project_model->upload_file($params); // call the upload function in the project db and pass the project ID
			if( $status == 'success'){ // checking if the upload was a success
				$this->index();			// calling index page to display all the projects 
			}
		else{
			echo $status; 
			$all_projects =  $project_model->select($params);		// Calling the select function from the project db DAO to get a listing of all project	
			$this->views("project/upload_project", $all_projects); //Calling the project view to display all the projects
		}			
		}else{ // if no file was submitted do the below		
			$all_projects =  $project_model->select($params);	// Calling the select function from the project db DAO to get a listing of all project	
			$this->views("project/upload_project", $all_projects); //Calling the project view to display all the projects
		}
		
	}
	
	public function download_project($params=[]){
		$project_model = $this->models("project_db"); // Create an instance of the project model	
		$project_to_download = $project_model->select($params); // using the instance to get the specific project
		
		$project_to_download = mysqli_fetch_array($project_to_download); // fetch the row from the set returned from the database. 
				
		if(file_exists($project_to_download['project_path'])){ // Checking if the project file exists on the file system of the server
			
			$project_model->save_download($_SESSION['userid'],$params); // Saving that project to the download project table
					
			$file_details = pathinfo($project_to_download['project_path']); // getting the detail parts of the string path
			
			header("Content-Description: Raj Downloading");	
			header("Content-Type: application/octet-stream"	);		
			header("Content-Disposition: attachment; filename=" . $file_details['basename'] );	
			header("Expires: 0");
			header("Content-Length:" . filesize($project_to_download['project_path']));
			readfile($project_to_download['project_path']);		// reading and printing out the file for download	
			
		}
		else{ // if the file does not exists
			echo "Not Found";
			
		}
		
		
		
			
	}
	
	

}

?>