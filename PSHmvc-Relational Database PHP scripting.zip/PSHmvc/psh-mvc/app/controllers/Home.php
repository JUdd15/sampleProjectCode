<?php 
class Home extends Controller{ // Extending to the controller class - Ability to call a view or model
	public function index()
	{
		$this->views("home/login", [] ); //Default our application to the login view page
	}

	public function login() // Module is validate the user trying to login
	{
		$user = $this->models("users"); // Getting an instance of the login model
		if($user->validate_login(["username"=> $_POST["username"], "password"=> $_POST["password"] ])) // Call the validate function and passing the user details
		{
			$this->views("home/home", [] );	// If login was successful call the home page		
		}
		else {
			$this->views("home/login", ["message" => "Login was not successful. Password or Username is incorrect"] );		//Call back the login view and passing a message 	
		}
	}	
}

?>