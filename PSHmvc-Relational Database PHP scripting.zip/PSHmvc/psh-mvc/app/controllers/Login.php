<?php 
class Login extends Controller{
	public function loguser()
	{
		echo "Login";
	}

}

?>