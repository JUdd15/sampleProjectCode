<?php 

class bugreport extends Controller{ // extending the controller class - to view 

	public function viewbugreport($param=[]){ // all to show a bug report
		$bug_model = $this->models("bugreport_db"); // get instance of the bug report db DAO
		
		$all_bugs = $bug_model->select("",$param); // Getting a life bug report for a given project
		
		$this->views("bugreport/viewbugreport",array("all_bugs"=>$all_bugs, "project_id" => $param)); // Pass the project Id and Bug report details to the view for displaying
		
	}
	
	public function addbugreport($params=[]){
		$bug_model = $this->models("bugreport_db");	// DB Instance of the bug report DAO 
		$project_db = $this->models("project_db"); // DB Instance of the project DAO
		
		$project = $project_db->select();  // get all projects
		
		$this->views("bugreport/addbugreport",$project); //Pass all the project to the view - Used for Dropdown list
		
		if(isset($_POST['addbugreport'])){	// Check if the user submit to add the bug report
			$bug_id = $bug_model->add_bug( array( "projectid"=>$_POST["projectid"] , "description"=>$_POST["description"] ) );	// Call the add bug function and pass the bug details	
			// $bug_id : return if for the bug just added
			
			$bug_model->add_bug_report(array("bugid"=>$bug_id, "projectid"=>$_POST["projectid"], "userid"=>$_SESSION["userid"])); // call the bug report function and pass the bug report detils
		}
		
	}
	
	
	
	
}



?>