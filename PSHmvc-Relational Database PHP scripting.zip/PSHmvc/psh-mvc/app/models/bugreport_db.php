<?php 
class bugreport_db{
	
	function add_bug($params){
		global $handle;
		
		$sql = "INSERT INTO psh_bug (projectid,description) 
				VALUES(
						'".$params["projectid"]."',
						'". $params["description"] ."'
					  )"; // SQL statement with the information to be added
					  
		mysqli_query($handle,$sql); // execute SQL statement
		$bug_id = mysqli_insert_id($handle); // Getting the last auto-increment primary field id for the last table inserted into
		
		return $bug_id;
	}
	
	function add_bug_report($params){
		
		global $handle;
		
		$sql = "INSERT INTO psh_bugreport (bugid,projectid,userid) VALUES(
			".$params["bugid"].",
			'".$params["projectid"]."',
			'".$params["userid"]."'
		)"; // SQL statement with the information to be added
		
		mysqli_query($handle,$sql); // execute SQL statement
		
	}	
	
	function select($bugid="",$projectid="" ){
		global $handle;
		
		$WHERE = ( ( $bugid != "" ? " AND b.bugid=".$bugid : ( $projectid != "" ? " AND b.projectid='".$projectid."'"  : "") ) ); // Building the where clause based on the parameters
		
	/* IF Bug_ID != "" THEN "AND BUGID = {parameter bug id}"
		ELSE 
			IF PROJECT_ID != "" THEN "AND  PROJECTID = {parameter project id}"
		ELSE ""
	   END
	*/	
		$sql = "SELECT b.*,u.name FROM psh_bug b, psh_bugreport bp, psh_user u WHERE b.bugid = bp.bugid AND bp.userid = u.userid " . $WHERE;	// Building the SQl statement to select one or more bug report based on the where clause	
		return mysqli_query($handle,$sql); // execute sql statement
	}
	
}


?>