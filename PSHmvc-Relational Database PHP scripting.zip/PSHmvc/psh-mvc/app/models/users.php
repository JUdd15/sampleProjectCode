<?php 

class users{
	
	public function view_users($userid)
	{				
	}

	public function update_user($user_details){
			
	}
	
	public function delete_user($userid){
				
	}
	
	public function add_new_user($user_details){
		
	}
		
	public function validate_login($user_details){
		global $handle;	// Get the global variable for the handle/instance to the database;
		
	$sql = "SELECT email,name,user_type,user.userid FROM `psh_user` user , 
	(SELECT sub.*, case when dev.userid is not null then 'Developer' when non.userid is not null then 'Non-Developer' end user_type  FROM `psh_subscriber` sub left outer join psh_developer dev
on (sub.userid = dev.userid) left outer join psh_nondeveloper  non 
on (sub.userid = non.userid)) sub
			where user.userid = sub.userid
			and email = '".$user_details["username"]."' and password = '".$user_details["password"]."'"; // Select statement filtering on a username and password
	
	
	$user = mysqli_query($handle,$sql);  // Querying the database using the SQL statement created above
		
	$login_user = mysqli_fetch_array($user); // Get the row for the database set. (Getting the user details)	
	
	if($login_user["email"] == $user_details['username']) // Checking if the user we get from the database is the one that is trying to login
	{
		// Saving the user information into sessions //
		$_SESSION["userid"] = $login_user["userid"];  
		$_SESSION["email"] = $login_user["email"];
		$_SESSION["name"] = $login_user["name"];		
		$_SESSION["user_type"] = $login_user["user_type"];		
	}else {
		return false;
	}
	
	return true;
		
	}
	
}

?>