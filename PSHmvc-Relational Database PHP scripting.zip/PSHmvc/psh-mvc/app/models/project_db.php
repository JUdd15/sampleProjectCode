<?php 

class project_db{

	// return all or a specific project
	public function select($project_id=""){ // takes a PROJECT ID as the parameter - Optional  / Defaults as a empty string
				
		global $handle; // getting the global variable for the DB handle
		$WHERE = ($project_id == "" ? "" : "WHERE projectid= '".$project_id . "'"); // Building the where SQL clause based on the parameter
		
		$sql = "SELECT * FROM psh_project " . $WHERE;	 // Select statement to get projects	
		return mysqli_query($handle,$sql); // execute the SQl statement and return the results
	}
	
	public function update($project_id , $updates /*An array of the field and values to be updated*/ ){ // Used to update a project
		global $handle; // getting the global variable for the DB handle
		$sql = "UPDATE psh_project SET "; // Update SQL statement
		foreach( $updates as $key => $value){ // looping through all the fields to be updated and building the SQL statement
			$sql .=  $key . "='" . 	$value . "',";		
		}
		
		$sql = rtrim($sql,','); // trimming the right side of the SQL string
		
		$sql .= " WHERE projectid='" . $project_id . "'"; // Adding the where clause to the SQL statement
		return mysqli_query($handle,$sql); // execute the SQl statement and return the results
	}
	
	
	public function save_download($userid,$projectid)
	{	
		global $handle;	
		$sql = "INSERT INTO psh_download (projectid,userid) VALUES('".$projectid."','".$userid."')";
		
		return mysqli_query($handle,$sql);
	}
	
	
	public function insert($colum){
		
		
	}
	
	
	public function delete(){
		
		
		
	}
	
	public function upload_file($projectid=''){
		
		$project_locations = "projects/";  // specify the default folder location to save uplaod files
		$project_file_name = $project_locations .  str_replace(" ","",$_FILES["fileupload"]["name"]); // Building the exact filename and path for the file to be uploaded
				
		if($_FILES['fileupload']['size'] > 100000){ // ensuring the file size if not too large
			return "FIle Size too large"; //return error message
		}
		
		
		if(file_exists($project_file_name)){ // Check if the filename already exists
			return "file already exists"; 
		}

		$fileExtension = pathinfo($project_file_name, PATHINFO_EXTENSION); // getting the extension go the file to be uploaded
		
		if($fileExtension != 'img' &&  $fileExtension != 'rft') // ensuring the file is not an image of RTF
		{
			if(move_uploaded_file( $_FILES["fileupload"]["tmp_name"], $project_file_name)) // Try to move the file to the upload folder
			{				
				$this->update($projectid, array("project_path"=>  $project_file_name) );	 // if upload was a success update the database table	
				return "success";
			}
			else{
				
				return "error Uploading";
			}			
		}else
		{
			return "Invalid File Extension";			
		}
		
	}
	
	
}


?>