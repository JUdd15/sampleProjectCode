<h1>Edit Project</h1>

<?php 
echo "Unable to modify project : ". $data;
?>

<h3 style = "color:red">Page is not implemented... Sorry !!</h3>
