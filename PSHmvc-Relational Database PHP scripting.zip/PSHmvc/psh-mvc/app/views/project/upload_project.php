<h1>Upload Project Document</h1>

<?php 
	$this_project = mysqli_fetch_array($data);
?>

<form action = "/psh-mvc/public/project/upload_project/<?php echo $this_project["projectid"] ?>" method = "post" enctype="multipart/form-data">
	<table style = "width:50%">
		<tr><td>Project ID</td><td><?php echo $this_project["projectid"] ?></td></tr>
		<tr><td>Description</td><td><?php echo $this_project["description"] ?></td></tr>
		<tr><td>Status</td><td><?php echo $this_project["status"] ?></td></tr>
		<tr><td>Owned By</td><td><?php echo $this_project["ownedby"] ?></td></tr>
		<tr><td></td><td><input type = "file" name = "fileupload"></input></td></tr>
		<tr><td></td><td><input type = "submit" value = "Upload Project File"></input></td></tr>
	</table>
</form>
