<h2>Welcome Home <?php echo $_SESSION["name"]."<br/> You are a ".$_SESSION["user_type"] ; ?></h2>



<br/>
<a href= "/psh-mvc/public/project/">View Projects</a>
<a href= "/psh-mvc/public/bugreport/addbugreport">File Bug Report</a>