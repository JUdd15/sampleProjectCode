
<?php
if(isset($data["message"]))
	echo $data["message"];
?>

<!-- Login form-->
<form action = "/psh-mvc/public/home/login" method ="post">  <!-- action is the page to call after the user click to submit. method [GET, POST] -->
<table>
	<tr>
		<td>Username</td>
		<td><input type= "text" name = "username" value = ""></input></td>
	</tr>
	<tr>
		<td>Password</td>
		<td><input type= "password" name = "password"></input></td>
	</tr>
	<tr>
		<td><input type= "submit" name = "login_buton" value = "login"></input></td>
	</tr>	
</table>
</form>