
<h1>Bug Report</h1>

<h4>Project ID: <?php echo $data["project_id"]; ?></h4>

<table border="1" >
	<thead>
		<tr>
			<th>Bug Description</th>
			<th>User</th>
			<th>Submit Date</th>
		</tr>
		<?php while ($bug= mysqli_fetch_array($data["all_bugs"])) // looping though all the bugs 
			{			
		?>
			<tr>
				<td><?php echo $bug["description"]?></td>
				<td><?php echo $bug["name"]?></td>
				<td><?php echo $bug["date"]?></td>
			</tr>
			<?php }?>
	</thead>
</table>