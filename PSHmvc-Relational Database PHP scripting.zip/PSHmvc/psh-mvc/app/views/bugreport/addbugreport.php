<form action="" method="post">


Project ID: 
<select name="projectid">
	<option value ="">Select Project ID</option>
	<?php 
		while($project = mysqli_fetch_array($data)){ // looping through the list of projects
	?>
		<option value="<?php echo $project["projectid"]?>" ><?php echo $project["description"]?></option>
	<?php 
		}
	?>	
</select>

<br/>

Description:
<textarea name = "description" rows="10" cols="20"></textarea>


<button type="submit" name = "addbugreport">Add Bug Report</button>

</form>