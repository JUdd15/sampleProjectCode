/*******************************************************************************
*Author: J Uddin
*Date: 02/01/2015
*Filename : DrinksDispenser1
*Purpose: To code in C a drinks dispenser that will simulate the dispensing of
* hot and cold drinks
*******************************************************************************/
#include "DrinkDispensing.h"
#include "menu.h"

#define MENU_MAXITEM 4
#define MENU_MAXLEN  8
#define MENU_ROWS    2

static char  s_nMenu         = 0;                   /* Number of items   */
static char* s_apItems[MENU_MAXITEM];               /* Item strings      */
static char  s_iSelect       = 0;                   /* Current selection */
static char  s_iRowVisible   = 0;                   /* First visible row */





                                                  // print text into row and put space in ''
                                                    // this code runs the menu item display and deletes the previous text
#define outLine(iRow, pszText) do {        \
  char i;                                  \
  Lcd_Out(iRow, 1, pszText);               \
                                           \
  for (i = 16; i > strlen(pszText); --i) { \
    Lcd_Chr_CP(' ');                       \
  }                                        \
} while (0)

//16 columns
//tea it  does not delete but replaces the previos char  by overwirting it


//it starts at 16 then moves
//this runs the for loop lets say 10 times if coffee is used
//after runnign 10 times it comes out of loop and
//runs            .

static const char s_aRow[2] = {         // array of address line
    _LCD_FIRST_ROW
  , _LCD_SECOND_ROW
};

void Menu_Clear() {                                      //sets variables to 0
  memset(s_apItems, 0, sizeof(s_apItems));
  s_nMenu       = 0;
  s_iSelect     = 0;
  s_iRowVisible = 0;
}

void Menu_Add(
  char* pszMenu                               //string array of char point first item of array
) {
  if (s_nMenu < MENU_MAXITEM) {              //   s_nMenu is the number of menu items in a given menu
    s_apItems[s_nMenu] = pszMenu;            // you take pszMenu and
                                               // p item is an array
    /* Is new item visible? */
    if ((s_nMenu >= s_iRowVisible) && (s_nMenu < (s_iRowVisible + MENU_ROWS))) {
        outLine(s_nMenu - s_iRowVisible + 1, s_apItems[s_nMenu]);
    }

     // every time you scroll in a LCD screen do you lose data--- so it has to be coded in to know what it has to do?
     // so how do you get the data back?------to get the data back you have to use for loops to run every time a scroll is made? to make data visible--
    ++s_nMenu;

    Lcd_Cmd(s_aRow[s_iSelect - s_iRowVisible]);       // set the cursor position
  }
}

static void ensureVisible(                //ensures that current rows are visible when scrolling the drinks selection list
  char iRow
) {
  if (iRow < s_iRowVisible) { /* above */
    s_iRowVisible = iRow;  //irow item index....

    for (iRow = 0; iRow < MENU_ROWS; ++iRow) {
      outLine(iRow + 1, s_apItems[s_iRowVisible + iRow]);   // string output
    }
  }
  else if (iRow >= (s_iRowVisible + MENU_ROWS)) { /* below */
    s_iRowVisible = iRow - MENU_ROWS + 1;          //scrolls up by +1

    for (iRow = 0; iRow < MENU_ROWS; ++iRow) {
      outLine(iRow + 1, s_apItems[s_iRowVisible + iRow]);
    }
  }
}
//LCD program you would need to program every command
char Menu_GetSelection() {
  do {
    if (BUTTON_CURSORUP()) {
      if (s_iSelect > 0) {
        ensureVisible(--s_iSelect);
        Lcd_Cmd(s_aRow[s_iSelect - s_iRowVisible]);
      }
      
      while (BUTTON_CURSORUP());
    }
    else if (BUTTON_CURSORDOWN()) {          // cursor down button pressed
      if (s_iSelect < (s_nMenu - 1)) {
        ensureVisible(++s_iSelect);
        Lcd_Cmd(s_aRow[s_iSelect - s_iRowVisible]);   // if iselect- iRow will the difference being that when a menu scrolls it reveals the next data...
      }                                                // is that correct? yes correct.
      
      while (BUTTON_CURSORDOWN());    // wait the cursor down button released
    }
    else if (BUTTON_SELECT()) {                                                                       //
      while (BUTTON_SELECT());        // wait for button released
      return s_iSelect;
    }
    else if (BUTTON_PAGEPREV()) {   // the button pressed
         while (BUTTON_PAGEPREV()); // wait the button released
         return ID_PREVPAGE;
    }
    else if (BUTTON_PAGENEXT()) {
         while (BUTTON_PAGENEXT()); // wait the button released
         return ID_NEXTPAGE;
    }
  } while (1);
}

void Menu_Display(
  char* pszText                                 //clear LCd --display message
) {
  Lcd_Cmd(_LCD_CLEAR);
  outLine(1, pszText);                            //print nextor second row --of line
}