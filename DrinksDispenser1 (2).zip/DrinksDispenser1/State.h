/*******************************************************************************
*Author: J Uddin
*Date: 02/01/2015
*Filename : DrinksDispenser1
*Purpose: To code in C a drinks dispenser that will simulate the dispensing of
* hot and cold drinks
*******************************************************************************/
#ifndef __STATE_H__
#define __STATE_H__

typedef void (*PFNSTATE)();                                              //function pointer-----
                                                                      //declaration
extern void State_Run();
extern void State_Set(PFNSTATE pfnState);

extern void State_SetMainMenu();                                        // external methods for calling by c methods
extern void State_SetColdDrinks();
extern void State_SetHotDrinks();
extern void State_SetInsertCoin();
extern void State_SetReturnCoin();
extern void State_SetChange();
extern void State_SetDrinkDispensed();



#endif /* __STATE_H__ */