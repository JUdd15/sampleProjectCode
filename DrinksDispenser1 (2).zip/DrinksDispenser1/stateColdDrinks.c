#include "DrinkDispensing.h"
#include "state.h"
#include "DrinkDispensing.h"
#include "menu.h"

static void stateColdDrink() {
  Menu_Clear();
  Menu_Add("Orange Juice");
  Menu_Add("Fizzy Drink");
  Menu_Add("Water");
  switch (Menu_GetSelection()) {                         // case switch to select a DRINK type into variable
  case 0: {
    setDrink(DRINK_ORANGEJUS);
    State_SetInsertCoin();
    return;
  }
  break;

  case 1: {
    setDrink(DRINK_FIZZY);
    State_SetInsertCoin();
    return;
  }
  break;

  case 2: {
    setDrink(DRINK_WATER);
    State_SetInsertCoin();
    return;
  }
  break;
  }
}

void State_SetColdDrinks() {                    // sets the cold DRINK into the variable...
  State_Set(stateColdDrink);
}