/*******************************************************************************
*Author: J Uddin
*Date: 02/01/2015
*Filename : DrinksDispenser1
*Purpose: To code in C a drinks dispenser that will simulate the dispensing of
* hot and cold drinks
*******************************************************************************/
#include "state.h"
#include "DrinkDispensing.h"
#include "menu.h"

static void stateDrinkDispensed() {            // Drink dispensed method which calls on the menu.c state
  Menu_Display("Drink Dispensed");

  Delay_ms(3000);

  State_SetMainMenu();                        //go back to main menu
}

void State_SetDrinkDispensed() {
  State_Set(stateDrinkDispensed);               // set next state
}