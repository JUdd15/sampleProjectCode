/*******************************************************************************
*Author: J Uddin
*Date: 02/01/2015
*Filename : DrinksDispenser1
*Purpose: To code in C a drinks dispenser that will simulate the dispensing of
* hot and cold drinks
*******************************************************************************/
#include <stddef.h>                                          // include this file stddef ?    standrad def for c language

#include "state.h"

static PFNSTATE s_pfnState = NULL;   /* Initial state */

void State_Run() {                                                    //   is this class  runs the states
  if (s_pfnState) {
    (*s_pfnState)();
  }
}

void State_Set(
  PFNSTATE pfnState                                                    //   back to intial state
) {
  s_pfnState  = pfnState;
}
