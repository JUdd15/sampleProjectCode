/*******************************************************************************
*Author: J Uddin
*Date: 02/01/2015
*Filename : DrinksDispenser1
*Purpose: To code in C a drinks dispenser that will simulate the dispensing of
* hot and cold drinks
*******************************************************************************/


#include "DrinkDispensing.h"
#include "state.h"

//1- Display a menu of the type of drinks available on the LCD.
//2- Use switches connected to RD0 and RD1 to move up and down the menu.
//3- Use the switch connected to RD2 to make a selection.
//4- Insert coins by means of RD0 to RD4.
//5- Use LED connected to RD7 is simulate the number of coins returned.
//6- Display suitable messages to inform the customer as the drink is made

// LCD module connection from pic to lcd
// The LCD using PORTB
sbit LCD_RS at RD4_bit;                        // PORTD bit 4 to RS pin on LCD
sbit LCD_EN at RD5_bit;                          // PORTD bit 5 to EN pin on LCD
sbit LCD_D4 at RD0_bit;                   //    buttons  data bit to the button
sbit LCD_D5 at RD1_bit;
sbit LCD_D6 at RD2_bit;
sbit LCD_D7 at RD3_bit;

sbit LCD_RS_Direction at TRISD4_bit;          // PORTD bit 4 as output
sbit LCD_EN_Direction at TRISD5_bit;         //
sbit LCD_D4_Direction at TRISD0_bit;
sbit LCD_D5_Direction at TRISD1_bit;
sbit LCD_D6_Direction at TRISD2_bit;
sbit LCD_D7_Direction at TRISD3_bit;
// End LCD module connections

static DRINK s_Drink;
static char  s_nCoin = 0;                     // set value at 0

static char s_aPrice[] = {
    50  /* Orange Juice */          //setting DRINK prices
  , 50  /* Fizzy Drink  */
  , 75  /* Water        */
  , 80  /* Tea          */
  , 90  /* Coffee       */
  , 65  /* Chocolate    */
  , 70  /* Soup         */
};

void setDrink(    //---  extern file is called or h files
                  // these are  global methods
  DRINK drink                                    // these methods relate to which extern call-- setting that DRINK into the variable setDrink.
) {
  s_Drink = drink;
}

char getPrice(
) {
  return s_aPrice[s_Drink];
}
void setCoin(                   // set the value of the coin using the set coin command
  char nCoin
) {
  s_nCoin = nCoin;
}

char getCoin() {          // return coin using the getCoin command
  return s_nCoin;
}

char getChange() {
  return s_nCoin - s_aPrice[s_Drink];
}

void main() {
  Lcd_Init();

  PORTD = 0xFF;        // the portd is set to 11111 when trid d is 11111?
  TRISD = 0xFF;
  TRISB = 0;

  /*State_SetDrink(); */
  while (1) {
    State_Run();
  }
}