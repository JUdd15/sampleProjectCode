/*******************************************************************************
*Author: J Uddin
*Date: 02/01/2015
*Filename : DrinksDispenser1
*Purpose: To code in C a drinks dispenser that will simulate the dispensing of
* hot and cold drinks
*******************************************************************************/
#include "DrinkDispensing.h"
#include "state.h"

#include "state.h"
#include "DrinkDispensing.h"
#include "menu.h"

static void stateHotDrinks() {                                         // case switching again to order drinks
  Menu_Clear();
  Menu_Add("Tea");
  Menu_Add("Coffee");
  Menu_Add("Chocolate");
  Menu_Add("Soup");
  switch (Menu_GetSelection()) {                                        // **Switch** Menu_GetSelection will select the hot DRINK selection into the variable
  case 0: {
    setDrink(DRINK_TEA);
    State_SetInsertCoin();
    return;
  }
  break;

  case 1: {
    setDrink(DRINK_COFFEE);
    State_SetInsertCoin();
    return;
  }
  break;

  case 2: {
    setDrink(DRINK_CHOCOLATE);
    State_SetInsertCoin();
    return;
  }
  break;

  case 3: {
    setDrink(DRINK_SOUP);
    State_SetInsertCoin();
    return;
  }
  break;
  }
}

void State_SetHotDrinks() {                                      // sets the hot DRINK in the variable using the sethotDrink command and passing the value of the hot DRINK into the parameter
  State_Set(stateHotDrinks);
}