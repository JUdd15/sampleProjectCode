/*******************************************************************************
*Author: J Uddin
*Date: 02/01/2015
*Filename : DrinksDispenser1
*Purpose: To code in C a drinks dispenser that will simulate the dispensing of
* hot and cold drinks
*******************************************************************************/
#ifndef __MENU_H__
#define __MENU_H__

extern void Menu_Clear();                                               //external method for menu clear.....

/*Yet to see if the hungarian notation will work on this?*/
extern void Menu_Add(char* pszMenu);                                    // menu _add is a pointer to a char obj to menu
extern char Menu_GetSelection();

extern void Menu_Display(char* pszText);

#endif /* __MENU_H__ */