/*******************************************************************************
*Author: J Uddin
*Date: 02/01/2015
*Filename : DrinksDispenser1
*Purpose: To code in C a drinks dispenser that will simulate the dispensing of
* hot and cold drinks
*******************************************************************************/
#include "DrinkDispensing.h"
#include "state.h"
#include "menu.h"

//static char szItem0[] = "Cold Drinks";
//static char szItem1[] = "Hot  Drinks";

static void stateMainMenu() {                     // setting up states
  Menu_Clear();                                  // clears menu
  Menu_Add("Cold Drinks");                        //add cold drinks
  Menu_Add("Hot  Drinks");                        // adding hot drinks
  switch (Menu_GetSelection()) {                    //user selection
  case 0: {
    State_SetColdDrinks();                        // using case switching set cold drinks
    return;
  }
  break;

  case 1: {
    State_SetHotDrinks();                          // using case again to set hot drinks
    return;
  }
  break;
  }
}

void State_SetMainMenu() {
  State_Set(stateMainMenu);
}