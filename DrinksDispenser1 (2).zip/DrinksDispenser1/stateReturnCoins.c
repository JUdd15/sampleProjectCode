/*******************************************************************************
*Author: J Uddin
*Date: 02/01/2015
*Filename : DrinksDispenser1
*Purpose: To code in C a drinks dispenser that will simulate the dispensing of
* hot and cold drinks
*******************************************************************************/
#include "state.h"

static void stateReturnCoin() {
  /* TODO: Return coin(s) if any */

  State_SetMainMenu();                        //function for coin return
}
                                              // balance = insertedcoins + balance;
                                              // put in x coins .....returns the difference
void State_SetReturnCoin() {
  State_Set(stateReturnCoin);
}