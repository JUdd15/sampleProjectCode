/*******************************************************************************
*Author: J Uddin
*Date: 02/01/2015
*Filename : DrinksDispenser1
*Purpose: To code in C a drinks dispenser that will simulate the dispensing of
* Hot and cold drinks
*******************************************************************************/
#ifndef __DRINKDISPENSER_H__
#define __DRINKDISPENSER_H__
// BUTTON_CURSORUP and BUTTON_CURSOR_DOWN for move up and down
// Currently using PORTC
#define BUTTON_CURSORUP()   Button(&PORTD, 0, 1, 1)                     // define will do button cursor
#define BUTTON_CURSORDOWN() Button(&PORTD, 1, 1, 1)
#define BUTTON_SELECT()     Button(&PORTD, 2, 1, 1)
#define BUTTON_PAGEPREV()   Button(&PORTD, 3, 1, 1)                     // Previous page
#define BUTTON_PAGENEXT()   Button(&PORTD, 4, 1, 1)                     // Next page
#define BUTTON_COIN5P()     Button(&PORTD, 0, 1, 1)
#define BUTTON_COIN10P()    Button(&PORTD, 1, 1, 1)
#define BUTTON_COIN20P()    Button(&PORTD, 2, 1, 1)
#define BUTTON_COIN50P()    Button(&PORTD, 3, 1, 1)
#define BUTTON_COIN1()      Button(&PORTD, 4, 1, 1)

#define ID_PREVPAGE -1
#define ID_NEXTPAGE -2

#if 0
#define LED_BLINK() do { \                                              
  PORTD = 0x00;          \
  Delay_ms(500);         \
  PORTD = 0xFF;          \
  Delay_ms(500);         \
} while (0)
#endif
  
typedef enum tagDRINK {
  /* Cold Drinks */                                                      // this file relates to the the other files using extern a global variable to share the code between different files
    DRINK_ORANGEJUS = 0                                                   // Cold drinks list
  , DRINK_FIZZY
  , DRINK_WATER

  /* Hot Drinks */
  , DRINK_TEA
  , DRINK_COFFEE                                                        // hot DRINK list
  , DRINK_CHOCOLATE
  , DRINK_SOUP
} DRINK;

extern void setDrink(
  DRINK drink
);

extern char getPrice();

extern void setCoin(
  char nCoin
);

extern char getCoin();

extern char getChange();

#endif /* __DRINKDISPENSER_H__ */