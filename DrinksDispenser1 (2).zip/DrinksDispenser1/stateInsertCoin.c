/*******************************************************************************
*Author: J Uddin
*Date: 02/01/2015
*Filename : DrinksDispenser1
*Purpose: To code in C a drinks dispenser that will simulate the dispensing of
* hot and cold drinks
*******************************************************************************/
#include "state.h"
#include "DrinkDispensing.h"
#include "menu.h"

static void stateInsertCoin() {
  int nDelay  = 5000; /* 5 sec */                       // initialised variables time delay
                                                        // as well as getPrice? from extern h file??
  char nPrice = getPrice();

  Menu_Display("Please insert coin(s)");
                                                      // --nDelay
  while (--nDelay) {                                   //set up buttons as price
    char nCoin = 0;                                   // your while loop to run the coin insertion events??

    if (BUTTON_COIN5P()) {
      nCoin += 5;
    }

    if (BUTTON_COIN10P()) {                            // add 10 pence
      nCoin += 10;
    }
                                                        // add 10 pence
    if (BUTTON_COIN20P()) {
      nCoin += 20;
    }
                                                         // add 50 pence
    if (BUTTON_COIN50P()) {
      nCoin += 50;
    }

    if (BUTTON_COIN1()) {                                 // add 1.00 pound
      nCoin += 100;
    }

    if (nCoin >= nPrice) {
      State_SetDrinkDispensed();                           // if the coin is greater than or equal to nPrice it will return set_drinkdispensed
      return;
    }

    Delay_ms(1);                                               // delay agiain
  }

  /*  Not enough coin in 5 sec */                               // not enough coins inserted in 5 seconds ....Delay
                                                                // you would have to run the return coin method?
  State_SetReturnCoin();
}

void State_SetInsertCoin() {
  State_Set(stateInsertCoin);
}