#include "DrinkDispensing.h"
#include "state.h"
#include "menu.h"

//static char szItem0[] = "Cold Drinks";
//static char szItem1[] = "Hot  Drinks";

static void stateDrink1() {                     // setting up states
  Menu_Clear();                                  // clears menu
  Menu_Add("Orange Juice");                        //add cold drinks
  Menu_Add("Fizzy Drink");                        // adding hot drinks
  switch (Menu_GetSelection()) {                    //user selection
  case 0: {
    setDrink(DRINK_FIZZY);
    State_SetInsertCoin();
    return;
  }
  break;

  case 1: {
    setDrink(DRINK_FIZZY);
    State_SetInsertCoin();
    return;
  }
  break;
  
  case ID_PREVPAGE: {
       // no prev page
  }
  break;
  
  case ID_NEXTPAGE: {
       //State_SetDrink2();
       return;
  }
  break;
  }
}

void State_SetDrink1() {
  State_Set(stateDrink1);
}