package graph;

/**
 * Graph errors.
 * 
 * 
 * @version December 2014
 */
public class GraphError extends RuntimeException {
	/**
	 * 
	 */
	private static final long serialVersionUID = 835254035854486066L;

	public GraphError() {
		super("Unspecified graph error");
	}

	public GraphError(String message) {
		super(message);
	}
}