Mazes are built from graphs.  This package defines the basic functionality of graphs.  It, incidentally, makes
use of the "jung" package to provide the visual representation of graphs.  The classes in this package are:
  - DirectedGraph: the basic graph package - defines most of the basic methods for graphs (e.g. add, remove, contains, ...)
  - UndirectedGraph: mazes are undirected (you can follow a link in either direction)
  - LabelledGraph: adds a facility for labelling nodes with Strings through the methods declareLabel, undeclareLabel, label, unlabel, 
    getNodesLabelledWith, getLabelsAttachedTo, isLabelForNode