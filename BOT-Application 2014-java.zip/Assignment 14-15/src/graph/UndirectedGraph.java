package graph;

import edu.uci.ics.jung.graph.util.EdgeType;

/**
 * Implementation of undirected graphs (i.e. all links are bidirectional).
 * 
 * 
 * @version November 2013
 * 
 * @param <Node>
 *            the type of node in this graph
 */
public class UndirectedGraph<Node> extends DirectedGraph<Node> {
	@Override
	public void add(Node start, Node end) {
		// do not add the link if it is already there (added from end<s==>start)
		if (!contains(start, end)) {
			super.add(start, end, EdgeType.UNDIRECTED);
		}
		// if start and end are different then also add the link in the other
		// direction
		if (!start.equals(end) && !contains(end, start)) {
			super.add(end, start, EdgeType.UNDIRECTED);
		}
	}

	@Override
	protected void add(String name, Node start, Node end) {
		addEdge(name, start, end, EdgeType.UNDIRECTED);
	}

}