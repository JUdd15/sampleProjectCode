package graph;

/**
 * Allows additional information, in the form of String labels, to be attached to nodes
 * in an undirected graph
 * 
 * @author Hugh Osborne
 * @version November 2013
 *
 * @param <Node> the type of node in the graph
 */

import java.util.HashSet;
import java.util.Hashtable;
import java.util.Set;

public class LabelledGraph<Node> extends UndirectedGraph<Node> {

	// Labelling is tracked by mapping labels to the set of nodes labelled by
	// those labels
	private Hashtable<String, HashSet<Node>> labelMap = new Hashtable<String, HashSet<Node>>();

	/**
	 * Declare a label. Labels must be declared before they can be used. It is
	 * an error to try to declare a label that has already previously been
	 * declared.
	 * 
	 * @param label
	 *            the label to be declared
	 */
	public void declareLabel(String label) {
		if (exists(label)) { // if the label already exists
			throw new GraphError("Cannot declare " + label
					+ ".  It already exists."); // it is an error to try to add
												// it
		}
		labelMap.put(label, new HashSet<Node>()); // add the label to the label
													// map, mapping to an empty
													// set (no nodes are yet
													// labelled with this label)
	}

	/**
	 * Undeclare a label. Labels can only be undeclared if they are no longer in
	 * use. It is also an error to try to undeclare a label that does not exist.
	 * 
	 * @param label
	 *            the label to be undeclared
	 */
	public void undeclareLabel(String label) {
		if (!exists(label)) { // if the label doesn't exist
			throw new GraphError("Cannot undeclare " + label
					+ ". Label dooes not exist."); // it is an error to try to
													// undeclare it
		}
		if (!labelMap.get(label).isEmpty()) { // if the label exists but is in
												// use (maps to a non-empty set
												// of nodes)
			throw new GraphError("Cannot undeclare " + label
					+ ". It is still in use."); // it is an error to undeclare
												// it
		}
		labelMap.remove(label); // remove the label from the label map
	}

	/**
	 * Test if a label exists in the graph.
	 * 
	 * @param label
	 *            the label to be tested for membership of the graph
	 * @return true iff the label exists (has been declared)
	 */
	public boolean exists(String label) {
		return labelMap.keySet().contains(label);
	}

	/**
	 * Test if a label labels a given node.
	 * 
	 * @param label
	 *            the label being looked for
	 * @param the
	 *            node to be checked
	 * @return true iff the label is a label attached to the node
	 */
	public boolean isLabelForNode(String label, Node node) {
		return exists(label) && labelMap.get(label).contains(node);
	}

	@Override
	/**
	 * Remove a node from the graph.  This method from the superclass needs to be overridden because it now needs to
	 * maintain the administration of the label map.  When a node is removed from the graph it will also be 
	 * removed from all entries in the label map.
	 * 
	 *  @param node the node to be removed from the graph
	 */
	public void remove(Node node) {
		super.remove(node);
		for (String label : labelMap.keySet()) { // for each current label
			labelMap.get(label).remove(node); // remove the node from its node
												// set
		}
	}

	/**
	 * Add a label to a node. It is an error to try to use a label that has not
	 * been declared, or to try to label a node with a label with which it is
	 * already labelled.
	 * 
	 * @param node
	 *            the node to be labelled
	 * @param label
	 *            the label the node is to be labelled with
	 */
	public void label(Node node, String label) {
		if (!exists(label)) { // if the label does not exist
			throw new GraphError("Cannot label " + node + " with " + label
					+ ".  The label has not been declared."); // it is an error
																// to try to use
																// it
		}
		if (isLabelForNode(label, node)) { // if this label already labels this
											// node
			throw new GraphError("Cannot label " + node + " with " + label
					+ ".  This node is already labelled with this label."); // it
																			// is
																			// an
																			// error
																			// to
																			// try
																			// to
																			// label
																			// it
																			// again
		}
		labelMap.get(label).add(node); // add the node to this label's node set
	}

	/**
	 * Remove a label from a node. It is an error to try to remove a label from
	 * a node when that node is not labelled with that label.
	 * 
	 * @param node
	 *            the node the label is to be removed from
	 * @param label
	 *            the label to be removed
	 */
	public void unlabel(Node node, String label) {
		if (!isLabelForNode(label, node)) { // if the label does not label this
											// node
			throw new GraphError("Cannot remove label " + label + " from "
					+ node
					+ ".  This node is not currently labelled with this label.");
		}
		labelMap.get(label).remove(node); // remove this node from this label's
											// node set
	}

	/**
	 * Get the set of nodes labelled with this label. A new set is created to
	 * avoid unwanted changes to the label map.
	 * 
	 * @param label
	 *            the label for which the set of labelled nodes will be returned
	 * @return a set of the nodes labelled with this label
	 */
	public Set<Node> getNodesLabelledWith(String label) {
		HashSet<Node> labelledNodes = new HashSet<Node>();
		for (Node node : labelMap.get(label)) {
			labelledNodes.add(node);
		}
		return labelledNodes;
	}

	/**
	 * Get the set of label currently attached to a node.
	 * 
	 * @param node
	 *            the node for which the set of attached labels will be returned
	 * @return a set of the labels attached to this node
	 */
	public Set<String> getLabelsAttachedTo(Node node) {
		HashSet<String> attachedLabels = new HashSet<String>();
		for (String label : labelMap.keySet()) { // for all the labels
			if (isLabelForNode(label, node)) { // if the label labels this node
				attachedLabels.add(label); // add it to the set
			}
		}
		return attachedLabels;
	}

	private final static String EMPTY_SET = "\u2205";

	@Override
	protected String nodeLabel(Node node) {
		Set<String> attachedLabels = getLabelsAttachedTo(node);
		String labelString = attachedLabels.toString();
		return (attachedLabels.size() == 0 ? EMPTY_SET : "{"
				+ labelString.substring(1, labelString.length() - 1) + "}")
				+ "," + super.nodeLabel(node);
	}

}
