package graph;

/**
 * An implementation of graphs using adjacency lists
 * 
 * @author Hugh Osborne
 * @version November 2013
 * 
 * @param Node the type of node in the graph
 */

// Will use a hashtable to implement the adjacency list
import java.awt.BasicStroke;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Paint;
import java.awt.Shape;
import java.awt.Stroke;
import java.awt.geom.Ellipse2D;
import java.util.Hashtable;
// The hashtable will map nodes to sets of nodes
import java.util.Set;
// Use hashsets as the implementation of sets
import java.util.HashSet;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import org.apache.commons.collections15.Transformer;

import edu.uci.ics.jung.algorithms.layout.CircleLayout;
import edu.uci.ics.jung.algorithms.layout.Layout;
import edu.uci.ics.jung.graph.util.EdgeType;
import edu.uci.ics.jung.visualization.BasicVisualizationServer;
import edu.uci.ics.jung.visualization.renderers.Renderer.VertexLabel.Position;
import map.MapError;

public class DirectedGraph<Node> extends
		edu.uci.ics.jung.graph.SparseMultigraph<Node, String> {
	private String edgeName(Node start, Node end) {
		return start.toString() + "==>" + end.toString();
	}

	/**
	 * @return (<tt>node</tt> is a node in this graph)
	 */
	public boolean contains(Node node) {
		return containsVertex(node);
	}

	/**
	 * @return (there is an edge from <tt>start</tt> to <tt>end</tt> in this
	 *         graph)
	 */
	public boolean contains(Node start, Node end) {
		// check that both nodes are in the graph, and then check that "end" is
		// in
		// "start"'s entry in the adjacency list
		return contains(start) && contains(end)
				&& containsEdge(edgeName(start, end));
	}

	/**
	 * Add node <tt>node</tt> to the graph
	 */
	public void add(Node node) {
		if (contains(node)) {
			throw new GraphError("Cannot add " + node
					+ " to the graph.  This node is already in the graph.");
		} else {
			addVertex(node);
		}
	}

	/**
	 * Remove node <tt>node</tt>, and all edges leading to and from it, from
	 * this graph
	 */
	public void remove(Node node) {
		if (!contains(node)) {
			throw new GraphError("Cannot remove " + node
					+ " from the graph.  No such node.");
		} else {
			removeVertex(node);
			for (Node start : getVertices()) {
				if (contains(start, node)) {
					remove(start, node);
				}
			}
		}
	}

	/**
	 * Add an edge from <tt>start</tt> to <tt>end</tt> to this graph
	 */
	public void add(Node start, Node end) {
		add(start, end, EdgeType.DIRECTED);
	}

	public void add(Node start, Node end, EdgeType edgeType) throws GraphError {
		if (contains(start, end)) {
			throw new GraphError("Cannot add " + start + "==>" + end
					+ " to the graph.  This link is already in the graph.");
		} else if (!contains(start) || !contains(end)) {
			throw new GraphError(
					"Cannot add "
							+ start
							+ "==>"
							+ end
							+ " to the graph.  One or more of the nodes is not in the graph.");
		} else {
			super.addEdge(edgeName(start, end), start, end, edgeType);
		}
	}

	protected void add(String name, Node start, Node end) {
		super.addEdge(name, start, end, EdgeType.DIRECTED);
	}

	/**
	 * Remove the edge from <tt>start</tt> to </tt>end</tt> from the graph
	 */
	public void remove(Node start, Node end) {
		if (!contains(start, end)) {
			throw new GraphError("Cannot remove " + start + "==>" + end
					+ " from the graph.  There is no such edge in the graph.");
		} else {
			removeEdge(edgeName(start, end));
		}
	}

	/**
	 * @return a set of the immediate successors of node <tt>node</tt>
	 */
	public Set<Node> getNeighbours(Node node) {
		// The neighbours can be accessed through this node's entry in the
		// adjacency list.
		// Note: Create a copy of the entry to avoid users being able to change
		// the adjacency list.
		Set<Node> copy = new HashSet<Node>();
		for (Node member : getSuccessors(node)) {
			copy.add(member);
		}
		return copy;
	}

	/**
	 * @return the number of nodes currently in this graph
	 */
	public int noOfNodes() {
		return getVertexCount();
	}

	/**
	 * @return a set of the nodes in the graph
	 */
	public Set<Node> getNodes() {
		// Note: The nodes can be accessed through the adjacency list's key set.
		// Note: Create a copy of the key set to avoid users being able to
		// change the adjacency list
		Set<Node> copy = new HashSet<Node>();
		for (Node member : getVertices()) {
			copy.add(member);
		}
		return copy;
	}

	/**
	 * @return the number of edges currently in this graph
	 */
	public int noOfEdges() {
		return getEdgeCount();
	}

	protected Paint nodeColour(Node node) {
		return Color.cyan;
	}

	private Transformer<Node, Paint> vertexPaint = new Transformer<Node, Paint>() {
		public Paint transform(Node node) {
			return nodeColour(node);
		}
	};

	protected Shape nodeShape(Node node) {
		return new Ellipse2D.Double(-10, -10, 20, 20);
	}

	private Transformer<Node, Shape> vertexShape = new Transformer<Node, Shape>() {
		public Shape transform(Node node) {
			return nodeShape(node);
		}
	};

	private Transformer<Node, Stroke> edgeStrokeTransformer = new Transformer<Node, Stroke>() {
		public Stroke transform(Node cn) {
			return new BasicStroke(1.0f);
		}
	};

	protected String nodeLabel(Node node) throws MapError {
		return node.toString();
	}

	private Transformer<Node, String> nodeLabelTransform = new Transformer<Node, String>() {
		public String transform(Node node) {
			try {
				return nodeLabel(node);
			} catch (MapError e) {
				// TODO Auto-generated catch block
				return "?";
			}
		}
	};

	public void show() {
		JFrame frame = new JFrame();
		final Layout<Node, String> layout = new CircleLayout<Node, String>(this);
		BasicVisualizationServer<Node, String> viewer = new BasicVisualizationServer<Node, String>(
				layout);
		viewer.getRenderContext().setVertexFillPaintTransformer(vertexPaint);
		viewer.getRenderContext().setVertexShapeTransformer(vertexShape);
		viewer.getRenderContext().setVertexLabelTransformer(nodeLabelTransform);
		viewer.getRenderContext().setVertexStrokeTransformer(
				edgeStrokeTransformer);
		viewer.getRenderer().getVertexLabelRenderer().setPosition(Position.N);
		frame.getContentPane().add(viewer);

		JPanel panel = new JPanel();
		frame.getContentPane().add(panel, BorderLayout.SOUTH);

		JLabel lblRed = new JLabel("Red square - Entrance");
		lblRed.setForeground(Color.RED);
		lblRed.setBackground(Color.BLACK);
		lblRed.setOpaque(true);
		panel.add(lblRed);

		JLabel lblBoth = new JLabel("Orange octagon - Entrance & Exit");
		lblBoth.setForeground(Color.ORANGE);
		lblBoth.setBackground(Color.BLACK);
		lblBoth.setOpaque(true);
		panel.add(lblBoth);

		JLabel lblExit = new JLabel("Yellow rhombus - Exit");
		lblExit.setForeground(Color.YELLOW);
		lblExit.setBackground(Color.BLACK);
		lblExit.setOpaque(true);
		panel.add(lblExit);

		frame.getContentPane().add(viewer, BorderLayout.NORTH);

		JPanel panel_1 = new JPanel();
		frame.getContentPane().add(panel_1, BorderLayout.WEST);
		frame.pack();
		frame.setTitle("Maze View");
		frame.setResizable(true);
		frame.setVisible(true);
	}
}