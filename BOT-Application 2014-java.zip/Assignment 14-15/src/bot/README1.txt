

Log of work:

Config build path --- done by deleting the package and reuploading via eclipse---


This lead to problems with the ChallengeMapped error that stated --- 

"Exception in thread "AWT-EventQueue-0" map.MapError$FileAccess: File access error.Test file subfolder ChallengeMAPPED does not exist.
	at tests.MazeTest$Challenge.getMaze(MazeTest.java:325)"
	
	After inserting system.out--- a result was obtained that stated--- "C:\Users\ram\Documents\TestFolder\ChallengeMAPPED" where eclipse was trying to reference
	the above folder but could not find it and this resulted in the excepetion error----
	
	
	