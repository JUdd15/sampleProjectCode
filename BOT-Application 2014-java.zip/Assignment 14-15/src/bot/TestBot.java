package bot;

import java.util.Set;

import map.MazeMap;
import maze.Maze;
import util.RandomAccess;

/**
 * An example of a bot implementation. These bots simply choose a neighbouring
 * node at random. They will leave the maze if they happen to reach an exit
 * node.
 * 
 * 
 * @version November 2014
 */
public class TestBot extends Bot {
	private MazeMap map;

	public TestBot(String name, Maze maze) {
		super(name, maze);
	}

	/**
	 * Enter node traces the bots arrival, and leaves the maze if the node is an
	 * exit node.
	 * 
	 * @throws UserError
	 * @throws MazeError
	 */
	@Override
	public void enterNodeActions() throws UserError {
		String location = getLocation();
		trace("Arrived at " + location);
		if (map.isExitNode(location)) {
			trace(location + " is an exit node - leaving");
			leaveMaze();
		}
	}

	/**
	 * Choose a random node from the bot's neighbouring nodes
	 * 
	 * @throws UserError
	 */
	@Override
	public String chooseNextNode() throws UserError {
		Set<String> neighbours = map.getNeighbours(getLocation());
		String chosen = RandomAccess.getRandomEntry(neighbours);
		trace("Chose " + chosen + " as next node.");
		return chosen;
	}

	/**
	 * Trace the exit from the node
	 * 
	 * @throws MazeError
	 */
	@Override
	public void leaveNodeActions() throws UserError {
		trace("Leaving " + getLocation());
	}

	/**
	 * Trace entry into the maze.
	 */
	@Override
	public void enterMazeActions() throws UserError {
		trace("Entered the maze.");
		map = getMap();
	}

	/**
	 * Trace the exit from the maze
	 */
	@Override
	public void leaveMazeActions() throws UserError {
		trace("Leaving the maze.");
	}

	/**
	 * Notify death
	 */
	@Override
	public void deathbedActions() throws UserError {
		trace("Aargh, I'm dying.");
	}
}