package bot;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Set;

import map.MazeMap;
import maze.Maze;
import resource.ResourceAdjustment;
import resource.ResourceLevel;
import resource.ResourceLevel.Exhausted;

/**
 * This is a placeholder implementation for Bot1 which just implements Bot1 as a
 * random bot. You should alter this implementation to provide a correct
 * implementation for bots in challenge 1 mazes.
 * 
 * 
 * @version December 2013
 */
public class SearcherBot extends RandomBot {
	public SearcherBot(String name, Maze maze) {
		super(name, maze);
	}

	private List<MapNode<ResourceLevel>> shortestRoute;
	private Queue<List<MapNode<ResourceLevel>>> toDo;
	private Set<String> visited = new HashSet<String>();
	private Map<String, ResourceLevel> visitedWith = new HashMap<String, ResourceLevel>();

	@Override
	public void enterMazeActions() throws UserError {
		super.enterMazeActions();
		shortestRoute = findRoute();
	}

	/**
	 * Perform a breadth first traversal of the maze. Rather than just storing
	 * the nodes visited, store the paths that would be taken to these nodes.
	 * Since this is a breadth first traversal, the first exit node found will
	 * be at the end of a shortest path to an exit node. New paths are added to
	 * the to do list if they lead to a node that has not already been visited
	 * with the same, or higher resources. Paths that would kill the bot are,
	 * obviously, also not added to the to do list.
	 * 
	 * @return a shortest path to an exit
	 */
	private List<MapNode<ResourceLevel>> findRoute() throws UserError {
		trace("Looking for route");

		MazeMap map = getMap();
		// Populate the to do list with a path consisting only of the current
		// node
		// First, create an empty to do list
		toDo = new ArrayDeque<List<MapNode<ResourceLevel>>>();
		// Now create an empty initial route
		List<MapNode<ResourceLevel>> initialRoute = new ArrayList<MapNode<ResourceLevel>>();
		// Create a map node containing the current location's name, and the
		// bot's current resource level
		ResourceLevel resources = getResourceLevel();
		try {
			resources.adjust(getResourceAdjustment());
		} catch (Exhausted e1) {
			throw new UserError(
					"Entry node would exhuast bot's resources.  This shouldn't happen");
		}
		MapNode<ResourceLevel> initialNode = new MapNode<ResourceLevel>(
				getLocation(), resources);
		// Add this node to the initial route
		initialRoute.add(initialNode);
		// Add the initial route too the to do list
		toDo.add(initialRoute);

		// Now start the breadth first traversal
		while (!toDo.isEmpty()) {
			// Get the route that is at the head of the to do list - this is the
			// next one to look at
			List<MapNode<ResourceLevel>> currentRoute = toDo.remove();
			// Get the node at the end of the route - the bot needs to try to
			// extend the route from here
			MapNode<ResourceLevel> currentNode = currentRoute.get(currentRoute
					.size() - 1);
			// Get the node's name
			String currentLocation = currentNode.getNode();
			// If this is an exit node, we have found a shortest route
			if (map.isExitNode(currentLocation)) {
				trace("Found route" + currentRoute);
				return currentRoute;
			}
			// Find out what the resource level will be on reaching this node
			ResourceLevel currentLevel = currentNode.getProperty();
			for (String neighbour : map.getNeighbours(currentLocation)) {
				ResourceAdjustment adjustment = map
						.getResourceAdjustment(neighbour);
				ResourceLevel newLevel = currentLevel.copyOf();
				try {
					newLevel.adjust(adjustment);
					if (!visited.contains(neighbour)
							|| visitedWith.get(neighbour).getValue() < newLevel
									.getValue()) {
						List<MapNode<ResourceLevel>> newRoute = new ArrayList<MapNode<ResourceLevel>>();
						newRoute.addAll(currentRoute);
						newRoute.add(new MapNode<ResourceLevel>(neighbour,
								newLevel));
						if (map.isExitNode(neighbour)) {
							trace("Found route: " + newRoute);
							return newRoute;
						} else {
							toDo.add(newRoute);
						}
					}
				} catch (Exhausted e) {
					// don't extend the route if we would run out of resources
				}
			}
		}
		throw new UserError("Oops: to do list ran out.");
	}

	private int routeIndex = 1;

	@Override
	public String chooseNextNode() throws UserError {
		if (routeIndex >= shortestRoute.size()) {
			throw new UserError("Oops: ran past end of shortest route.");
		} else {
			String next = shortestRoute.get(routeIndex++).getNode();
			trace("Chosen " + next);
			return next;
		}
	}
}