This package implements bots.  This is where you should create your own
bot for the additional question.  A placeholder implementation of this bot is already
included in this package (as ExplorerBot), but this bot simply makes a random choice of 
which node to go to next.  You should replace this bot with your own implementations 
that show more intelligent behaviour, in searching and traversing the maze.

The other classes in this package are:
 - Bot.  Provides the basic functionality of bots, allowing bots to query
   mazes about nodes in the maze.  A bot can always find out:
     - the name of its current location: String getLocation()
     - the resource adjustment in force at its current location: ResourceAdjustment getResourceAdjustment()
     - the names of its current location's immediate neighbours, and the resource adjustments in force at
       those locations (this information is returned as a Map - a set containing the names of the neighbouring 
       locations can be obtained by using the Map's keySet() method, and the resource adjustments can then
       be retrieved using the Map's get() method): Map<String,ResourceAdjustment> getNeighbours()
   The Bot class also defines a number of abstract methods (at the top of the source code) that all 
   bots must implement.  These methods define the behaviour of the bots.
 - RandomBot.  An implementation of Bot.  A RandomBot does not perform any
   analysis or exploration of the maze but at each node just makes a random
   choice of which node to go to next.  It does implement all the required 
   methods and implements basic tracing of the bot's behaviour.
 - SearcherBot.  An implementation of a bot that will find the shortest route to an
   exit node in a maze for which a full map is always available - i.e. a MappedMaze.
 - ExplorerBot.  This is the bot that is used to try to solve unmapped mazes.  It is
   currently implemented simply as a RandomBot.  You should change the implementation so that
   explorer bots will explore mazes, and build up a map of the maze for future bots to#
   use.
 - MapNode.  This class is used by searcher bots as they search for a shortest route in the
   maze map.  A MapNode is a pair containing a location name and information related to that
   location.  In searcher bots this information is information about the resource level the
   bot would have on reaching that node.