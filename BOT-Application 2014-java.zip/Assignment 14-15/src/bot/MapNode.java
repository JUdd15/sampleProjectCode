package bot;

public class MapNode<T> {
	private String node;
	private T property;

	protected MapNode(String node, T property) {
		this.node = node;
		this.property = property;
	}

	protected String getNode() {
		return node;
	}

	protected T getProperty() {
		return property;
	}

	@Override
	public String toString() {
		return node + "(" + property + ")";
	}
}
