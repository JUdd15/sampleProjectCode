package bot;

import java.util.Map;

import javax.swing.JOptionPane;

import map.MazeMap;
import maze.Maze;
import resource.ResourceAdjustment;
import resource.ResourceLevel;
import resource.ResourceLevel.Exhausted;
import tests.MazeTest;

/**
 * Provides bot structure, with administrative functions
 * 
 * This abstract class starts with a number of abstract methods which need to be
 * implemented bu bots. The implementations of these methods will determine the
 * bot's behaviour.
 * 
 * 
 * @version November 2014
 */
public abstract class Bot {
	// There now follow a number of abstract methods that need to be implemented
	// by bots
	// The implementations of these methods will determine the bot's behaviour

	/**
	 * To be implemented as part of the assignment. This method should define
	 * the actions that the bot should perform when entering a node in the
	 * graph. These actions will take place <i>before</i> the bot's resources
	 * are adjusted by the node and/or by a deal with another bot. This method
	 * is for updating any data structures you may be using. It could also be
	 * used as part of a trace of the bot's actions.
	 */
	public abstract void enterNodeActions() throws UserError;

	/**
	 * To be implemented as part of the assignment. This method should choose
	 * the (name of) the next node the bot wishes to go to. This method will be
	 * called <i>after</i> the bot's resources are adjusted by the node and/or a
	 * deal with another bot, but <i>before</i> <tt>leaveNodeActions</tt> is
	 * called. Returning a string that is not the name of a neighbouring node of
	 * the bot's current location will cause an error.
	 */
	public abstract String chooseNextNode() throws UserError;

	/**
	 * To be implemented as part of the assignment. This method should define
	 * the actions that the bot should perform just before leaving a node in the
	 * graph. These actions will take place <i>after</i> the bot's resources are
	 * adjusted by the node, and/or a deal with another bot.
	 */
	public abstract void leaveNodeActions() throws UserError;

	/**
	 * To be implemented as part of the assignment. This method should define
	 * the actions that the bot should perform when entering the maze. This does
	 * <i>not</i> include choosing an entry node. The graph will do that. These
	 * actions will take place <i>before</i> any <tt>enterNodeActions()</tt>
	 * executed when the bot enters its entry node. This method is for
	 * initialising any data structures you may want to use. It could also be
	 * used as part of a trace of the bot's actions.
	 */
	public abstract void enterMazeActions() throws UserError;

	/**
	 * To be implemented as part of the assignment. This method should define
	 * the actions that the bot should perform when it leaves the maze. This
	 * method could be used as part of a trace of the bot's actions. See the
	 * example Bot class provided for an example of implementing this method.
	 */
	public abstract void leaveMazeActions() throws UserError;

	/**
	 * To be implemented as part of the assignment. This method should define
	 * the actions that the bot should perform just before it dies. See the
	 * example Bot class provided for an example of implementing this method.
	 */
	public abstract void deathbedActions() throws UserError;

	// the name of this bot
	private String name;

	// the maze this bot is in
	protected Maze maze;

	// Tbe initial default resource level for bots
	private final static int DEFAULT_INITIAL_RESOURCE_LEVEL = 0;

	// the bot's current location
	private String location;

	// the bot's current resource level
	private ResourceLevel resourceLevel;

	// the number of nodes the bot has visited
	private int pathLength;

	// the length of the shortest possible path to an exit node
	private int shortestPathLength;

	// is the bot currently in the maze
	private boolean inMaze = false;

	/**
	 * Construct a bot with the given name, and inhabiting the given maze
	 */
	public Bot(String name, Maze maze) {
		this.name = name;
		this.maze = maze;
		resourceLevel = new ResourceLevel(DEFAULT_INITIAL_RESOURCE_LEVEL);
	}

	/**
	 * Run the bot through the maze
	 * 
	 * @throws Death
	 *             if the bot runs out of resources
	 */
	public void runBot() throws UserError, Death {
		startBot();
		while (inMaze) {
			moveBot();
		}
	}

	/**
	 * Start the bot in the maze
	 * 
	 * @throws Death
	 *             if the resource adjustment at the initial node kills the bot
	 */
	private void startBot() throws UserError, Death {
		location = maze.getEntryNode();
		shortestPathLength = maze.getShortestPathFrom(location);
		pathLength = 1; // path currently just the entry node
		enterMazeActions();
		inMaze = true;
		enterNode(location);
	}

	/**
	 * Enter a node
	 * 
	 * @throws Death
	 *             if visiting this node exhausts the bot's resources
	 */
	private void enterNode(String node) throws Death, UserError {
		location = node;
		enterNodeActions();
		try {
			resourceLevel.adjust(getResourceAdjustment());
		} catch (Exhausted exhausted) {
			die();
			throw new Death("Bot ran out of resources.");
		}
	}

	/**
	 * Move the bot
	 * 
	 * @throws Death
	 *             if this move would kill the bot
	 */
	private void moveBot() throws UserError, Death {
		String nextNode = chooseNextNode();
		leaveNodeActions();
		if (!maze.isValidMove(location, nextNode)) {
			throw new UserError("Cannot move to " + nextNode
					+ ".  There is no link from " + location + " to "
					+ nextNode + ".");
		}
		pathLength++;
		enterNode(nextNode);
	}

	/**
	 * Leave the maze
	 */
	public void leaveMaze() throws UserError {
		if (!maze.isAtExit(this)) {
			throw new UserError(
					"Bot cannot leave the maze.  It is not at an exit node.");
		}
		inMaze = false;
		leaveMazeActions();
	}

	/**
	 * Die
	 */
	public void die() throws UserError {
		inMaze = false;
		deathbedActions();
	}

	// Access methods

	/**
	 * @return this bot's name
	 */
	public final String getName() {
		return name;
	}

	/**
	 * Get the bot's current location.
	 * 
	 * @return the bot's current location
	 */
	public String getLocation() {
		return location;
	}

	/**
	 * Get the resource adjustment in force at the bot's location
	 */
	public ResourceAdjustment getResourceAdjustment() {
		return maze.getBotsResourceAdjustment(this);
	}

	/**
	 * Get the bot's current resource level.
	 * 
	 * @throws MazeError
	 */
	public ResourceLevel getResourceLevel() {
		return resourceLevel;
	}

	/**
	 * Get the length of the bot's current path
	 */
	public int getPathLength() {
		return pathLength; // maze.getBotsPathLength();
	}

	/**
	 * Get the shortest path length
	 */
	public int getShortestPathLength() {
		return shortestPathLength;
	}

	public Map<String, ResourceAdjustment> getNeighbours() {
		return maze.getBotsNeighbours(this);
	}

	/**
	 * Get a map of the maze
	 */
	public final MazeMap getMap() {
		return maze.getMap();
	}

	/**
	 * Leave a map in the maze
	 * 
	 * @throws MazeError
	 */
	public final void leaveMap(MazeMap map) {
		maze.leaveMap(map);
	}

	/**
	 * Defines the options for tracing a bot's behaviour. Current options are
	 * <ul>
	 * <li> <tt>OFF</tt> provide no trace
	 * <li> <tt>TERMINAL</tt> print trace to terminal
	 * <li> <tt>POP_UP</tt> display trace in a pop-up
	 * </ul>
	 * A trace is the <tt>String</tt> parameter of a call of the
	 * <tt>trace()</tt> method, annotated with information identifying this bot
	 * and its status. The default trace mode is <tt>OFF</tt>.
	 */
	public enum TraceMode {
		/**
		 * Switch off tracing.
		 */
		OFF,
		/**
		 * Print traces to the terminal
		 */
		TERMINAL,
		/**
		 * Show traces in pop-up windows
		 */
		POP_UP
	}

	// set the default trace mode (OFF)
	private static TraceMode traceMode = TraceMode.OFF;

	/**
	 * Set the trace mode for this bot. Current options are
	 * <ul>
	 * <li> <tt>OFF</tt> provide no trace
	 * <li> <tt>TERMINAL</tt> print trace to terminal
	 * <li> <tt>POP_UP</tt> display trace in a pop-up
	 * </ul>
	 * A trace is the <tt>String</tt> parameter of a call of the
	 * <tt>trace()</tt> method, annotated with information identifying this bot
	 * and its status.
	 * 
	 * @param newTraceMode
	 *            the new trace mode
	 */
	public static void setTraceMode(TraceMode newTraceMode) {
		traceMode = newTraceMode;
	}

	/**
	 * Switch off traces from bots.
	 */
	public static void setBotTraceOff() {
		setTraceMode(TraceMode.OFF);
	}

	/**
	 * Send bot traces to the terminal.
	 */
	public static void setBotTraceToTerminal() {
		setTraceMode(TraceMode.TERMINAL);
	}

	/**
	 * Report bot traces through pop-ups.
	 */
	public static void setBotTraceToPopUp() {
		setTraceMode(TraceMode.POP_UP);
	}

	/**
	 * Set the trace mode used to report test results. Current options are
	 * <ul>
	 * <li> <tt>OFF</tt> provide no trace
	 * <li> <tt>TERMINAL</tt> print trace to terminal
	 * <li> <tt>POP_UP</tt> display trace in a pop-up
	 * </ul>
	 * A trace is the <tt>String</tt> parameter of a call of the
	 * <tt>trace()</tt> method, annotated with information identifying this bot
	 * and its status.
	 * 
	 * @param newTraceMode
	 *            the new trace mode
	 */
	public static void setTestResultTraceMode(TraceMode newTraceMode) {
		MazeTest.setTraceMode(newTraceMode, newTraceMode);
	}

	/**
	 * Do not report test results.
	 */
	public static void setTestTraceOff() {
		setTestResultTraceMode(TraceMode.OFF);
	}

	/**
	 * Send test results to the terminal.
	 */
	public static void setTestTraceToTerminal() {
		setTestResultTraceMode(TraceMode.TERMINAL);
	}

	/**
	 * Report test results through pop-ups.
	 */
	public static void setTestTraceToPopUp() {
		setTestResultTraceMode(TraceMode.POP_UP);
	}

	@Override
	public String toString() {
		return name;
	}

	/**
	 * Produce a trace. Unless <tt>traceMode</tt> is set to <tt>OFF</tt> a trace
	 * will be produced consisting of information identifying this bot and its
	 * status, and the message specified.
	 * 
	 * @param info
	 *            the trace message to be produced
	 * @throws MazeError
	 * @throws BotError
	 *             if the bot is not at a node.
	 */
	public void trace(String info) {
		String location, resource, message;
		location = getLocation();
		resource = getResourceLevel().toString();
		message = "[Bot " + this + " at " + location + " with resource "
				+ resource + "]\n\t";
		message = (message + info).replaceAll("\\.", "\n\t");
		switch (traceMode) {
		case TERMINAL:
			System.out.println(message);
			break;
		case POP_UP:
			JOptionPane.showMessageDialog(null, message, getName(),
					JOptionPane.PLAIN_MESSAGE);
			break;
		}
	}

	/**
	 * Produce an error message. Unless <tt>traceMode</tt> is set to
	 * <tt>OFF</tt> a trace will be produced consisting of information
	 * identifying this bot and its status, and the message specified.
	 * 
	 * @param info
	 *            the trace message to be produced
	 * @throws MazeError
	 * @throws BotError
	 *             if the bot is not at a node.
	 */
	public final void error(String info) {
		String location, resource, message;
		location = getLocation();
		resource = getResourceLevel().toString();
		message = "***[Bot " + this + " at " + location + " witjh resource "
				+ resource + "]***\n\t";
		message = (message + info).replaceAll("\\.", "\n\t");
		switch (traceMode) {
		case TERMINAL:
			System.out.println(message);
			break;
		case POP_UP:
			JOptionPane.showMessageDialog(null, message, getName(),
					JOptionPane.ERROR_MESSAGE);
			break;
		}
	}

	public class Death extends Exception {
		/**
		 * 
		 */
		private static final long serialVersionUID = 1833650101025315677L;

		public Death() {
			super("Bot died");
			inMaze = false;
		}

		public Death(String reason) {
			super("Bot died: " + reason);
			inMaze = false;
		}
	}

	/**
	 * Report user errors
	 */
	public class UserError extends Exception {
		/**
		 * 
		 */
		private static final long serialVersionUID = 8468602157547399028L;

		public UserError() {
			super(
					"Bot error.This is probably due to an error in your programme.");
			inMaze = false;
		}

		public UserError(String reason) {
			super("Bot error." + reason
					+ "This is probably due to an error in your programme.");
			inMaze = false;
		}
	}
}
