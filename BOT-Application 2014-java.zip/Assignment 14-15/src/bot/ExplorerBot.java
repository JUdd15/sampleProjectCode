package bot;

/*The Bot explores the map with BFS and finds the exit route
 *Once it reaches the exit node, it works backwords and tries to optimize the path, trying to find the shortest path
 * findRoute() method does the BFS search
 * getShortestPath() finds the shortest path for the next bot to travel.
 *
 * Author : j Uddin
 * 
 *
*
 */
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Set;

import resource.ResourceAdjustment;
import resource.ResourceLevel;
import resource.ResourceLevel.Exhausted;
import bot.Bot.UserError;
import util.RandomAccess;
import map.MazeMap;
import maze.Maze;

public class ExplorerBot<T> extends Bot {
	private MazeMap visitedMap; //checks the visited nodes for BFS in findroute method for the current bot
	private static Queue<List<MapNode<ResourceLevel>>> toDoQueue = new ArrayDeque<List<MapNode<ResourceLevel>>>(); //Keeps the queue of nodes to travel and transfers the same to the next bot.
	private static ArrayList<String> visited = new ArrayList<String>();//visited nodes transferred to the next bot
	private String visitNext = null;//used to travel to the next node
	private String lastNode = null;//to check if it the last node in the tree, if it is last node, it will send the flow back to the parent node
	private static HashMap staticMap = new HashMap();//hashmap to keep track of the explored map
	private static Boolean continueWithAnotherBot;//if the next bot should start , where the previous bot left, this becomes true
	private ArrayList pathtravelledtoCurrentNode = new ArrayList();//path travelled by the current bot
	private ArrayList checkVisited = new ArrayList();//local variable used to check the visited nodes path , keeps its value for every node travelled.
	private static ArrayList pathToTravelByNewBot = new ArrayList();//the path to be travelled by the new bot once the exit node is found
	String entrancePath = null;//keeps track if the bot reached where it started, used for optimization.

	public ExplorerBot(String name, Maze maze) {
		// Calling the super class which will reference the Bot class
		super(name, maze);
		//the below code neutralizes the static values, used when a new test is called.
		if (this.getName().equals("UNMAPPED(1)")) {
			staticMap = new HashMap();
			pathToTravelByNewBot = new ArrayList();
			visited = new ArrayList<String>();
			toDoQueue = new ArrayDeque<List<MapNode<ResourceLevel>>>();
		}

	}

	@Override
	public void enterNodeActions() throws UserError {
		String location = getLocation();
		pathtravelledtoCurrentNode.add(this.getLocation()); //adds every node reached by the current bot to the list.
		checkVisited.add(this.getLocation());//used to check if the node was visited.
		if (maze.isAtExit(this)) {
			trace(location + " is an exit node - leaving");
			leaveMaze();
			pathtravelledtoCurrentNode.add("exit");//exit is added at the last for optimization
			pathToTravelByNewBot = getShortestPath(pathtravelledtoCurrentNode);//the path to be travelled by the next bot is transferred.
		}
		// trace("entering node:"+this.getName()+" location:"+this.getLocation()+"shortest path length:"+this.getShortestPathLength());
		if (maze.isAtEntrance(this)) {
			entrancePath = this.getLocation();//entrance node is saved for later use.
		}
	}

	@Override
	public String chooseNextNode() throws UserError {
		//trace("todo size:" + toDoQueue.size() + "toDo contains:" + toDoQueue);
		String value = null;
		if (pathToTravelByNewBot.size() > 1) {
			value = (String) pathToTravelByNewBot.get(1);
			pathToTravelByNewBot.remove(1);
		} else if (isLastNode()) {
			trace("this is last node going back to:" + lastNode);
			value = lastNode;
		}

		else if (visitNext != null) {
			value = visitNext;
			trace("coming inside visit next:" + visitNext);
			if (!getNeighbours().containsKey(value)) {
				
				value = lastNode;
				visited.add(value);
				visitNext = null;
			} else {
				visitNext = null;
				visited.add(value);
			}
		} else {
			findRoute();//BFS algorithm called to explore the map.
			//trace("toDO Queue:" + toDoQueue);

			value = toDoQueue.remove().get(0).getNode();
			if (!getNeighbours().containsKey(value)) {

				// trace("visted contians:"+checkVisited.size()+"current node:"+this.getLocation()+"neighbours:"+getNeighbours()+"-->visited array:"+checkVisited.size());
				visitNext = value;
				if (checkVisited.size() > 0)
					value = (String) checkVisited.get(checkVisited.size() - 1);

				if (value.equals(this.getLocation())
						&& (checkVisited.size() >= 2)) {
					value = (String) checkVisited.get(checkVisited.size() - 2);
				}

			}

		}
		// trace("value to go:"+value);
		lastNode = this.getLocation();
		return value;

	}

	@Override
	public void leaveNodeActions() throws UserError {
		// TODO Auto-generated method stub
		trace("Leaving " + getLocation());
	}

	@Override
	public void enterMazeActions() throws UserError {
		// TODO Auto-generated method stub
		// trace("ToDO queue contains:"+toDoQueue);
		// trace("Entered the maze.");
		if (continueWithAnotherBot != null && continueWithAnotherBot) {

			// trace("path to Travel by new bot:"+pathToTravelByNewBot);
			if (pathToTravelByNewBot.size() > 1)
				pathToTravelByNewBot.remove(pathToTravelByNewBot.size() - 1);

		}
		// map = getMap();

	}

	@Override
	public void leaveMazeActions() throws UserError {
		// TODO Auto-generated method stub
		trace("Leaving the maze.");

	}

	@Override
	public void deathbedActions() throws UserError {
		// TODO Auto-generated method stub
		continueWithAnotherBot = true;
		trace("dying---------.");
		// previousVisited=visited;
		pathToTravelByNewBot = pathtravelledtoCurrentNode;

	}

	private void findRoute() throws UserError {
		// trace("todo value in find route start:"+toDoQueue+"-->size:"+toDoQueue.size());
		List<MapNode<ResourceLevel>> initialRoute = new ArrayList<MapNode<ResourceLevel>>();
		ResourceLevel resources = getResourceLevel();
		try {
			resources.adjust(getResourceAdjustment());//adjusting the resources
		} catch (Exhausted e1) {
			throw new UserError(
					"Entry node would exhuast bot's resources.  This shouldn't happen");
		}
		MazeMap map = getMap();
		MapNode<ResourceLevel> initialNode = new MapNode<ResourceLevel>(
				getLocation(), resources);
		initialRoute.add(initialNode);
		Map neighbours = getNeighbours();//checking the neighbours , and putting all of them to the ToDo queue, if not already visited.
		Set<String> neighboursSet = new HashSet<String>();
		if (!staticMap.containsKey(this.getLocation())) {
			staticMap.put(this.getLocation(), getNeighbours());//exploring the map and storing the values.
		}
		String next = null;
		Iterator it = neighbours.entrySet().iterator();// iteration through neighbours
		List<MapNode<ResourceLevel>> currentRoute;
		List<MapNode<ResourceLevel>> newRoute = null;
		currentRoute = initialRoute;
		MapNode<ResourceLevel> currentNode = currentRoute.get(currentRoute
				.size() - 1);
		visited.add(currentNode.getNode());
		String currentLocation = currentNode.getNode();
		ResourceLevel currentLevel = currentNode.getProperty();
		while (it.hasNext()) {
			@SuppressWarnings("rawtypes")
			Map.Entry pair = (Map.Entry) it.next();
			if (!pair.getKey().toString().equals(getLocation()))
				neighboursSet.add(pair.getKey().toString());
		}
		for (String neighbour : neighboursSet) {
			ResourceLevel newLevel = currentLevel.copyOf();
			if (!visited.contains(neighbour)) {
				newRoute = new ArrayList<MapNode<ResourceLevel>>();
				// newRoute.addAll(currentRoute);
				newRoute.add(new MapNode<ResourceLevel>(neighbour, newLevel));
				toDoQueue.add(newRoute);//putting the new route to the todo queue.
			
			}
		}
	}

	//checks if it is the last node in the tree. The condition is that it should have only 2 neighbours,1 itself and the other will be a parent node.
	Boolean isLastNode() {
		if (!staticMap.containsKey(this.getLocation())) {
			staticMap.put(this.getLocation(), getNeighbours());
		}
		Boolean result = false;
		if (getNeighbours().size() == 2) {
			result = true;
		}
		trace("is last node is true");
		return result;
		
	}

	//getting the parent node from the explored map.
	String getParent(String nodeToGo) {
		String parent = null;
		Boolean result = false;
		Iterator it = staticMap.entrySet().iterator();
		while (it.hasNext()) {
			Map.Entry pair = (Map.Entry) it.next();

			Map neighbours = (Map) pair.getValue();
			{
				if (isNodeNeighbour(nodeToGo, neighbours)) {
					parent = (String) pair.getKey();
				}
			}

		}

		return parent;
	}

	//checking if the node is a neighbour, used for finding the shortest path
	Boolean isNodeNeighbour(String isNodeNeighbour, Map neighbours) {
		Boolean result = false;
		Iterator it = neighbours.entrySet().iterator();
		while (it.hasNext()) {
			@SuppressWarnings("rawtypes")
			Map.Entry pair = (Map.Entry) it.next();
			if (pair.getKey().toString().equals(isNodeNeighbour)) {
				result = true;
				break;
			}
		}
		return result;
	}

	
	String generatePathForNextNode() {
		String parent = getParent(this.getLocation());
		visited.add(this.getLocation());
		return parent;
	}

	
	//calculates the shortest path 
	ArrayList getShortestPath(ArrayList currentPath) {
		ArrayList newPath = new ArrayList();
		trace("in shortest path.------>");
		for (int i = 0; i < currentPath.size(); i++) {

			if (currentPath.get(i).equals(entrancePath)) {
				newPath.clear();
			}
			newPath.add(currentPath.get(i));
		}
		ArrayList newCheckedpath = new ArrayList();
		ArrayList finalPath = new ArrayList();

		newCheckedpath = (ArrayList) newPath.clone();
		System.out.println("newCheckpath:" + newCheckedpath.size());
		if (newCheckedpath.size() >= 2) {
			String node = "";
			int count = newCheckedpath.size() - 1;
			System.out.println("count:" + count);
			while (count >= 0) {
				node = (String) newCheckedpath.get(count);
				finalPath.add(node);

				newCheckedpath = getShortestPathForNode(newCheckedpath, node);
				count = newCheckedpath.size() - 1;
			}
		}

		if (finalPath.size() > 0) {
			System.out.println("final path:" + finalPath);
			newPath = finalPath;
		}
		return newPath;
	}

	
	//getting the shortest path for a particular node from the entrance node.
	ArrayList getShortestPathForNode(ArrayList nodeList, String nodeName) {
	
		ArrayList newList = new ArrayList();
		for (int i = 0; i < nodeList.size(); i++) {
			if (nodeList.get(i).equals(nodeName)) {
				break;
			}
			newList.add(nodeList.get(i));

		}
		trace("newList size:" + newList.size());
		return newList;
	}
}
