package maze;

/**
 * Implements a maze in which bots cannot automatically access the maze's map,
 * but must construct their own map
 * 
 * 
 * @version November 2014
 */
public class UnmappedMaze extends Maze {

	public UnmappedMaze(String file) {
		super(file, false);
	}

	public UnmappedMaze() {
		super(null, false);
	}
}