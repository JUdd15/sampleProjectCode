package maze;

import java.util.HashMap;
import java.util.Map;

import map.MapError;
import map.MapReader;
import map.MazeMap;
import resource.ResourceAdjustment;
import util.RandomAccess;
import bot.Bot;

/**
 * The basic maze class. This class will be wrapped to provide the different
 * types of maze required for the assignment.
 * 
 * 
 * @version November 2014
 */
public class Maze {
	// Map of the maze, owned by the maze
	private MazeMap mazesMap;
	// Map of the maze, owned by bots
	private MazeMap botsMap;

	/**
	 * Construct a new maze from a file containing a maze specification, with a
	 * given level of access to map information.
	 * 
	 * @param file
	 *            The name of the file holding the maze specification
	 * @param mapIsPublic
	 *            the permitted level of access to map information: true if the
	 *            maze's map is public, false otherwise
	 */
	public Maze(String file, boolean mapIsPublic) {
		MapReader reader = new MapReader(file);
		mazesMap = reader.getMap();
		if (mapIsPublic) {
			botsMap = mazesMap.copyOf(); // bots have access to the maze's map,
											// so copy it to the bot's map
		} else {
			botsMap = new MazeMap(); // bot's map is initially empty
		}
		// Check the structure of the graph
		if (mazesMap.getEntryNodes().size() == 0) {
			throw new MapError("Maze has no entry nodes.");
		}
		if (mazesMap.getExitNodes().size() == 0) {
			throw new MapError("Maze has no exit nodes.");
		}
	}

	public void displayMaze() {
		mazesMap.show();
	}

	/**
	 * Get the resource adjustment at a bot's location.
	 * 
	 * @param bot
	 *            the bot enquiring about the resource adjustment
	 * @return the adjustment in force at the bot's location
	 */
	public ResourceAdjustment getBotsResourceAdjustment(Bot bot) {
		return mazesMap.getResourceAdjustment(bot.getLocation());
	}

	/**
	 * Get the neighbouring nodes at a bot's current location.
	 * 
	 * @param bot
	 *            the bot enquiring about its neighbours
	 * @return a map form the neighbours' names to the resource adjustment at
	 *         the nodes
	 */
	public Map<String, ResourceAdjustment> getBotsNeighbours(Bot bot) {
		Map<String, ResourceAdjustment> neighbours = new HashMap<String, ResourceAdjustment>();
		for (String neighbour : mazesMap.getNeighbours(bot.getLocation())) {
			neighbours
					.put(neighbour, mazesMap.getResourceAdjustment(neighbour));
		}
		return neighbours;
	}

	/**
	 * Get a map of the maze. If the map access for the maze is MAZE, the maze's
	 * map will be returned. Otherwise, the bot's map will be returned (note
	 * that this may be null).
	 * 
	 * @return a map of the maze
	 */
	public MazeMap getMap() {
		return botsMap;
	}

	/**
	 * Leave a map in the maze
	 * 
	 * @param map
	 *            the map to be left in the maze
	 * @throws MazeError
	 *             if the bot is not in the maze
	 */
	public void leaveMap(MazeMap map) {
		botsMap = map;
	}

	/**
	 * Get a random entry node
	 */
	public String getEntryNode() {
		return RandomAccess.getRandomEntry(mazesMap.getEntryNodes());
	}

	/**
	 * Get the length of a shortest path from a node
	 */
	public int getShortestPathFrom(String node) {
		return mazesMap.getShortestPathLengthFrom(node);
	}

	/**
	 * Check if a move is a valid move - i.e. whether there is a link from the
	 * source node to the destination node
	 */
	public boolean isValidMove(String source, String dest) {
		return mazesMap.contains(source, dest);
	}

	/**
	 * Check if a bot is at an entry node
	 */
	public boolean isAtEntrance(Bot bot) {
		return mazesMap.isEntranceNode(bot.getLocation());
	}

	/**
	 * Check if a bot is at an exit node
	 */
	public boolean isAtExit(Bot bot) {
		return mazesMap.isExitNode(bot.getLocation());
	}
}
