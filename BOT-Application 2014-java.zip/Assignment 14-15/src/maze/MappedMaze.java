package maze;

/**
 * Mazes in which bots have access to a map of the maze.
 * 
 *
 * @version November 2014
 */
public class MappedMaze extends Maze {
	public MappedMaze(String file) {
		super(file, true);
	}

	public MappedMaze() {
		super(null, true);
	}
}