This package implements the various types of mazes used in the various
challenges.  The Maze class implements the basic functionality of mazes,
providing the methods that bots can call to access information about the
mazes.  You should not be calling these methods directly, but rather accessing
them through the corresponding Bot methods.

The two types of maze used in the assignment, MappedMaze and UnmappedMaze
are implemented as subclasses of the basic Maze class.

 
There is no need to understand these classes in detail.  It is probably
fairly clear how to access maze information from the method signatures
defined in the bot.Bot class, and how to access map information from the
methods defined in the map.MazeMap class.
 - 