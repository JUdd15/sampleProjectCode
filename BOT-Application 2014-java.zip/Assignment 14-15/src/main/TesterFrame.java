package main;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JPanel;
import javax.swing.JTextField;

import bot.Bot;
import bot.Bot.TraceMode;

import tests.MazeTest;
import tests.MazeTest.Challenge;
import tests.MazeTest.TestType;

public class TesterFrame extends JPanel implements ActionListener {
	/**
	 * 
	 */
	private static final long serialVersionUID = -7179171096901990090L;

	protected class OptionChooser<T> extends JComponent implements
			ActionListener, ItemListener {
		/**
		 * 
		 */
		private static final long serialVersionUID = -4758914548956028414L;
		private JTextField label;
		private JCheckBox allButton;
		private JComboBox<T> comboBox;
		private boolean allSelected;
		private T selectedObject;

		@SuppressWarnings("unchecked")
		public OptionChooser(String label, JComboBox<T> comboBox) {
			setLayout(new GridLayout(1, 3));
			this.label = new JTextField(label);
			this.label.setEditable(false);
			this.label.setForeground(Color.BLACK);
			add(this.label);
			this.comboBox = comboBox;
			comboBox.setEditable(false);
			comboBox.setSelectedIndex(0);
			selectedObject = (T) comboBox.getSelectedItem();
			comboBox.addActionListener(this);
			add(comboBox);
			allButton = new JCheckBox("All");
			allButton.setSelected(false);
			allButton.setEnabled(false);
			allButton.addItemListener(this);
			add(allButton);
			allSelected = false;
		}

		public void allowAllOption() {
			allButton.setEnabled(true);
		}

		public void disallowAllOption() {
			allButton.setEnabled(false);
		}

		@Override
		@SuppressWarnings("unchecked")
		public void actionPerformed(ActionEvent e) {
			if (e.getSource() == comboBox) {
				selectedObject = (T) comboBox.getSelectedItem();
			}
		}

		@Override
		public void itemStateChanged(ItemEvent e) {
			if (e.getSource() == allButton) {
				allSelected = e.getStateChange() == ItemEvent.SELECTED;
				comboBox.setEnabled(!allSelected);
			}
		}

		public boolean isSelected(T option) {
			return allSelected || selectedObject.equals(option);
		}

		public T getSelected() {
			return selectedObject;
		}

		public void setSelected(T select) {
			comboBox.setSelectedItem(select);
		}
	}

	protected class EnumValueChooser<T extends Enum<T>> extends
			OptionChooser<T> {
		/**
		 * 
		 */
		private static final long serialVersionUID = -5147591815796484164L;

		public EnumValueChooser(Class<T> enumClass) {
			super(enumClass.getName().substring(
					Math.max(enumClass.getName().lastIndexOf('$'), enumClass
							.getName().lastIndexOf('.')) + 1),
					new JComboBox<T>(enumClass.getEnumConstants()));
		}

		public EnumValueChooser(Class<T> enumClass, String labelAnnotation) {
			super(enumClass.getName().substring(
					Math.max(enumClass.getName().lastIndexOf('$'), enumClass
							.getName().lastIndexOf('.')) + 1)
					+ " (" + labelAnnotation + ")", new JComboBox<T>(
					enumClass.getEnumConstants()));
		}
	}

	protected class IntegerChooser extends OptionChooser<Integer> {
		/**
		 * 
		 */
		private static final long serialVersionUID = 2815414260493348920L;

		public IntegerChooser(Integer[] choices, String label) {
			super(label, new JComboBox<Integer>(choices));
		}
	}

	private EnumValueChooser<MazeTest.Challenge> challengeChooser;
	private EnumValueChooser<MazeTest.TestType> levelChooser;
	private IntegerChooser testChooser;
	private EnumValueChooser<Bot.TraceMode> botTraceChooser, mazeTraceChooser,
			testTraceChooser;
	private JButton runTests;

	private Integer[] testNos = new Integer[5];

	/**
	 * Create the GUI and show it. For thread safety, this method should be
	 * invoked from the event-dispatching thread.
	 */
	public TesterFrame() {
		// Set up the content pane.
		setLayout(new GridLayout(3, 3));
		challengeChooser = new EnumValueChooser<Challenge>(
				MazeTest.Challenge.class);
		challengeChooser.allowAllOption();
		add(challengeChooser);
		levelChooser = new EnumValueChooser<TestType>(MazeTest.TestType.class);
		levelChooser.allowAllOption();
		add(levelChooser);
		for (int i = 0; i <= 4; i++) {
			testNos[i] = i;
		}
		testChooser = new IntegerChooser(testNos, "Test number");
		testChooser.allowAllOption();
		add(testChooser);
		botTraceChooser = new EnumValueChooser<TraceMode>(Bot.TraceMode.class,
				"Bot");
		botTraceChooser.setSelected(Bot.TraceMode.OFF);
		add(botTraceChooser);
		mazeTraceChooser = new EnumValueChooser<TraceMode>(Bot.TraceMode.class,
				"Maze");
		mazeTraceChooser.setSelected(Bot.TraceMode.OFF);
		add(mazeTraceChooser);
		testTraceChooser = new EnumValueChooser<TraceMode>(Bot.TraceMode.class,
				"Tests");
		testTraceChooser.setSelected(Bot.TraceMode.POP_UP);
		add(testTraceChooser);
		JButton dead1 = new JButton("");
		dead1.setEnabled(false);
		add(dead1);
		runTests = new JButton("Run tests");
		add(runTests);
		runTests.addActionListener(this);
		JButton dead2 = new JButton("");
		dead2.setEnabled(false);
		add(dead2);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == runTests) {
			Bot.setTraceMode(botTraceChooser.getSelected());
			MazeTest.setTraceMode(mazeTraceChooser.getSelected(),
					testTraceChooser.getSelected());
			for (MazeTest.Challenge challenge : MazeTest.Challenge.values()) {
				if (challengeChooser.isSelected(challenge)) {
					for (MazeTest.TestType level : MazeTest.TestType.values()) {
						if (levelChooser.isSelected(level)) {
							for (Integer testNo : testNos) {
								if (testChooser.isSelected(testNo)) {
									MazeTest.runTests(
											challenge,
											new MazeTest.AbsoluteTester(level
													.toString(), testNo, 20));
								}
							}
						}
					}
				}
			}
		}
	}
}