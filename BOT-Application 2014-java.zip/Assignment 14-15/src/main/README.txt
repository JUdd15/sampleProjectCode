You do not need to study the code in this package.  This package provides a 
facility for running a tester GUI.  The main method in the Main class will
launch this GUI.  This GUI allows you to choose which challenges you want
to run.  

On the top line of the GUI, from left to right, you can choose
 - the challenge: either mapped mazes or unmapped mazes (the SearcherBot provided
   works with mapped mazes, the assignment challenge is to implement
   an ExplorerBot class that will work successfully with unmapeed mazes) 
 - the test type: from "extra mild" to "suicide" - this is an indication
   of how challenging the mazes the bots will be tested on are.  "Extra mild"
   mazes are relatively easy, "suicide" mazes are relatively difficult. These
   are approximate indications - there is no guarantee that all "suicide" mazes
   are more difficult than all "extra mild" mazes.  The nomenclature is 
   loosely based on the 1970s Plaza cafe in Manchester -
   see http://www.mdmarchive.co.uk/artefact.php?&aid=10336&vid=809
   and http://www.flickr.com/photos/kh1234567890/1449505053/
 - the test number: there are five tests available for each challenge/level
   combination, numbered 0 to 4.
   
The bottom line of the GUI allows you to choose the trace mode for the
tests.  This can be set for bots, for tests, and for mazes.  For bots the trace is the
output produced by calls of the trace(String) method, for tests the trace is
a summary of the test results.  The trace level can be set separately for
bots and tests to off, terminal, or pop up.  For mazes the only sensible options
to choose are off, or pop up.  The pop up option will display a graphical
representation of the current maze.