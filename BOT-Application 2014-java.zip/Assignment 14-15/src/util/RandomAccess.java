package util;

import java.util.Collection;
import java.util.Random;

public class RandomAccess {
	public static <T> T getRandomEntry(Collection<T> collection) {
		int randomIndex = new Random().nextInt(collection.size());
		int index = 0;
		for (T entry : collection) {
			if (index == randomIndex) {
				return entry;
			}
			index++;
		}
		return null;
	}
}
