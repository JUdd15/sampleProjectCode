package util;

/**
 
 * @version December 2014
 * 
 */

public class CopyError extends RuntimeException {
	/**
	 * 
	 */
	private static final long serialVersionUID = 20131201L;

	public CopyError() {
		super("Undefined copy error");
	}

	public CopyError(String message) {
		super(message);
	}
}
