package util;

public interface Copyable<T> {
	/**
	 * A copyable object will have a copyOf method that will return a clone of
	 * the object, unless the object is immutable.
	 * 
	 * @return a clone of the object
	 */
	public T copyOf();

}
