This package provides two utilities:
 - RandomAccess provides a method for accessing a random entry from a collection
 - Copyable defines the interface for "copyable" objects (a variant of cloneability).
   Some of the classes used in other packages are required to be copyable.