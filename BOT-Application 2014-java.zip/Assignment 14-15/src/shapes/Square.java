package shapes;

import java.awt.Polygon;

public class Square extends Polygon {
	public Square(int xLeft, int yLeft, int width, int height) {
		super();
		addPoint(xLeft, yLeft);
		addPoint(xLeft + width, yLeft);
		addPoint(xLeft + width, yLeft + height);
		addPoint(xLeft, yLeft + height);
	}

}
