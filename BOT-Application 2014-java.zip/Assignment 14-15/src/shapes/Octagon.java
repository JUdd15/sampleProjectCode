package shapes;

import java.awt.Polygon;

public class Octagon extends Polygon {
	public Octagon(int xLeft, int yLeft, int width, int height) {
		super();
		addPoint(xLeft + width / 3, yLeft);
		addPoint(xLeft + 2 * width / 3, yLeft);
		addPoint(xLeft + width, yLeft + height / 3);
		addPoint(xLeft + width, yLeft + 2 * height / 3);
		addPoint(xLeft + 2 * width / 3, yLeft + height);
		addPoint(xLeft + width / 3, yLeft + height);
		addPoint(xLeft, yLeft + 2 * height / 3);
		addPoint(xLeft, yLeft + height / 3);
	}

}
