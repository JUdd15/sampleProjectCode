package shapes;

import java.awt.Polygon;

public class Diamond extends Polygon {
	public Diamond(int xLeft, int yLeft, int width, int height) {
		super();
		addPoint(xLeft + width / 2, yLeft);
		addPoint(xLeft + width, yLeft + height / 2);
		addPoint(xLeft + width / 2, yLeft + height);
		addPoint(xLeft, yLeft + height / 2);
	}

}
