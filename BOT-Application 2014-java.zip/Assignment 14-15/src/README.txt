This package contains the code for the additional question for the 2014/2015 AP&D
logbook.  The current package should contain sufficient code to enable you to 
programme a solution to the additional question
.
It also contains tools for testing your implementation.  The results of these tests
should give you an indication of how well your implementation is performning.

There is a considerable amount of code here, but you do not need to study all
of it in detail.

See the README files in the individual packages for more details of what they do.