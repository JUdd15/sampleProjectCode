This package defines the maps used in mazes.  MapNode defines nodes in a
map, and MazeMap defines the maps.  MazeMap objects are returned by a bot's
getMap method. You will need to study the MazeMap class to understand how 
your ExplorerBot can build maps.  The first two methods defined in the class
(getDisplayLocation and setDisplayLocation) are needed for the graphical
display, and you do not need to worry about these.  The methods that are
relevant to building maps are, in addition to those defined in the graph
classes, markNodeAsEntrance and markNodeAsExit.  There are also some access
methods you may need (again in addition to those already defined in
the graph classes).  These are: isEntranceNode, isExitNode, getEntryNodes,
getExitNodes and getResourceAdjustment.  You do not need to concern
yourself with the "shortest path" methods - these are used solely by the
tester to compare your bot's performance with the theoretical ideal
performance. 

MapReader is provided as a utility for reading map definitions from files.
There is no need to understand how this class is implemented.