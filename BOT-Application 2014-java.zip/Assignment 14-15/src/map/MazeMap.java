package map;

import java.awt.Color;
import java.awt.Paint;
import java.awt.Point;
import java.awt.Shape;
import java.awt.geom.Ellipse2D;
import java.util.HashMap;
import java.util.Set;

import graph.GraphError;
import graph.LabelledGraph;
import resource.ResourceAdjustment;
import shapes.Diamond;
import shapes.Octagon;
import shapes.Square;
import util.Copyable;

import util.*;

/**
 * Implements maps of mazes. The nodes in the maze may hold information (e.g.
 * resource adjustment), and may be labelled. The names of the nodes are
 * strings.
 * 
 * This class also holds the information about the nodes required for a visual
 * display.
 * 
 * 
 * @version November 2013
 * 
 * @param <Info>
 *            the type of information held in the maze's nodes.
 * @param <Label>
 *            the type of label being used in this maze.
 */

public class MazeMap extends LabelledGraph<String> implements Copyable<MazeMap> {

	// The location of the nodes in a visual display
	private HashMap<String, Point> displayLocations = new HashMap<String, Point>();

	// The resource adjustment at each node
	private HashMap<String, ResourceAdjustment> resourceAdjustments = new HashMap<String, ResourceAdjustment>();

	// The length of the shortest exit route from each start node
	private HashMap<String, Integer> shortestRoutes = new HashMap<String, Integer>();

	// The entry and exit labels
	private final static String ENTRY = "entry", EXIT = "exit";

	/**
	 * Initialise with the entry and exit labels, for marking entrance and exit
	 * nodes
	 */
	public MazeMap() {
		super();
		declareLabel(ENTRY);
		declareLabel(EXIT);
	}

	/**
	 * Get the (visual display) location of a node.
	 * 
	 * @param node
	 *            a node in the map
	 * @return the coordinates of the node in a visual display
	 */
	public Point getDisplayLocation(String node) {
		return displayLocations.get(node);
	}

	/**
	 * set the (visual display) location of a node.
	 * 
	 * @param node
	 *            a node in the map
	 */
	public void setDisplayLocation(String node, Point location) {
		displayLocations.put(node, location);
	}

	/**
	 * Mark a node as an entrance node.
	 * 
	 * @param nodeName
	 *            the node to be marked as an entrance node.
	 */
	public void markNodeAsEntrance(String nodeName) {
		label(nodeName, ENTRY);
	}

	/**
	 * Mark a node as an exit node.
	 * 
	 * @param nodeName
	 *            the node to be marked as an exit node.
	 */
	public void markNodeAsExit(String nodeName) {
		label(nodeName, EXIT);
	}

	/**
	 * Check if a node is an entrance node.
	 * 
	 * @param nodeName
	 *            the node to be checked.
	 * @return true iff the node is an entrance node.
	 */
	public boolean isEntranceNode(String nodeName) {
		return isLabelForNode(ENTRY, nodeName);
	}

	/**
	 * Check if a node is an exit node.
	 * 
	 * @param nodeName
	 *            the node to be checked.
	 * @return true iff the node is an exit node.
	 */
	public boolean isExitNode(String nodeName) {
		return isLabelForNode(EXIT, nodeName);
	}

	/**
	 * Get a set containing all the entry nodes in this map.
	 * 
	 * @return a set containing all the entry nodes in this map
	 */
	public Set<String> getEntryNodes() {
		return super.getNodesLabelledWith(ENTRY);
	}

	/**
	 * Get a set containing all the exit nodes in this map.
	 * 
	 * @return a set containing all the exit nodes in this map
	 */
	public Set<String> getExitNodes() {
		return super.getNodesLabelledWith(EXIT);
	}

	/**
	 * Get the info attached to a node.
	 * 
	 * @param name
	 *            the name of the node
	 * @return the info attached to this node, if it exists
	 */
	public ResourceAdjustment getResourceAdjustment(String name) {
		if (!contains(name)) { // if the node doesn't exist
			System.out.println("" + resourceAdjustments);
			throw new MapError("Cannot get node " + name
					+ ".  It doesn't exist.");
		}
		return resourceAdjustments.get(name);
	}

	/**
	 * Add a node to the map. Also add the name->node mapping to the infoMap.
	 * This method needs to override the method in the superclass in order to
	 * maintain the node map.
	 * 
	 * @param nodeName
	 *            the name of the node to be added to the map
	 * @param info
	 *            the info to be attached to this node
	 */
	public void add(String nodeName, ResourceAdjustment info) {
		super.add(nodeName);
		resourceAdjustments.put(nodeName, info);
	}

	@Override
	/**
	 * Override super's add, as each node <i>must</i> have a resource adjustment attached
	 * to it.
	 */
	public void add(String node) throws GraphError {
		throw new GraphError(
				"Cannot use add(node) in MazeMap. Use add(node,adjustment) instead.");
	}

	@Override
	/**
	 * Remove a node from the map. Also remove the name->node mapping from the nodeMap.  This method needs to override
	 * the method in the superclass in order to maintain the node map.
	 * 
	 * @param node the node to be removed from the map
	 */
	public void remove(String node) {
		super.remove(node);
		resourceAdjustments.remove(node);
	}

	/**
	 * Note the shortest route from an entrance node
	 * 
	 * @param node
	 *            the name of the entrance node
	 * @param length
	 *            the length of the shortest route
	 */
	public void setShortestPathLengthFrom(String node, int length) {
		shortestRoutes.put(node, length);
	}

	/**
	 * Get the length of the shortest route from an entrance node
	 * 
	 * @param node
	 *            the entrance node the route should start at
	 */
	public int getShortestPathLengthFrom(String node) {
		return shortestRoutes.get(node);
	}

	@Override
	public MazeMap copyOf() throws CopyError {
		MazeMap copy;
		try {
			copy = new MazeMap();
			for (String node : getNodes()) {
				copy.add(node, resourceAdjustments.get(node));
				for (String label : getLabelsAttachedTo(node)) {
					if (!copy.exists(label)) {
						copy.declareLabel(label);
					}
					copy.label(node, label);
				}
			}
			for (String node : getNodes()) {
				for (String otherNode : getNodes()) {
					if (contains(node, otherNode)) {
						copy.add(node, otherNode);
					}
				}
			}
			return copy;
		} catch (GraphError error) {
			throw new CopyError(
					"Could not copy map.  Error while creating copy. "
							+ error.getMessage());
		}
	}

	@Override
	protected String nodeLabel(String node) {
		return super.nodeLabel(node) + "(" + getResourceAdjustment(node) + ")";
	}

	@Override
	protected Shape nodeShape(String node) {
		if (isExitNode(node) && isEntranceNode(node)) {
			return new Octagon(-10, -10, 20, 20);
		} else if (isExitNode(node)) {
			return new Diamond(-10, -10, 20, 20);
		} else if (isEntranceNode(node)) {
			return new Square(-10, -10, 20, 20);
		} else {
			return new Ellipse2D.Double(-10, -10, 20, 20);
		}
	}

	@Override
	protected Paint nodeColour(String node) {
		if (isExitNode(node) && isEntranceNode(node)) {
			return Color.ORANGE;
		} else if (isExitNode(node)) {
			return Color.YELLOW;
		} else if (isEntranceNode(node)) {
			return Color.RED;
		} else {
			return Color.CYAN;
		}
	}
}
