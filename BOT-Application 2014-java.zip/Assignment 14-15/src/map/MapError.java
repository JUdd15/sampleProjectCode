package map;

import graph.GraphError;

import java.io.StreamTokenizer;

/**
 * Report errors in maps.
 * 
 * 
 * @version November 2014
 */
public class MapError extends GraphError {
	/**
	 * 
	 */
	private static final long serialVersionUID = 2969908160565243008L;

	public MapError() {
		super("Undefined map error.");
	}

	public MapError(String message) {
		super(message);
	}

	public static class Scanning extends MapError {
		/**
		 * 
		 */
		private static final long serialVersionUID = 6576745960371021073L;

		protected Scanning(StreamTokenizer tokeniser, String fileName) {
			super("Error scanning map specification at or around " + tokeniser
					+ " in file " + fileName);
		}

		protected Scanning(StreamTokenizer tokeniser, String fileName,
				String expected) {
			super("Error scanning map specification at or around " + tokeniser
					+ " in file " + fileName + ", " + expected + " expected");
		}
	}

	public static class FileAccess extends MapError {
		/**
		 * 
		 */
		private static final long serialVersionUID = 6666285056133465251L;

		public FileAccess(String message) {
			super("File access error." + message);
		}
	}

	public static class Structure extends MapError {
		/**
		 * 
		 */
		private static final long serialVersionUID = 7599517863296264330L;

		public Structure(String message) {
			super("Structural error." + message);
		}
	}

	public static class BotAdmin extends MapError {
		/**
		 * 
		 */
		private static final long serialVersionUID = 368283925334242490L;

		public BotAdmin(String message) {
			super("Bot administration error. " + message);
		}
	}
}