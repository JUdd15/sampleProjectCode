package map;

import java.io.File;
import java.io.FileReader;
import java.io.StreamTokenizer;

import javax.swing.JFileChooser;
import javax.swing.JOptionPane;

import resource.ResourceAdjustment;

/**
 * Provides a facility for reading a maze map from a specification file.
 */
public class MapReader {
	private StreamTokenizer tokeniser;
	private File mapFile;
	private MazeMap map;

	/**
	 * Read a map from a file.
	 */
	public MapReader(String filename) {
		if (filename != null) {
			mapFile = new File(filename);
		} else {
			mapFile = chooseFile();
		}
		map = new MazeMap();
		generateMap();
	}

	public MazeMap getMap() {
		return map;
	}

	private File chooseFile() {
		File file;
		JFileChooser chooser = new JFileChooser();
		chooser.setDialogTitle("Choose maze specification file");
		if (chooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) {
			file = chooser.getSelectedFile();
		} else {
			if (JOptionPane.showConfirmDialog(null,
					"No maze specification file was chosen\n" + "Try again?",
					"Error selecting maze specification file",
					JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
				file = chooseFile();
			} else {
				throw new MapError.FileAccess(
						"User did not select a maze specification file.");
			}
		}
		if (!file.exists()) {
			if (JOptionPane.showConfirmDialog(null,
					"The maze specification file " + mapFile.getName()
							+ " does not exist\n" + "Choose another file?",
					"Error selecting maze specification file",
					JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
				file = chooseFile();
			} else {
				throw new MapError.FileAccess(
						"User chose a nonexistent maze specification file.");
			}
		}
		return file;
	}

	private void generateMap() {
		if (mapFile == null) {
			mapFile = chooseFile();
		}
		try {
			tokeniser = new StreamTokenizer(new FileReader(mapFile));
		} catch (java.io.FileNotFoundException error) {
			throw new MapError.FileAccess("No scan file called "
					+ mapFile.getName() + " found.");
		}
		buildTokeniser();
		scan();
	}

	private void buildTokeniser() {
		tokeniser.eolIsSignificant(false);
		tokeniser.slashSlashComments(true);
		tokeniser.slashStarComments(true);
		tokeniser.parseNumbers();
		tokeniser.ordinaryChar(':');
		tokeniser.ordinaryChar(',');
		tokeniser.ordinaryChar(';');
		tokeniser.ordinaryChar('<');
		tokeniser.ordinaryChar('+');
		tokeniser.ordinaryChar('-');
		tokeniser.ordinaryChar('=');
	}

	private void scan() {
		do {
			getNextToken();
			if (checkToken("nodes")) {
				getNextToken();
				if (!checkToken(':')) {
					throw new MapError.Scanning(tokeniser, mapFile.getName(),
							"':'");
				}
				do {
					getNextToken();
					scanNode();
					if (!checkToken(',') && !checkToken(';')) {
						throw new MapError.Scanning(tokeniser,
								mapFile.getName(), "',' or ';'");
					}
				} while (!checkToken(';'));
			} else if (checkToken("links")) {
				getNextToken();
				if (!checkToken(':')) {
					throw new MapError.Scanning(tokeniser, mapFile.getName(),
							"':'");
				}
				do {
					getNextToken();
					scanLink();
					if (!checkToken(',') && !checkToken(';')) {
						throw new MapError.Scanning(tokeniser,
								mapFile.getName(), "',' or ';'");
					}
				} while (!checkToken(';'));
			}
		} while (tokeniser.ttype != StreamTokenizer.TT_EOF);
	}

	private void getNextToken() {
		try {
			tokeniser.nextToken();
		} catch (java.io.IOException error) {
			throw new MapError.Scanning(tokeniser, mapFile.getName());
		}
	}

	private void scanNode() {
		String name = scanNodeName();
		int adjustment;
		if (checkToken('(')) { // adjustment info
			getNextToken();
			adjustment = scanNumber();
			if (checkToken(')')) {
				getNextToken();
			} else {
				throw new MapError.Scanning(tokeniser, mapFile.getName(), "')'");
			}
		} else {
			adjustment = 0;
		}
		map.add(name, new ResourceAdjustment(adjustment));
		boolean isEntry = checkToken('[');
		if (isEntry) { // is an entry node, with route length indicator
			getNextToken();
			map.markNodeAsEntrance(name);
			int shortestRoute = scanNumber();
			map.setShortestPathLengthFrom(name, shortestRoute);
			if (checkToken(']')) {
				getNextToken();
			} else {
				throw new MapError.Scanning(tokeniser, mapFile.getName(), "']'");
			}
		}
		boolean isExit = checkToken('*');
		if (isExit) { // exit node marker
			getNextToken();
			map.markNodeAsExit(name);
		}
	}

	private String scanNodeName() {
		if (checkIsNodeName()) {
			String name = tokeniser.sval;
			getNextToken();
			return name;
		} else {
			throw new MapError.Scanning(tokeniser, mapFile.getName(),
					"Node name");
		}
	}

	private int scanNumber() {
		int multiplier = 1;
		if (checkToken('+')) {
			getNextToken();
		} else if (checkToken('-')) {
			multiplier = -1;
			getNextToken();
		}
		if (!checkToken(0)) {
			throw new MapError.Scanning(tokeniser, mapFile.getName(), "Number");
		}
		int result = (int) (multiplier * tokeniser.nval);
		getNextToken();
		return result;
	}

	private void scanLink() {
		String node1 = scanNodeName();
		if (!checkToken('<')) {
			throw new MapError.Scanning(tokeniser, mapFile.getName(), "'<'");
		}
		do {
			getNextToken();
		} while (checkToken('-') || checkToken('='));
		if (!checkToken('>')) {
			throw new MapError.Scanning(tokeniser, mapFile.getName(), "'>'");
		}
		getNextToken();
		String node2 = scanNodeName();
		map.add(node1, node2);
		// if (!node1.equals(node2))
		// forDisplay.addEdge(node1 + "-" + node2, node1, node2, false);
	}

	private boolean checkIsNodeName() {
		return tokeniser.ttype == StreamTokenizer.TT_WORD
				&& tokeniser.sval.matches("[A-za-z][A-za-z_0-9]*");
	}

	private boolean checkToken(char expected) {
		return tokeniser.ttype == expected;
	}

	private boolean checkToken(String expected) {
		return tokeniser.ttype == StreamTokenizer.TT_WORD
				&& tokeniser.sval.toLowerCase().compareTo(
						expected.toLowerCase()) == 0;
	}

	private boolean checkToken(int n) {
		return tokeniser.ttype == StreamTokenizer.TT_NUMBER;
	}
}