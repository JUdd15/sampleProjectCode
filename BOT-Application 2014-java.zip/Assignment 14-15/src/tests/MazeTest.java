package tests;

import graph.GraphError;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.HashMap;
import java.util.Properties;

import javax.swing.JFileChooser;
import javax.swing.JOptionPane;

import map.MapError;
import maze.MappedMaze;
import maze.Maze;
import maze.UnmappedMaze;
import bot.Bot;
import bot.ExplorerBot;
import bot.RandomBot;
import bot.SearcherBot;

public class MazeTest extends junit.framework.TestCase {
	/**
	 * Default constructor for test class MazeTest
	 */
	public MazeTest() {
		Bot.setTraceMode(Bot.TraceMode.OFF);
	}

	/**
	 * Sets up the test fixture.
	 * 
	 * Called before every test case method.
	 */
	@Override
	protected void setUp() {
	}

	/**
	 * Tears down the test fixture.
	 * 
	 * Called after every test case method.
	 */
	@Override
	protected void tearDown() {
	}

	public static abstract class Tester {
		int testNo, iterations; // achieved in the given number of iterations
		String level;

		protected Tester(String level, int testNo, int iterations) {
			this.level = level;
			this.testNo = testNo;
			this.iterations = iterations;
		}

		protected String reportResult(int result) {
			return "The bots achieved a score of " + result + "% in "
					+ iterations + " test runs. " + getDescription() + result
					+ "%";
		}

		protected File getMazeFile(File parent) throws MapError {
			File levelFolder = new File(parent, level);
			if (!levelFolder.exists()) {
				throw new MapError.FileAccess("Test subfolder "
						+ levelFolder.getName() + " for " + parent.getName()
						+ " does not exist.");
			}
			File testFile = new File(levelFolder, "Maze" + testNo + ".map");
			if (!testFile.exists()) {
				throw new MapError.FileAccess("Test file " + testFile.getName()
						+ " at level " + levelFolder.getName() + " in "
						+ parent.getName() + " does not exist.");
			}
			return testFile;
		}

		protected int getTestNo() {
			return testNo;
		}

		protected String getLevel() {
			return level;
		}

		protected String getDescriptor() {
			return "Test number " + testNo + ", level " + level;
		}

		protected int getIterations() {
			return iterations;
		}

		protected abstract String getDescription();
	}

	public static class AbsoluteTester extends Tester {
		public AbsoluteTester(String level, int testNo, int iterations) {
			super(level, testNo, iterations);
		}

		@Override
		protected String getDescription() {
			return "Score: ";
		}
	}

	protected static class ComparativeTester extends Tester {
		private int comparison;

		protected ComparativeTester(String level, int testNo, int iterations,
				int comparison) {
			super(level, testNo, iterations);
			this.comparison = comparison;
		}

		@Override
		protected String getDescription() {
			return "A bot is unlikely to score 100% in these tests because of the need to explore."
					+ "An indicative target for the bot's score might be "
					+ comparison
					+ "% (this is based on results from my implementation)."
					+ "Score (indicative target " + comparison + "%): ";
		}
	}

	public enum TestType {
		EXTRA_MILD(Spread.ONE, Spread.ONE, Spread.THREE_TO_SIX,
				Spread.LOW_CONNECTIVITY, Spread.HIGH_ADJUSTMENT), MILD(
				Spread.ONE, Spread.ONE, Spread.THREE_TO_SIX,
				Spread.MEDIUM_CONNECTIVITY, Spread.MEDIUM_ADJUSTMENT), MEDIUM_MILD(
				Spread.ONE, Spread.ONE, Spread.SIX_TO_TWELVE,
				Spread.MEDIUM_CONNECTIVITY, Spread.MEDIUM_ADJUSTMENT), MEDIUM(
				Spread.ONE, Spread.ONE, Spread.SIX_TO_TWELVE,
				Spread.MEDIUM_CONNECTIVITY, Spread.LOW_ADJUSTMENT), MEDIUM_HOT(
				Spread.ONE_TO_THREE, Spread.ONE_TO_THREE, Spread.SIX_TO_TWELVE,
				Spread.MEDIUM_CONNECTIVITY, Spread.LOW_ADJUSTMENT), HOT(
				Spread.ONE_TO_THREE, Spread.ONE, Spread.TWELVE_TO_TWENTY_FIVE,
				Spread.MEDIUM_CONNECTIVITY, Spread.LOW_ADJUSTMENT), EXTRA_HOT(
				Spread.ONE_TO_THREE, Spread.ONE_TO_THREE,
				Spread.TWELVE_TO_TWENTY_FIVE, Spread.MEDIUM_CONNECTIVITY,
				Spread.MEDIUM_ADJUSTMENT), KILLER(Spread.THREE_TO_SIX,
				Spread.ONE_TO_THREE, Spread.TWELVE_TO_TWENTY_FIVE,
				Spread.MEDIUM_CONNECTIVITY, Spread.LOW_ADJUSTMENT), SUICIDE(
				Spread.THREE_TO_SIX, Spread.ONE, Spread.TWELVE_TO_TWENTY_FIVE,
				Spread.HIGH_CONNECTIVITY, Spread.VERY_LOW_ADJUSTMENT);

		private Spread rangeOfNodes, rangeOfEntryNodes, rangeOfExitNodes;
		private Spread rangeOfConnectivity, rangeOfWeight;

		private int numberOfNodes, numberOfEntryNodes, numberOfExitNodes,
				numberOfLinks, iterations;

		protected boolean set = false;

		public void set() throws Spread.RangeError {
			numberOfEntryNodes = rangeOfEntryNodes.pickInt();
			numberOfExitNodes = rangeOfExitNodes.pickInt();
			numberOfNodes = rangeOfNodes.pickIntAbove(numberOfEntryNodes
					+ numberOfExitNodes);
			double connectivity = rangeOfConnectivity
					.pickDoubleBelow(numberOfNodes);
			numberOfLinks = (int) Math
					.floor((numberOfNodes * connectivity) / 2);
			iterations = 10 + numberOfEntryNodes * (3 + numberOfNodes / 10);
			set = true;
		}

		public void reset() {
			set = false;
		}

		protected int getNumberOfNodes() throws Spread.RangeError {
			if (!set)
				set();
			return numberOfNodes;
		}

		protected int getNumberOfEntryNodes() throws Spread.RangeError {
			if (!set)
				set();
			return numberOfEntryNodes;
		}

		protected int getNumberOfExitNodes() throws Spread.RangeError {
			if (!set)
				set();
			return numberOfExitNodes;
		}

		protected int getAdjustmentStepSize() {
			return rangeOfWeight.getGrain();
		}

		protected int getNewAdjustment() {
			return rangeOfWeight.pickIntBetween(-100, 100);
		}

		protected int getNumberOfLinks() throws Spread.RangeError {
			if (!set)
				set();
			return numberOfLinks;
		}

		protected int getNumberOfIterations() {
			return iterations;
		}

		TestType(Spread entryNodeRange, Spread exitNodeRange, Spread nodeRange,
				Spread connectivityRange, Spread weightRange) {
			rangeOfNodes = nodeRange;
			rangeOfEntryNodes = entryNodeRange;
			rangeOfExitNodes = exitNodeRange;
			rangeOfConnectivity = connectivityRange;
			rangeOfWeight = weightRange;
		}
	}

	public enum Challenge {
		MAPPED(0, true), UNMAPPED(0, true);

		Challenge(int initialResource, boolean adjustmentsInForce) {
			this.initialResource = initialResource;
			this.adjustmentsInForce = adjustmentsInForce;
		}

		private int initialResource;
		boolean adjustmentsInForce;

		protected int getInitialResource() {
			return initialResource;
		}

		protected boolean getAdjustmentsInForce() {
			return adjustmentsInForce;
		}

		protected Bot getBot(String name, Maze maze) {
			switch (this) {
			case MAPPED:
				return new SearcherBot(name, maze);
			case UNMAPPED:
				return new ExplorerBot(name, maze);
			default:
				return new RandomBot(name, maze);
			}
		}

		/**
		 * Allow the user to select a challenge, select a maze specification
		 * file, and then generate a suitable maze for that challenge.
		 * 
		 * @param challenge
		 *            the number of the challenge the maze should be generated
		 *            for
		 */
		public Maze getMaze() throws GraphError {
			switch (this) {
			case MAPPED:
				return new MappedMaze();
			case UNMAPPED:
			default:
				return new UnmappedMaze();
			}
		}

		private static File testFoldersRootFolder = null;
		private final static File PROPERTIES_FILE = new File(System
				.getProperties().getProperty("user.home"),
				".CIS2344.Ass.2014.2015");
		private final static String TEST_FOLDERS_ROOT_STRING = "CIS2344 2014/2015 Assignment test folders' root";

		protected File getTestFileRootFolder() throws MapError {
			Properties proudhon = new Properties();
			File root;
			if (PROPERTIES_FILE.exists()) {
				try {
					proudhon.load(new FileInputStream(PROPERTIES_FILE));
					String rootFolderName = proudhon
							.getProperty(TEST_FOLDERS_ROOT_STRING);
					if (rootFolderName == null) {
						root = chooseTestFileRootFolder();
					} else {
						root = new File(rootFolderName);
						if (!root.exists()) {
							root = chooseTestFileRootFolder();
						}
					}
				} catch (java.io.IOException error) {
					throw new MapError.FileAccess(
							"Could not open properties file " + PROPERTIES_FILE
									+ ".");
				}
			} else {
				root = chooseTestFileRootFolder();
			}
			try {
				proudhon.setProperty(TEST_FOLDERS_ROOT_STRING,
						root.getCanonicalPath());
				if (PROPERTIES_FILE.exists()
						|| JOptionPane
								.showConfirmDialog(
										null,
										"For persistence of your choice of the test folders' root folder\n"
												+ "the tester system wishes to save your choice in a file called\n"
												+ PROPERTIES_FILE.getName()
												+ " in your home directory.\n"
												+ "Do you agree to this happening?\n"
												+ "Note: you can force a reset of your choice of test folders' root folder\n"
												+ "by deleting the "
												+ PROPERTIES_FILE.getName()
												+ " file.",
										"Save test folders' root folder location information?",
										JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
					proudhon.store(
							new FileOutputStream(PROPERTIES_FILE),
							"# This file was automatically generated by the AP&D 2011/2012 assignment tester system.\n"
									+ "# It contains information that specifies the test folders' root folder for the assignment tests.\n"
									+ "# Please do not edit this file.\n"
									+ "# To reset your choice of test folders' root folder delete this file.\n");
				}
			} catch (java.io.IOException error) {
				throw new MapError.FileAccess(
						"Could not save test folders' root folder location information.");
			}
			return root;
		}

		protected File chooseTestFileRootFolder() throws MapError {
			File folder;
			JFileChooser chooser = new JFileChooser();
			chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
			chooser.setDialogTitle("Choose test file root folder (\"Test-files\" in unpacked source code)");
			if (chooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) {
				folder = chooser.getSelectedFile();
			} else {
				if (JOptionPane.showConfirmDialog(null,
						"No test file root folder chosen\n" + "Try again?",
						"Error selecting test file root folder",
						JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
					folder = chooseTestFileRootFolder();
				} else {
					throw new MapError.FileAccess(
							"User did not select a test file root folder.");
				}
			}
			if (!folder.exists()) {
				if (JOptionPane.showConfirmDialog(null,
						"The test file root folder " + folder.getName()
								+ " does not exist\n"
								+ "Choose another folder?",
						"Error selecting test file root folder",
						JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
					folder = chooseTestFileRootFolder();
				} else {
					throw new MapError.FileAccess(
							"User chose a nonexistent test file root folder.");
				}
			}
			return folder;
		}

		protected Maze getMaze(Tester tester) throws GraphError {
			System.out.println("testFolder:"+testFoldersRootFolder);
			if (testFoldersRootFolder == null) {
				testFoldersRootFolder = getTestFileRootFolder();
			}
			System.out.println("testFolder new:"+testFoldersRootFolder);
			
			File challengeFolder = new File(testFoldersRootFolder, "Challenge"
					+ this);
			if (!challengeFolder.exists()) {
				System.out.println(challengeFolder);
				throw new MapError.FileAccess("Test file subfolder "
						+ challengeFolder.getName() + " does not exist.");
			}
			try {
				String mazeFile = tester.getMazeFile(challengeFolder)
						.getCanonicalPath();
				switch (this) {
				case MAPPED:
					return new MappedMaze(mazeFile);
				case UNMAPPED:
				default:
					return new UnmappedMaze(mazeFile);
				}
			} catch (java.io.IOException error) {
				throw new MapError.FileAccess(error.getMessage());
			}
		}

		protected String getTesterConstructor(TestType testType, int testNo,
				int iterations, int target) {
			switch (this) {
			case MAPPED:
				return "new AbsoluteTester(\"" + testType + "\"," + testNo
						+ "," + iterations + ")";
			case UNMAPPED:
			default:
				return "new ComparativeTester(\"" + testType + "\"," + testNo
						+ "," + iterations + "," + target + ")";
			}
		}
	}

	private static Bot.TraceMode testTraceMode = Bot.TraceMode.POP_UP;
	private static Bot.TraceMode mazeTraceMode = Bot.TraceMode.POP_UP;

	public static void setTraceMode(Bot.TraceMode newMazeTraceMode,
			Bot.TraceMode newTestTraceMode) {
		mazeTraceMode = newMazeTraceMode;
		testTraceMode = newTestTraceMode;
	}

	public static void runTests(Challenge challenge, Tester tester) {
		int cumulativeScore = 0;
		int tested = 0; // number of bots successfully tested
		int survived = 0; // and of the number of test bots that survive
		String report = "";
		HashMap<Integer, String> fails = new HashMap<Integer, String>();
		Maze maze = challenge.getMaze(tester);
		switch (mazeTraceMode) {
		case POP_UP:
			maze.displayMaze();
			break;
		case TERMINAL:
			System.out.println(maze.toString());
			break;
		}
		report = report + tester.getDescriptor() + ", Challenge " + challenge
				+ "." + tester.getIterations()
				+ " bots will be sent through this maze.";
		for (int testNo = 1; testNo <= tester.getIterations(); testNo++) {
			Bot bot = challenge.getBot(challenge.toString() + "(" + testNo
					+ ")", maze);
			try {
				bot.runBot();
				int length = bot.getPathLength();
				int shortest = bot.getShortestPathLength();
				double ratio = ((double) shortest) / ((double) length);
				int score = (int) Math.round(ratio * ratio * 100);
				cumulativeScore += score;
				tested++;
				report = report + "Bot " + bot + " exited the maze after "
						+ length + " node" + (length == 1 ? "" : "s")
						+ " (target was " + shortest + " node"
						+ (shortest == 1 ? "" : "s") + "), and scored " + score
						+ "%. ";
				survived++;
			} catch (Bot.Death died) {
				tested++;
				report = report + "Bot " + bot + " died: " + died.getMessage()
						+ ", so this bot scored 0%.";
			} catch (Bot.UserError error) {
				report = report
						+ "Bot "
						+ bot
						+ " caused an un expected error: "
						+ error.getMessage()
						+ ". This was probably due to an error in your code, so this bot's score of 0% will be counted.";
				fails.put(testNo, error.getMessage());
			}
		}
		if (tested == 0) {
			report = report
					+ "None of the tests could be properly executed so there is no overall result.";
		} else {
			int overallResult = (int) Math.round(((double) cumulativeScore)
					/ ((double) tested));
			report = report + survived + " bots survived, out of " + tested
					+ " bots tested. The overall result for all " + tested
					+ " bots tested is " + overallResult + "%. "
					+ tester.reportResult(overallResult);
		}
		switch (testTraceMode) {
		case POP_UP:
			JOptionPane.showMessageDialog(null, report.replaceAll("\\.", "\n"),
					tester.getDescriptor() + ", Challenge " + challenge,
					JOptionPane.PLAIN_MESSAGE);
			break;
		case TERMINAL:
			System.out.println(report.replaceAll("\\.", ".\n"));
			break;
		}
		if (fails.size() > 0) {
			report = "There were some unexpected errors:\n";
			for (int testNo : fails.keySet()) {
				report = report + "\tTest " + testNo + " - "
						+ fails.get(testNo) + "\n";
			}
			// fail(report);
		}
	}
}