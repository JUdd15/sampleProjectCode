package tests;

import java.util.Random;

public class Spread {
	private int minimum, maximum;
	private Random picker = new Random(System.currentTimeMillis());
	private boolean uniform;
	private int grain;

	protected Spread(int minimum, int maximum) {
		if (maximum < minimum) {
			this.maximum = maximum;
			this.minimum = minimum;
		} else {
			this.maximum = minimum;
			this.minimum = maximum;
		}
		uniform = true;
		grain = 1;
	}

	private double average, standardDeviation;

	protected Spread(double average, double standardDeviation, int grain,
			int minimum, int maximum) {
		this.average = average;
		this.standardDeviation = standardDeviation;
		this.grain = grain;
		this.minimum = minimum;
		this.maximum = maximum;
		uniform = false;
	}

	protected Spread(int maximum) {
		if (maximum > 0) {
			this.maximum = maximum;
			this.minimum = 0;
		} else {
			this.maximum = 0;
			this.minimum = maximum;
		}
		uniform = true;
		grain = 1;
	}

	protected int getGrain() {
		return grain;
	}

	protected int pickInt() {
		return pickIntBetween(minimum, maximum);
	}

	protected double pickDouble() {
		return pickDoubleBetween(minimum, maximum);
	}

	protected int pickIntAbove(int minimum) throws RangeError {
		if (minimum > maximum) {
			throw new RangeError("Can't pick above " + minimum
					+ ", this is more than the range maximum " + maximum);
		}
		if (minimum < this.minimum) {
			minimum = this.minimum;
		}
		return pickIntBetween(minimum, maximum);
	}

	protected double pickDoubleAbove(double minimum) throws RangeError {
		if (minimum > maximum) {
			throw new RangeError("Can't pick above " + minimum
					+ ", this is more than the range maximum " + maximum);
		}
		if (minimum < this.minimum) {
			minimum = this.minimum;
		}
		return pickDoubleBetween(minimum, maximum);
	}

	protected int pickIntBelow(int maximum) throws RangeError {
		if (maximum < minimum) {
			throw new RangeError("Can't pick below " + maximum
					+ ", this is less than the range minimum " + minimum);
		}
		if (maximum > this.maximum) {
			maximum = this.maximum;
		}
		return pickIntBetween(minimum, maximum);
	}

	protected double pickDoubleBelow(double maximum) throws RangeError {
		if (maximum < minimum) {
			throw new RangeError("Can't pick below " + maximum
					+ ", this is less than the range minimum " + minimum);
		}
		if (maximum > this.maximum) {
			maximum = this.maximum;
		}
		return pickDoubleBetween(minimum, maximum);
	}

	public int pickIntBetween(int minimum, int maximum) {
		if (minimum == maximum) {
			return minimum;
		} else if (minimum > maximum) {
			return pickIntBetween(maximum, minimum);
		} else {
			if (uniform) {
				return picker.nextInt(maximum - minimum) + minimum;
			} else {
				double picked = average + picker.nextGaussian()
						* standardDeviation;
				int result = ((int) Math.rint(picked / grain)) * grain;
				if (result < minimum) {
					result = minimum;
				} else if (result > maximum) {
					result = maximum;
				}
				return result;
			}
		}

	}

	public double pickDoubleBetween(double minimum, double maximum) {
		if (uniform) {
			return (maximum - minimum) * picker.nextDouble() + minimum;
		} else {
			double result = average + picker.nextGaussian() * standardDeviation;
			if (result < minimum) {
				result = minimum;
			} else if (result > maximum) {
				result = maximum;
			}
			return result;
		}
	}

	protected class RangeError extends Exception {
		/**
		 * 
		 */
		private static final long serialVersionUID = -8542724890308458514L;

		protected RangeError(String message) {
			super(message);
		}
	}

	public final static Spread ONE = new Spread(1, 1);
	public final static Spread ONE_TO_THREE = new Spread(1, 3);
	public final static Spread THREE_TO_SIX = new Spread(3, 6);
	public final static Spread SIX_TO_TWELVE = new Spread(6, 12);
	public final static Spread TWELVE_TO_TWENTY_FIVE = new Spread(12, 25);
	public final static Spread LOW_CONNECTIVITY = new Spread(1.5, 0.5, 0, 0, 4);
	public final static Spread MEDIUM_CONNECTIVITY = new Spread(2.5, 0.5, 0, 0,
			6);
	public final static Spread HIGH_CONNECTIVITY = new Spread(3.5, 0.8, 0, 0, 6);
	public final static Spread HIGH_ADJUSTMENT = new Spread(5.0, 20.0, 5, -95,
			100);
	public final static Spread MEDIUM_ADJUSTMENT = new Spread(0.0, 30.0, 10,
			-90, 100);
	public final static Spread LOW_ADJUSTMENT = new Spread(-5.0, 40.0, 10, -90,
			100);
	public final static Spread VERY_LOW_ADJUSTMENT = new Spread(-15.0, 50.0,
			10, -90, 100);
}