package tests;

public class ChallengeMAPPEDtests extends MazeTest {

	public void testEXTRA_MILD_0() {
		runTests(Challenge.MAPPED, new AbsoluteTester("EXTRA_MILD", 0, 13));
	}

	public void testEXTRA_MILD_1() {
		runTests(Challenge.MAPPED, new AbsoluteTester("EXTRA_MILD", 1, 13));
	}

	public void testEXTRA_MILD_2() {
		runTests(Challenge.MAPPED, new AbsoluteTester("EXTRA_MILD", 2, 13));
	}

	public void testEXTRA_MILD_3() {
		runTests(Challenge.MAPPED, new AbsoluteTester("EXTRA_MILD", 3, 13));
	}

	public void testEXTRA_MILD_4() {
		runTests(Challenge.MAPPED, new AbsoluteTester("EXTRA_MILD", 4, 13));
	}

	public void testMILD_0() {
		runTests(Challenge.MAPPED, new AbsoluteTester("MILD", 0, 13));
	}

	public void testMILD_1() {
		runTests(Challenge.MAPPED, new AbsoluteTester("MILD", 1, 13));
	}

	public void testMILD_2() {
		runTests(Challenge.MAPPED, new AbsoluteTester("MILD", 2, 13));
	}

	public void testMILD_3() {
		runTests(Challenge.MAPPED, new AbsoluteTester("MILD", 3, 13));
	}

	public void testMILD_4() {
		runTests(Challenge.MAPPED, new AbsoluteTester("MILD", 4, 13));
	}

	public void testMEDIUM_MILD_0() {
		runTests(Challenge.MAPPED, new AbsoluteTester("MEDIUM_MILD", 0, 13));
	}

	public void testMEDIUM_MILD_1() {
		runTests(Challenge.MAPPED, new AbsoluteTester("MEDIUM_MILD", 1, 14));
	}

	public void testMEDIUM_MILD_2() {
		runTests(Challenge.MAPPED, new AbsoluteTester("MEDIUM_MILD", 2, 13));
	}

	public void testMEDIUM_MILD_3() {
		runTests(Challenge.MAPPED, new AbsoluteTester("MEDIUM_MILD", 3, 13));
	}

	public void testMEDIUM_MILD_4() {
		runTests(Challenge.MAPPED, new AbsoluteTester("MEDIUM_MILD", 4, 13));
	}

	public void testMEDIUM_0() {
		runTests(Challenge.MAPPED, new AbsoluteTester("MEDIUM", 0, 13));
	}

	public void testMEDIUM_1() {
		runTests(Challenge.MAPPED, new AbsoluteTester("MEDIUM", 1, 13));
	}

	public void testMEDIUM_2() {
		runTests(Challenge.MAPPED, new AbsoluteTester("MEDIUM", 2, 13));
	}

	public void testMEDIUM_3() {
		runTests(Challenge.MAPPED, new AbsoluteTester("MEDIUM", 3, 13));
	}

	public void testMEDIUM_4() {
		runTests(Challenge.MAPPED, new AbsoluteTester("MEDIUM", 4, 13));
	}

	public void testMEDIUM_HOT_0() {
		runTests(Challenge.MAPPED, new AbsoluteTester("MEDIUM_HOT", 0, 13));
	}

	public void testMEDIUM_HOT_1() {
		runTests(Challenge.MAPPED, new AbsoluteTester("MEDIUM_HOT", 1, 14));
	}

	public void testMEDIUM_HOT_2() {
		runTests(Challenge.MAPPED, new AbsoluteTester("MEDIUM_HOT", 2, 13));
	}

	public void testMEDIUM_HOT_3() {
		runTests(Challenge.MAPPED, new AbsoluteTester("MEDIUM_HOT", 3, 13));
	}

	public void testMEDIUM_HOT_4() {
		runTests(Challenge.MAPPED, new AbsoluteTester("MEDIUM_HOT", 4, 16));
	}

	public void testHOT_0() {
		runTests(Challenge.MAPPED, new AbsoluteTester("HOT", 0, 20));
	}

	public void testHOT_1() {
		runTests(Challenge.MAPPED, new AbsoluteTester("HOT", 1, 18));
	}

	public void testHOT_2() {
		runTests(Challenge.MAPPED, new AbsoluteTester("HOT", 2, 14));
	}

	public void testHOT_3() {
		runTests(Challenge.MAPPED, new AbsoluteTester("HOT", 3, 18));
	}

	public void testHOT_4() {
		runTests(Challenge.MAPPED, new AbsoluteTester("HOT", 4, 15));
	}

	public void testEXTRA_HOT_0() {
		runTests(Challenge.MAPPED, new AbsoluteTester("EXTRA_HOT", 0, 20));
	}

	public void testEXTRA_HOT_1() {
		runTests(Challenge.MAPPED, new AbsoluteTester("EXTRA_HOT", 1, 18));
	}

	public void testEXTRA_HOT_2() {
		runTests(Challenge.MAPPED, new AbsoluteTester("EXTRA_HOT", 2, 20));
	}

	public void testEXTRA_HOT_3() {
		runTests(Challenge.MAPPED, new AbsoluteTester("EXTRA_HOT", 3, 14));
	}

	public void testEXTRA_HOT_4() {
		runTests(Challenge.MAPPED, new AbsoluteTester("EXTRA_HOT", 4, 14));
	}

	public void testKILLER_0() {
		runTests(Challenge.MAPPED, new AbsoluteTester("KILLER", 0, 25));
	}

	public void testKILLER_1() {
		runTests(Challenge.MAPPED, new AbsoluteTester("KILLER", 1, 25));
	}

	public void testKILLER_2() {
		runTests(Challenge.MAPPED, new AbsoluteTester("KILLER", 2, 22));
	}

	public void testKILLER_3() {
		runTests(Challenge.MAPPED, new AbsoluteTester("KILLER", 3, 22));
	}

	public void testKILLER_4() {
		runTests(Challenge.MAPPED, new AbsoluteTester("KILLER", 4, 25));
	}

	public void testSUICIDE_0() {
		runTests(Challenge.MAPPED, new AbsoluteTester("SUICIDE", 0, 25));
	}

	public void testSUICIDE_1() {
		runTests(Challenge.MAPPED, new AbsoluteTester("SUICIDE", 1, 26));
	}

	public void testSUICIDE_2() {
		runTests(Challenge.MAPPED, new AbsoluteTester("SUICIDE", 2, 26));
	}

	public void testSUICIDE_3() {
		runTests(Challenge.MAPPED, new AbsoluteTester("SUICIDE", 3, 30));
	}

	public void testSUICIDE_4() {
		runTests(Challenge.MAPPED, new AbsoluteTester("SUICIDE", 4, 25));
	}

}