package tests;

public class ChallengeUNMAPPEDtests extends MazeTest {

	public void testEXTRA_MILD_0() {
		runTests(Challenge.UNMAPPED, new ComparativeTester("EXTRA_MILD", 0, 13,
				100));
	}

	public void testEXTRA_MILD_1() {
		runTests(Challenge.UNMAPPED, new ComparativeTester("EXTRA_MILD", 1, 13,
				92));
	}

	public void testEXTRA_MILD_2() {
		runTests(Challenge.UNMAPPED, new ComparativeTester("EXTRA_MILD", 2, 13,
				100));
	}

	public void testEXTRA_MILD_3() {
		runTests(Challenge.UNMAPPED, new ComparativeTester("EXTRA_MILD", 3, 13,
				100));
	}

	public void testEXTRA_MILD_4() {
		runTests(Challenge.UNMAPPED, new ComparativeTester("EXTRA_MILD", 4, 13,
				100));
	}

	public void testMILD_0() {
		runTests(Challenge.UNMAPPED, new ComparativeTester("MILD", 0, 13, 90));
	}

	public void testMILD_1() {
		runTests(Challenge.UNMAPPED, new ComparativeTester("MILD", 1, 13, 95));
	}

	public void testMILD_2() {
		runTests(Challenge.UNMAPPED, new ComparativeTester("MILD", 2, 13, 100));
	}

	public void testMILD_3() {
		runTests(Challenge.UNMAPPED, new ComparativeTester("MILD", 3, 13, 100));
	}

	public void testMILD_4() {
		runTests(Challenge.UNMAPPED, new ComparativeTester("MILD", 4, 13, 100));
	}

	public void testMEDIUM_MILD_0() {
		runTests(Challenge.UNMAPPED, new ComparativeTester("MEDIUM_MILD", 0,
				13, 90));
	}

	public void testMEDIUM_MILD_1() {
		runTests(Challenge.UNMAPPED, new ComparativeTester("MEDIUM_MILD", 1,
				14, 95));
	}

	public void testMEDIUM_MILD_2() {
		runTests(Challenge.UNMAPPED, new ComparativeTester("MEDIUM_MILD", 2,
				13, 100));
	}

	public void testMEDIUM_MILD_3() {
		runTests(Challenge.UNMAPPED, new ComparativeTester("MEDIUM_MILD", 3,
				13, 100));
	}

	public void testMEDIUM_MILD_4() {
		runTests(Challenge.UNMAPPED, new ComparativeTester("MEDIUM_MILD", 4,
				13, 93));
	}

	public void testMEDIUM_0() {
		runTests(Challenge.UNMAPPED, new ComparativeTester("MEDIUM", 0, 13, 93));
	}

	public void testMEDIUM_1() {
		runTests(Challenge.UNMAPPED,
				new ComparativeTester("MEDIUM", 1, 13, 100));
	}

	public void testMEDIUM_2() {
		runTests(Challenge.UNMAPPED,
				new ComparativeTester("MEDIUM", 2, 13, 100));
	}

	public void testMEDIUM_3() {
		runTests(Challenge.UNMAPPED,
				new ComparativeTester("MEDIUM", 3, 13, 100));
	}

	public void testMEDIUM_4() {
		runTests(Challenge.UNMAPPED, new ComparativeTester("MEDIUM", 4, 14, 93));
	}

	public void testMEDIUM_HOT_0() {
		runTests(Challenge.UNMAPPED, new ComparativeTester("MEDIUM_HOT", 0, 13,
				100));
	}

	public void testMEDIUM_HOT_1() {
		runTests(Challenge.UNMAPPED, new ComparativeTester("MEDIUM_HOT", 1, 16,
				100));
	}

	public void testMEDIUM_HOT_2() {
		runTests(Challenge.UNMAPPED, new ComparativeTester("MEDIUM_HOT", 2, 18,
				86));
	}

	public void testMEDIUM_HOT_3() {
		runTests(Challenge.UNMAPPED, new ComparativeTester("MEDIUM_HOT", 3, 16,
				100));
	}

	public void testMEDIUM_HOT_4() {
		runTests(Challenge.UNMAPPED, new ComparativeTester("MEDIUM_HOT", 4, 13,
				100));
	}

	public void testHOT_0() {
		runTests(Challenge.UNMAPPED, new ComparativeTester("HOT", 0, 14, 79));
	}

	public void testHOT_1() {
		runTests(Challenge.UNMAPPED, new ComparativeTester("HOT", 1, 15, 93));
	}

	public void testHOT_2() {
		runTests(Challenge.UNMAPPED, new ComparativeTester("HOT", 2, 15, 36));
	}

	public void testHOT_3() {
		runTests(Challenge.UNMAPPED, new ComparativeTester("HOT", 3, 14, 100));
	}

	public void testHOT_4() {
		runTests(Challenge.UNMAPPED, new ComparativeTester("HOT", 4, 20, 91));
	}

	public void testEXTRA_HOT_0() {
		runTests(Challenge.UNMAPPED, new ComparativeTester("EXTRA_HOT", 0, 15,
				79));
	}

	public void testEXTRA_HOT_1() {
		runTests(Challenge.UNMAPPED, new ComparativeTester("EXTRA_HOT", 1, 15,
				87));
	}

	public void testEXTRA_HOT_2() {
		runTests(Challenge.UNMAPPED, new ComparativeTester("EXTRA_HOT", 2, 18,
				95));
	}

	public void testEXTRA_HOT_3() {
		runTests(Challenge.UNMAPPED, new ComparativeTester("EXTRA_HOT", 3, 14,
				93));
	}

	public void testEXTRA_HOT_4() {
		runTests(Challenge.UNMAPPED, new ComparativeTester("EXTRA_HOT", 4, 18,
				95));
	}

	public void testKILLER_0() {
		runTests(Challenge.UNMAPPED, new ComparativeTester("KILLER", 0, 26, 90));
	}

	public void testKILLER_1() {
		runTests(Challenge.UNMAPPED, new ComparativeTester("KILLER", 1, 30, 92));
	}

	public void testKILLER_2() {
		runTests(Challenge.UNMAPPED, new ComparativeTester("KILLER", 2, 30, 95));
	}

	public void testKILLER_3() {
		runTests(Challenge.UNMAPPED, new ComparativeTester("KILLER", 3, 35, 92));
	}

	public void testKILLER_4() {
		runTests(Challenge.UNMAPPED, new ComparativeTester("KILLER", 4, 26, 88));
	}

	public void testSUICIDE_0() {
		runTests(Challenge.UNMAPPED,
				new ComparativeTester("SUICIDE", 0, 22, 68));
	}

	public void testSUICIDE_1() {
		runTests(Challenge.UNMAPPED,
				new ComparativeTester("SUICIDE", 1, 26, 59));
	}

	public void testSUICIDE_2() {
		runTests(Challenge.UNMAPPED,
				new ComparativeTester("SUICIDE", 2, 22, 86));
	}

	public void testSUICIDE_3() {
		runTests(Challenge.UNMAPPED,
				new ComparativeTester("SUICIDE", 3, 26, 93));
	}

	public void testSUICIDE_4() {
		runTests(Challenge.UNMAPPED,
				new ComparativeTester("SUICIDE", 4, 30, 65));
	}

}