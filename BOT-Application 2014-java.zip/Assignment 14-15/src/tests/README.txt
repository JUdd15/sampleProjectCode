This package provides facilities for testing bot implementations.  These are
used by the tester GUI in the main package, but they can also be run
independently as JUnit tests (ChallengeMAPPEDtests and ChallengeUNMAPPEDtests).
Note that if you do this there may be some diferences between the tests run
by the JUnit tests, and the tests run by the tester GUI:
  - the test mazes may be tested in a different order
  - the number of bots sent through the mazes may differ

There is no need to study the code in this package.