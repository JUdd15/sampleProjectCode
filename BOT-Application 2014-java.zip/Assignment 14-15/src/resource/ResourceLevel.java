package resource;

import util.Copyable;

/**
 * Models the resource level of a bot. The resource level can never be more than
 * 100%, nor less than 0%.
 * 
 * 
 * @version November 2013
 * 
 */
public class ResourceLevel extends BoundInteger implements
		Copyable<ResourceLevel> {
	private final static Range RANGE = new Range(0, 100);

	/**
	 * Initialises the value of this resource. Any initial value may be passed
	 * as a parameter, but the actual value will be limited to the range [0,100]
	 * 
	 * @param value
	 *            the initial level of the resource
	 * @throws Exhausted
	 */
	public ResourceLevel(int value) {
		super(RANGE, value);
	}

	/**
	 * Adjust a resource level.
	 * 
	 * @param adjustment
	 *            the amount to adjust the level by
	 * @throws Exhausted
	 *             if the adjust causes the level to reach zero
	 */
	public void adjust(ResourceAdjustment adjustment) throws Exhausted {
		setValue(getValue() + adjustment.getValue());
		if (getValue() == 0) {
			throw new Exhausted();
		}
	}

	private static final int SPAWN_COST = 10;

	/**
	 * @return the resource level that will remain after spawning a bot.
	 */
	public ResourceLevel afterSpawning() {
		int newLevel = (getValue() / 2) - SPAWN_COST;
		return new ResourceLevel(newLevel);
	}

	@Override
	public ResourceLevel copyOf() {
		return new ResourceLevel(getValue());
	}

	/**
	 * Reports a resource being exhausted (reaching zero)
	 */
	public class Exhausted extends Exception {
		/**
		 * 
		 */
		private static final long serialVersionUID = 5303244825434164666L;

		public Exhausted() {
			super("The resource is exhausted");
		}
	}
}
