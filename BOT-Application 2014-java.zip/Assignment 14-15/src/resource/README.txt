This package defines resources and resource adjustment.  Resources and resource
adjusments are both bound values, restricted to a given range (resources must 
be in the range [0,100] and resource adjustments in the range [-100,100]).

The Range class is used to define ranges, and applied in BoundedInteger to define
bound integer values.  Resource and ResourceAdjustment are then subclasses of
BoundedInteger, binding these values to the required ranges.