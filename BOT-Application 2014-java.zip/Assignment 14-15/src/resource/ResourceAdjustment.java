package resource;

import util.Copyable;

/**
 * Models the resource level of a bot. The resource level can never be more than
 * 100%, nor less than 0%.
 * 
 * 
 * @version November 2013
 * 
 */
public class ResourceAdjustment extends BoundInteger implements
		Copyable<ResourceAdjustment> {
	private final static Range RANGE = new Range(-100, 100);

	/**
	 * Initialise the level of this resource adjustment. Any value may be passed
	 * as the parameter but the actual value will be restricted to the range
	 * [-100,100].
	 * 
	 * @param level
	 *            the level of this resource adjustment
	 */
	public ResourceAdjustment(int level) {
		super(RANGE, level);
	}

	@Override
	public ResourceAdjustment copyOf() {
		return new ResourceAdjustment(getValue());
	}

}