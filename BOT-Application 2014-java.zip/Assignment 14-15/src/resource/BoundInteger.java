package resource;

/**
 * Implements an integer bound to a certain range.
 * 
 * 
 * 
 * @version November 2013
 * 
 */
public class BoundInteger {
	private Range range;
	private int value;

	public BoundInteger(Range range, int value) {
		this.range = range;
		setValue(value);
	}

	public int getValue() {
		return value;
	}

	public void setValue(int value) {
		this.value = range.restrict(value);
	}

	@Override
	public String toString() {
		return String.valueOf(value);
	}

}
