This folder and its subfolders contain the specifications of the maps used
in the tests.

Each map starts with a comment giving the length(s) of the shortest route(s)
to an exit node from the entry node(s).

This is followed by a specification of the nodes in the maze.  The figure
between parentheses is the resource adjustment in force at that node.  A figure
between brackets following this indicates that the node is an entry node,
and the figure is the length of the shortest path from this entry node to an 
exit node.  A '*' indicates that a node is an exit node.

The map specification concludes with a listing of all the links in the maze.