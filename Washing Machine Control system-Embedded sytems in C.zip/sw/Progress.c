#include "Progress.h"
#include "Delay.h"

/*  Convert from temperature vale to ADC result number */
#define TEMP_TO_ADC(t) ((t) * (unsigned)1023 / 100)

void progress_fill() {
  PORTD = 0b00000001; /* Turn LED RD0 on */
  del(2);             /* Delay 2 sec     */
}

void progress_heater(char nTemperature) {
  PORTD = 0b00000010; /* Turn LED RD1 on */
  
  /* Wait the temperature reach the desired value */
  while (ADC_Read(1) < TEMP_TO_ADC(nTemperature));
}

void progress_prewash() {
  char i;

  for (i = 0; i < 3; ++i) {
    PORTD = 0b00000100; /* Turn LED RD2 on */
    del(2);             /* Delay 2 sec     */

    PORTD = 0b000000000; /* Turn all LEDs off  */
    del(2);              /* Delay 2 sec        */
  }
}

void progress_wash() {
  PORTD = 0b00001000; /* Turn LED RD3 on */
  del(4);             /* Delay 4 sec     */
}

void progress_drain() {
  PORTD = 0b00100000; /* Turn LED RD5 on */
  del(3);             /* Delay 3 sec     */
}

void progress_rinse() {
  char i;

  for (i = 0; i < 2; ++i) {
    PORTD = 0b00011001; /* Turn LED RD0, RD3 and RD4 on */
    del(2);             /* Delay 2 sec                  */

    PORTD = 0b00010000; /* Turn LED RD4 on */
    del(1);             /* Delay 1 sec     */
  }
}

void progress_spin() {
  PORTD = 0b00100000; /* Turn LED RD5 on */
  del(5);             /* Delay 5 sec     */
}

void progress_end() {
  char i;

  /* Turn LED RD7 on and off 5 sec */
  for (i = 0; i < 5; ++i) {
    PORTD = 0b10000000; /* Turn LED RD7 on */
    del_half(1);        /* Wait half sec   */
    
    PORTD = 0b00000000; /* Turn LED RD7 off */
    del_half(1);        /* Wait half sec    */
  }
}