#ifndef __PROGRAM_H__
#define __PROGRAM_H__

void program_QuickWash();
void program_Wool();
void program_ColdWash();
void program_Cotton();
void program_Jeans();
void program_Synthetics();
void program_Delicates();

#endif /* __PROGRAM_H__ */
