#include "Program.h"
#include "Progress.h"

#define TEMP_DEFAULT 40

void program_QuickWash() {
  TRISD = 0x00; /* Port D as output */

  progress_fill();
  progress_heater(TEMP_DEFAULT);
  progress_prewash();
  progress_drain();
  progress_rinse();
  progress_spin();
  progress_end();
}

void program_Wool() {
  TRISD = 0x00; /* Port D as output */

  progress_fill();
  progress_heater(TEMP_DEFAULT);
  progress_prewash();
  progress_wash();
  progress_drain();
  progress_rinse();
  progress_spin();
  progress_end();
}

void program_ColdWash() {
  TRISD = 0x00; /* Port D as output */

  progress_fill();
  progress_heater(TEMP_DEFAULT);
  progress_prewash();
  progress_wash();
  progress_drain();
  progress_rinse();
  progress_spin();
  progress_end();
}

void program_Cotton() {
  TRISD = 0x00; /* Port D as output */

  progress_fill();
  progress_heater(60);
  progress_prewash();
  progress_wash();
  progress_drain();
  progress_rinse();
  progress_spin();
  progress_end();
}

void program_Jeans() {
  TRISD = 0x00; /* Port D as output */

  progress_fill();
  progress_heater(TEMP_DEFAULT);
  progress_prewash();
  progress_wash();
  progress_drain();
  progress_rinse();
  progress_spin();
  progress_end();
}

void program_Synthetics() {
  TRISD = 0x00; /* Port D as output */

  progress_fill();
  progress_heater(60);
  progress_prewash();
  progress_wash();
  progress_drain();
  progress_rinse();
  progress_spin();
  progress_end();
}

void program_Delicates() {
  TRISD = 0x00; /* Port D as output */

  progress_fill();
  progress_heater(TEMP_DEFAULT);
  progress_wash();
  progress_drain();
  progress_rinse();
  progress_end();
}