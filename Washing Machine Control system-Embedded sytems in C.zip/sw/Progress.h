#ifndef __PROGRESS_H__
#define __PROGRESS_H__

void progress_fill();
void progress_heater(char nTemperature);
void progress_prewash();
void progress_wash();
void progress_drain();
void progress_rinse();
void progress_spin();
void progress_end();

#endif /* __PROGRESS_H__ */