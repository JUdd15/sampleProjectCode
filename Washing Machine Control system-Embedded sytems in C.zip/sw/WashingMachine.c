#include "Program.h"

// 1. Assume LCD connected to PORT B

// LCD module connections
sbit LCD_RS at RB4_bit;
sbit LCD_EN at RB5_bit;
sbit LCD_D4 at RB0_bit;
sbit LCD_D5 at RB1_bit;
sbit LCD_D6 at RB2_bit;
sbit LCD_D7 at RB3_bit;

sbit LCD_RS_Direction at TRISB4_bit;
sbit LCD_EN_Direction at TRISB5_bit;
sbit LCD_D4_Direction at TRISB0_bit;
sbit LCD_D5_Direction at TRISB1_bit;
sbit LCD_D6_Direction at TRISB2_bit;
sbit LCD_D7_Direction at TRISB3_bit;
// End LCD module connections

char* s_apOptions[] = {
    "Quick Wash"
  , "Wool"
  , "Cold Wash"
  , "Cotton at 60 degrees"
  , "Jeans"
  , "Synthetics at 50 degrees"
  , "Delicates at 30 degrees"
};

/* *****************************************************************************
  displayOptions
  
  Display list of wash options
***************************************************************************** */
static void displayOptions(
  char iSelection
) {
  Lcd_Cmd(_LCD_CLEAR);
  Lcd_Out(1, 1, "Select Program");
  Lcd_Out(2, 1, s_apOptions[iSelection]);
}

static void displaySelected(
  char iSelection
) {
  Lcd_Cmd(_LCD_CLEAR);
  Lcd_Out(1, 1, s_apOptions[iSelection]);
}

/* *****************************************************************************
  getOption
  
  Display list of wash options and use dispswitches connected to PORTD to select
  the desired wash program. Use RD0 and RD1 to move up and down the list and RD2
  to select the display wash option. RD3 is used to cancel the selection.
***************************************************************************** */
static char getOption(
) {
  char iSelection = 0;

  TRISD = 0xFF; /* Port D as input */
  
  displayOptions(iSelection);
  while (1) {
    if (Button(&PORTD, 0, 1, 1)) {      /* move up */
      if ((iSelection - 1) >= 0) {      /* any previous item? */
        displayOptions(--iSelection);   /* select previous item */
      }
      while (Button(&PORTD, 0, 1, 1));  /* wait button released */
    }
    else if (Button(&PORTD, 1, 1, 1)) { /* move down */
      if ((iSelection + 1) < 7) {       /* any next item? */
        displayOptions(++iSelection);   /* select next item */
      }
      while (Button(&PORTD, 1, 1, 1));  /* wait button released */
    }
    else if (Button(&PORTD, 2, 1, 1)) { /* select */
      displaySelected(iSelection);
      while (Button(&PORTD, 2, 1, 1));  /* wait button released */
      return iSelection;                /* return selected index */
    }
  }

  return 0;
}

void main(
) {
  Lcd_Init();                        // Initialize LCD

  Lcd_Cmd(_LCD_CLEAR);               // Clear display
  Lcd_Cmd(_LCD_CURSOR_OFF);          // Cursor off

program_start:
  do {
    char iOption = getOption();
    
    /* wait door closed */
    while (!Button(&PORTD, 6, 1, 1)) {
      if (Button(&PORTD, 3, 1, 1)) { /* cancel */
        goto program_start;          /* If user press cancel button */
      }
    }
    
    /* wait start button */
    while (!Button(&PORTD, 7, 1, 1)) {
      if (Button(&PORTD, 3, 1, 1)) { /* cancel */
        goto program_start;          /* If user press cancel button */
      }
    }

    switch (iOption) { /* User selection */
      case 0: { /* Quick Wash */
        program_QuickWash();
      }
      break;

      case 1: { /* Wool */
        program_Wool();
      }
      break;

      case 2: { /* Cold Wash */
        program_ColdWash();
      }
      break;

      case 3: { /* Cotton at 60 degrees */
        program_Cotton();
      }
      break;

      case 4: { /* Jeans */
        program_Jeans();
      }

      case 5: { /* Synthetics at 50 degrees */
        program_Synthetics();
      }
      break;

      case 6: { /* Delicates at 30 degrees */
        program_Delicates();
      }
      break;
    }
  } while (1);
}