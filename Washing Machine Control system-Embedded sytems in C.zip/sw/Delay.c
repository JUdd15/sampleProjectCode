#include "Delay.h"

#define LOBYTE(n) ((unsigned char)((n) & 0xFF))
#define HIBYTE(n) ((unsigned char)(((n) >>  8) & 0xFF))

#define FOSC 3.2768e6  /* Oscilator Frequency = 3.2768 MHz */
#define PRESCALER 8
#define FOUT 2         /* Output Frequency = 2 Hz. We use 2 Hz output since imposible to generate 1 Hz output */
#define COUNT_HALF_SECOND ((unsigned short)(65536 - FOSC / (4 * PRESCALER  * FOUT)))

static volatile char s_nDel;

/* *****************************************************************************
  setup
  
  Setting up and start the TIMER1 for delay functiona
***************************************************************************** */
static void setup() {
  /*
    Timer 1
    -------
    Prescaler: 8
    Used internal clock pulses
    Synchronise external pulses
    Use internal clock
    Timer1 stop
  */
  T1CON = 0x30;

  /* Counter value for half second */
  TMR1H  = HIBYTE(COUNT_HALF_SECOND);
  TMR1L  = LOBYTE(COUNT_HALF_SECOND);

  TMR1IF_bit = 0;
  TMR1ON_bit = 1; /* Start Timer 1 */
  
  TMR1IE_bit = 1; /* Enable Timer 1 interrupt       */
  PEIE_bit   = 1; /* Enable Peripheral interrupts   */
  GIE_bit    = 1; /* Enable all selected interrupts */
}

/* *****************************************************************************
  del
  
  Delay seconds
***************************************************************************** */
void del(char nSeconds) {
  s_nDel = nSeconds * 2; /* number of half second */
  
  setup();
  while (s_nDel != 0); /* wait reach zero */
}

/* *****************************************************************************
  del_half
  
  Delay half seconds
***************************************************************************** */
void del_half(char nHalfSecond) {
  s_nDel = nHalfSecond;
  
  setup();
  while (s_nDel != 0); /* wait reach zero */
}

/* Interrupt occurs every half second */
void interrupt() {
  GIE_bit = 0; /* Disable all interrupts */
  
  TMR1IF_bit = 0;
  
  /* Counter value for half second */
  TMR1H  = HIBYTE(COUNT_HALF_SECOND);
  TMR1L  = LOBYTE(COUNT_HALF_SECOND);
  
  --s_nDel;

  GIE_bit = 1; /* Enable all interrupts */
}