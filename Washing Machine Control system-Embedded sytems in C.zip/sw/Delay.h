#ifndef __DELAY_H__
#define __DELAY_H__

void del(char nSeconds);
void del_half(char nHalfSecond);

#endif /* __DELAY_H__ */
