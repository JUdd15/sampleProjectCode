package zillionaire;

import java.awt.BorderLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.WindowConstants;

/**
 * This code was edited or generated using CloudGarden's Jigloo SWT/Swing GUI
 * Builder, which is free for non-commercial use. If Jigloo is being used
 * commercially (ie, by a corporation, company or business for any purpose
 * whatever) then you should purchase a license for each developer using Jigloo.
 * Please visit www.cloudgarden.com for details. Use of Jigloo implies
 * acceptance of these licensing terms. A COMMERCIAL LICENSE HAS NOT BEEN
 * PURCHASED FOR THIS MACHINE, SO JIGLOO OR THIS CODE CANNOT BE USED LEGALLY FOR
 * ANY CORPORATE OR COMMERCIAL PURPOSE.
 */
public class CategoryFrame extends javax.swing.JFrame implements ActionListener {
	private JPanel mainPanel;
	private JLabel infoLabel;
	private JLabel moneyBankedLbl;
	private JButton scienceBtn;
	private JButton historyBtn;
	private JButton geography;
	private JButton englishBtn;
	private JButton mathsBtn;
	private JButton generalKnowledge;
	private JPanel northPanel;
	private JPanel bottomPanel;
	static String playerOne;
	private int currentMoney = 0;

	public CategoryFrame(String playerOne, int moneyBanked) {
		super();
		CategoryFrame.playerOne = playerOne;
		this.currentMoney = moneyBanked;
		initGUI();
	}

	private void initGUI() {
		try {
			setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
			{
				mainPanel = new JPanel();
				GridBagLayout mainPanelLayout = new GridBagLayout();
				mainPanelLayout.columnWidths = new int[] { 7, 7 };
				mainPanelLayout.rowHeights = new int[] { 7, 7, 7 };
				mainPanelLayout.columnWeights = new double[] { 0.1, 0.1 };
				mainPanelLayout.rowWeights = new double[] { 0.1, 0.1, 0.1 };
				getContentPane().add(mainPanel, BorderLayout.CENTER);
				mainPanel.setLayout(mainPanelLayout);
				{
					generalKnowledge = new JButton();
					mainPanel.add(generalKnowledge, new GridBagConstraints(0,
							0, 1, 1, 0.0, 0.0, GridBagConstraints.CENTER,
							GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0,
							0));
					generalKnowledge.setText("General Knowledge");
					generalKnowledge.setSize(378, 23);
					generalKnowledge.addActionListener(this);
					if (MainFrame.categoryToBlank.get(0) == 1) {
						generalKnowledge.setEnabled(false);
					}
				}
				{
					mathsBtn = new JButton();
					mainPanel.add(mathsBtn, new GridBagConstraints(1, 0, 1, 1,
							0.0, 0.0, GridBagConstraints.CENTER,
							GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0,
							0));
					mathsBtn.setText("Maths");
					mathsBtn.addActionListener(this);
					if (MainFrame.categoryToBlank.get(3) == 1) {
						mathsBtn.setEnabled(false);
					}
				}
				{
					englishBtn = new JButton();
					mainPanel.add(englishBtn, new GridBagConstraints(0, 1, 1,
							1, 0.0, 0.0, GridBagConstraints.CENTER,
							GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0,
							0));
					englishBtn.setText("English");
					englishBtn.addActionListener(this);
					if (MainFrame.categoryToBlank.get(1) == 1) {
						englishBtn.setEnabled(false);
					}

				}
				{
					geography = new JButton();
					mainPanel.add(geography, new GridBagConstraints(1, 1, 1, 1,
							0.0, 0.0, GridBagConstraints.CENTER,
							GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0,
							0));
					geography.setText("Geography");
					geography.addActionListener(this);
					if (MainFrame.categoryToBlank.get(4) == 1) {
						geography.setEnabled(false);
					}

				}
				{
					historyBtn = new JButton();
					mainPanel.add(historyBtn, new GridBagConstraints(0, 2, 1,
							1, 0.0, 0.0, GridBagConstraints.CENTER,
							GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0,
							0));
					historyBtn.setText("History");
					historyBtn.addActionListener(this);
					if (MainFrame.categoryToBlank.get(2) == 1) {
						historyBtn.setEnabled(false);
					}
				}
				{
					scienceBtn = new JButton();
					mainPanel.add(scienceBtn, new GridBagConstraints(1, 2, 1,
							1, 0.0, 0.0, GridBagConstraints.CENTER,
							GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0,
							0));
					scienceBtn.setText("Science");
					scienceBtn.addActionListener(this);
					if (MainFrame.categoryToBlank.get(5) == 1) {
						scienceBtn.setEnabled(false);
					}
				}
			}
			{
				bottomPanel = new JPanel();
				getContentPane().add(bottomPanel, BorderLayout.SOUTH);
				{
					moneyBankedLbl = new JLabel();
					bottomPanel.add(moneyBankedLbl);
					moneyBankedLbl.setText("Money banked: �" + currentMoney);
				}
			}
			{
				northPanel = new JPanel();
				getContentPane().add(northPanel, BorderLayout.NORTH);
				{
					infoLabel = new JLabel();
					northPanel.add(infoLabel);
					infoLabel.setText("Welcome " + playerOne
							+ ", please choose a category");
				}
			}
			pack();
			setSize(400, 300);
		} catch (Exception e) {
		}
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		String s = e.getActionCommand();
		if (s == "General Knowledge") {
			this.dispose();
			AnswerFrame inst = new AnswerFrame(currentMoney,
					"General Knowledge");
			inst.setLocationRelativeTo(null);
			inst.setVisible(true);
		}

		if (s == "English") {
			AnswerFrame inst = new AnswerFrame(currentMoney, "English");
			inst.setLocationRelativeTo(null);
			inst.setVisible(true);
		}
		if (s == "History") {
			AnswerFrame inst = new AnswerFrame(currentMoney, "History");
			inst.setLocationRelativeTo(null);
			inst.setVisible(true);
		}
		if (s == "Maths") {
			AnswerFrame inst = new AnswerFrame(currentMoney, "Maths");
			inst.setLocationRelativeTo(null);
			inst.setVisible(true);
		}
		if (s == "Geography") {
			AnswerFrame inst = new AnswerFrame(currentMoney, "Geography");
			inst.setLocationRelativeTo(null);
			inst.setVisible(true);
		}
		if (s == "Science") {
			AnswerFrame inst = new AnswerFrame(currentMoney, "Science");
			inst.setLocationRelativeTo(null);
			inst.setVisible(true);
		}
	}

}
