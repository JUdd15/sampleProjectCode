package zillionaire;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.ArrayList;

import javax.swing.ComboBoxModel;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.WindowConstants;
import javax.imageio.*;

/**
 * This code was edited or generated using CloudGarden's Jigloo SWT/Swing GUI
 * Builder, which is free for non-commercial use. If Jigloo is being used
 * commercially (ie, by a corporation, company or business for any purpose
 * whatever) then you should purchase a license for each developer using Jigloo.
 * Please visit www.cloudgarden.com for details. Use of Jigloo implies
 * acceptance of these licensing terms. A COMMERCIAL LICENSE HAS NOT BEEN
 * PURCHASED FOR THIS MACHINE, SO JIGLOO OR THIS CODE CANNOT BE USED LEGALLY FOR
 * ANY CORPORATE OR COMMERCIAL PURPOSE.
 */
public class MainFrame extends javax.swing.JFrame implements ItemListener,
		ActionListener {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel jPanel1;
	private JLabel playerLabel;
	private JTextField jTextField1;
	private JLabel playerTwoName;
	private JLabel playerThreeName;
	private JTextField jTextField2;
	private JPanel playerThreePanel;
	private JPanel playerTwoPanel;
	private JPanel playerOnePanel;
	private JTextField playerOneField;
	private JLabel playerOne;
	private JPanel middlePanel;
	private JPanel jPanel2;
	private JButton Submit;
	private JComboBox<String> jComboBox1;
	static ArrayList<Integer> categoryToBlank = new ArrayList<Integer>();
	static boolean isFiftyFiftyUsed = false;
	static boolean isAskAudienceUsed = false;

	public MainFrame() {
		super();
		initGUI();
		for (int i = 0; i < 6; i++) {
			categoryToBlank.add(0);
		}
	}

	private void initGUI() {
		try {
			setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
			{

				jPanel1 = new JPanel();
				getContentPane().add(jPanel1, BorderLayout.NORTH);
				jPanel1.setPreferredSize(new java.awt.Dimension(422,60));

				jPanel1.setBackground(Color.RED);
				{
					playerLabel = new JLabel();
					jPanel1.add(playerLabel);
					playerLabel.setText("Please select number of players");
				}
				{
					ComboBoxModel jComboBox1Model = new DefaultComboBoxModel(
							new String[] { "One Player", "Two Player","Three Player" });
					jComboBox1 = new JComboBox();
					jPanel1.add(jComboBox1);
					jComboBox1.setModel(jComboBox1Model);
					jComboBox1.addItemListener(this);
				}
			}

			{
				jPanel2 = new JPanel();
				getContentPane().add(jPanel2, BorderLayout.SOUTH);
				jPanel2.setBackground(Color.RED);

				{
					Submit = new JButton();
					jPanel2.add(Submit);
					Submit.setText("Next");
					Submit.addActionListener(this);
				}
			}
			{
				middlePanel = new JPanel();
				BorderLayout middlePanelLayout = new BorderLayout();
				middlePanel.setLayout(middlePanelLayout);
				getContentPane().add(middlePanel, BorderLayout.CENTER);
				middlePanel.setBackground(Color.RED);
				{
					playerOnePanel = new JPanel();
					FlowLayout playerOnePanelLayout = new FlowLayout();
					playerOnePanel.setLayout(playerOnePanelLayout);
					middlePanel.add(playerOnePanel, BorderLayout.NORTH);
					playerOnePanel.setBackground(Color.RED);
					{
						playerOne = new JLabel();
						playerOnePanel.add(playerOne);
						playerOne.setText("Player One Name");
					}
					{
						playerOneField = new JTextField();
						playerOnePanel.add(playerOneField);
						playerOneField.setPreferredSize(new java.awt.Dimension(
								114, 23));
					}
				}
				{
					playerTwoPanel = new JPanel();
					FlowLayout playerTwoPanelLayout = new FlowLayout();
					playerTwoPanel.setLayout(playerTwoPanelLayout);
					middlePanel.add(playerTwoPanel, BorderLayout.CENTER);
					playerTwoPanel.setBackground(Color.RED);
					{
						playerTwoName = new JLabel();
						playerTwoPanel.add(playerTwoName);
						playerTwoName.setText("Player Two Name");
					}
					{
						jTextField1 = new JTextField();
						playerTwoPanel.add(jTextField1);
						jTextField1.setPreferredSize(new java.awt.Dimension(
								114, 23));
					}
					playerThreePanel = new JPanel();
					FlowLayout playerThreePanelLayout = new FlowLayout();
					playerThreePanel.setLayout(playerThreePanelLayout);
					middlePanel.add(playerThreePanel, BorderLayout.SOUTH);
					playerThreePanel.setBackground(Color.RED);
					{
						playerThreeName = new JLabel();
						playerThreePanel.add(playerThreeName);
						playerThreeName.setText("Player Three Name");
					}
					{
						jTextField2 = new JTextField();
						playerThreePanel.add(jTextField2);
						jTextField2.setPreferredSize(new java.awt.Dimension(
								107, 23));
					}
				}
				playerTwoPanel.setVisible(false);
				
				playerThreePanel.setVisible(false);
				
				pack();
			}
			
			
			this.setSize(438,250);
		} catch (Exception e) {
			// add your error handling code here
			e.printStackTrace();
		}
	}
	

	@Override
	public void itemStateChanged(ItemEvent e) {
		if (e.getStateChange() == ItemEvent.SELECTED) {
			String s = e.getItem().toString();
			if (s.equalsIgnoreCase("Two Player")) {
				playerTwoPanel.setVisible(true);
			} else {
				playerTwoPanel.setVisible(true);
			if (s.equalsIgnoreCase("Three Player")){
				playerThreePanel.setVisible(true);
			} else {
				playerThreePanel.setVisible(false);
				
			
			}
			
			}
		}

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		String s = e.getActionCommand();
		String playerOneName = null;
		if (s == "Next") {
			playerOneName = playerOneField.getText();
			if ((jComboBox1.getSelectedIndex() == 0)
					&& (playerOneField.getText().equalsIgnoreCase(""))) {
				JOptionPane.showMessageDialog(this,
						"Please ensure you have entered" + " player name");
			} else if ((jComboBox1.getSelectedIndex() == 1)
					&& (playerOneField.getText().equalsIgnoreCase(""))
					&& (playerTwoName.getText().equalsIgnoreCase("")&& (playerThreeName.getText().equalsIgnoreCase("")))) {
				JOptionPane.showMessageDialog(this,
						"Please ensure you have entered all player names");
			} else {
				this.dispose();
				CategoryFrame inst = new CategoryFrame(playerOneName, 0);
				inst.setLocationRelativeTo(null);
				inst.setVisible(true);
			}
		}
	}

}
