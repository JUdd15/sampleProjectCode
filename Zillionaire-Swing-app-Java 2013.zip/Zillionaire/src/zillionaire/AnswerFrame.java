package zillionaire;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Random;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.WindowConstants;

/**
 * This code was edited or generated using CloudGarden's Jigloo SWT/Swing GUI
 * Builder, which is free for non-commercial use. If Jigloo is being used
 * commercially (ie, by a corporation, company or business for any purpose
 * whatever) then you should purchase a license for each developer using Jigloo.
 * Please visit www.cloudgarden.com for details. Use of Jigloo implies
 * acceptance of these licensing terms. A COMMERCIAL LICENSE HAS NOT BEEN
 * PURCHASED FOR THIS MACHINE, SO JIGLOO OR THIS CODE CANNOT BE USED LEGALLY FOR
 * ANY CORPORATE OR COMMERCIAL PURPOSE.
 */
public class AnswerFrame extends javax.swing.JFrame {
	//GUI Components
	private JPanel InfoPanel;
	private JPanel questionPanel;
	private JButton answerTwoBtn;
	private JButton anwserOneBtn;
	private JPanel bottonPanel;
	private JLabel moneyEarnedLbl;
	private JButton askAudienceBtn;
	private JButton bankBtn;
	private JButton fiftyFiftyBtn;
	private JPanel infoPanel;
	private JPanel buttonPanel;
	private JButton anwserFourBtn;
	private JButton anwserThreeBtn;
	private JPanel middlePanel;
	private JPanel topPanel;
	private JLabel questionLabel;
	private JLabel questionNumberLabel;
	private ArrayList<Question> questionsList;
	private int numberOfQuestions = 3;
	private String correctAnswer;
	private int moneyEarned;
	private JLabel moneyBankedLbl;
	private int moneyBanked;/**Stores the money banked**/
	private String category;/**Stores the category**/
	private Question question;

	/**
	 * Constructor that keeps track of the money banked
	 * @param moneyBanked
	 * @param category
	 */
	public AnswerFrame(int moneyBanked, String category) {
		super();
		try {
			//load the questions for a particular category
			questionsList = QuestionLoader.getQuestions(category);
			this.moneyBanked = moneyBanked;
			this.category = category;
		} catch (FileNotFoundException e) {
			//Error if the file cannot be found
			e.printStackTrace();
		}
		initGUI();

	}

	/**
	 * Gets a random question from the list - It ensures that the same question will not be displayed twice
	 * @return
	 */
	private Question generateRandomQuestion() {
		Random random = new Random();
		int questionNumber = random.nextInt(questionsList.size());
		Question question = questionsList.get(questionNumber);//Removes the question from the list so not to display it twice
		questionsList.remove(questionNumber);
		return question;
	}

	/**
	 * Method to load the GUI
	 */
	private void initGUI() {
		try {
			question = generateRandomQuestion();
			correctAnswer = question.getRightAnswer();
			setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
			this.setTitle("Answer Question");
			{
				topPanel = new JPanel();
				BorderLayout topPanelLayout = new BorderLayout();
				topPanel.setLayout(topPanelLayout);
				getContentPane().add(topPanel, BorderLayout.NORTH);
				{
					InfoPanel = new JPanel();
					topPanel.add(InfoPanel, BorderLayout.NORTH);
					{
						questionNumberLabel = new JLabel();
						InfoPanel.add(questionNumberLabel);
						questionNumberLabel.setText("Question ");
					}
				}
				{
					questionPanel = new JPanel();
					topPanel.add(questionPanel, BorderLayout.CENTER);
					{
						questionLabel = new JLabel();
						questionPanel.add(questionLabel);
					}
				}
			}
			{
				middlePanel = new JPanel();
				GridBagLayout middlePanelLayout = new GridBagLayout();
				middlePanelLayout.columnWidths = new int[] { 7, 7 };
				middlePanelLayout.rowHeights = new int[] { 7, 7 };
				middlePanelLayout.columnWeights = new double[] { 0.1, 0.1 };
				middlePanelLayout.rowWeights = new double[] { 0.1, 0.1 };
				getContentPane().add(middlePanel, BorderLayout.CENTER);
				middlePanel.setLayout(middlePanelLayout);
				{
					anwserOneBtn = new JButton();
					middlePanel.add(anwserOneBtn, new GridBagConstraints(0, 0,
							1, 1, 0.0, 0.0, GridBagConstraints.CENTER,
							GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0,
							0));
				}
				{
					answerTwoBtn = new JButton();
					middlePanel.add(answerTwoBtn, new GridBagConstraints(1, 0,
							1, 1, 0.0, 0.0, GridBagConstraints.CENTER,
							GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0,
							0));
				}
				{
					anwserThreeBtn = new JButton();
					middlePanel.add(anwserThreeBtn, new GridBagConstraints(0,
							1, 1, 1, 0.0, 0.0, GridBagConstraints.CENTER,
							GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0,
							0));
				}
				{
					anwserFourBtn = new JButton();
					middlePanel.add(anwserFourBtn, new GridBagConstraints(1, 1,
							1, 1, 0.0, 0.0, GridBagConstraints.CENTER,
							GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0,
							0));
				}
			}
			{
				bottonPanel = new JPanel();
				BorderLayout bottonPanelLayout = new BorderLayout();
				bottonPanel.setLayout(bottonPanelLayout);
				getContentPane().add(bottonPanel, BorderLayout.SOUTH);
				{
					buttonPanel = new JPanel();
					FlowLayout buttonPanelLayout = new FlowLayout();
					buttonPanel.setLayout(buttonPanelLayout);
					bottonPanel.add(buttonPanel, BorderLayout.CENTER);
					{
						fiftyFiftyBtn = new JButton();
						buttonPanel.add(fiftyFiftyBtn);
						fiftyFiftyBtn.setText("50:50");
						if (MainFrame.isFiftyFiftyUsed) {
							fiftyFiftyBtn.setEnabled(false);
						}
					}
					{
						bankBtn = new JButton();
						buttonPanel.add(bankBtn);
						bankBtn.setText("Bank");
					}
					{
						askAudienceBtn = new JButton();
						buttonPanel.add(askAudienceBtn);
						askAudienceBtn.setText("Ask The Audience");
						if (MainFrame.isAskAudienceUsed) {
							askAudienceBtn.setEnabled(false);
						}
					}
				}
				{
					infoPanel = new JPanel();
					FlowLayout infoPanelLayout = new FlowLayout();
					infoPanel.setLayout(infoPanelLayout);
					bottonPanel.add(infoPanel, BorderLayout.SOUTH);
					{
						moneyEarnedLbl = new JLabel();
						FlowLayout moneyEarnedLblLayout = new FlowLayout();
						moneyEarnedLbl.setLayout(moneyEarnedLblLayout);
						infoPanel.add(moneyEarnedLbl);
						moneyEarnedLbl.setText("Money Earned: �0");
					}
					{
						moneyBankedLbl = new JLabel();
						infoPanel.add(moneyBankedLbl);
						moneyBankedLbl.setText("Money Banked: �" + moneyBanked);
					}
				}
			}
			questionLabel.setText(question.getQuestion());
			anwserOneBtn.setText(question.getAnswerOne());
			answerTwoBtn.setText(question.getAnswerTwo());
			anwserThreeBtn.setText(question.getAnswerThree());
			anwserFourBtn.setText(question.getAnswerFour());
			anwserOneBtn.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent arg0) {
					int answer = JOptionPane.showConfirmDialog(null,
							"Final Answer?", "", JOptionPane.YES_NO_OPTION);
					if (answer == JOptionPane.YES_OPTION) {
						String answerStr = anwserOneBtn.getText();
						if (answerStr.equalsIgnoreCase(correctAnswer)) {
							JOptionPane.showMessageDialog(null,
									"Well Done!, you have earned �1000");
							moneyEarned += 1000;
							moneyEarnedLbl.setText("Money Earned: �"
									+ moneyEarned);
							numberOfQuestions--;
							loadNewQuestion();
						} else {
							JOptionPane.showMessageDialog(null,
									"Incorrect answer, Game Over!! - you are leaving with � "
											+ moneyBanked);
							dispose();
							new MainFrame().setVisible(true);
						}
					}
				}
			});

			answerTwoBtn.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					int answer = JOptionPane.showConfirmDialog(null,
							"Final Answer?", "", JOptionPane.YES_NO_OPTION);
					if (answer == JOptionPane.YES_OPTION) {
						String answerStr = answerTwoBtn.getText();
						if (answerStr.equalsIgnoreCase(correctAnswer)) {
							JOptionPane.showMessageDialog(null,
									"Well Done!, you have earned �1000");
							moneyEarned += 1000;
							moneyEarnedLbl.setText("Money Earned: �"
									+ moneyEarned);
							numberOfQuestions--;
							loadNewQuestion();
						} else {
							JOptionPane.showMessageDialog(null,
									"Incorrect answer, Game Over!! - you are leaving with � "
											+ moneyBanked);
							dispose();
							new MainFrame().setVisible(true);
						}
					}
				}
			});
			anwserThreeBtn.addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
					int answer = JOptionPane.showConfirmDialog(null,
							"Final Answer?", "", JOptionPane.YES_NO_OPTION);
					if (answer == JOptionPane.YES_OPTION) {
						String answerStr = anwserThreeBtn.getText();
						if (answerStr.equalsIgnoreCase(correctAnswer)) {
							JOptionPane.showMessageDialog(null,
									"Well Done!, you have earned �1000");
							moneyEarned += 1000;
							moneyEarnedLbl.setText("Money Earned: �"
									+ moneyEarned);
							numberOfQuestions--;
							loadNewQuestion();
						} else {
							JOptionPane.showMessageDialog(null,
									"Incorrect answer, Game Over!! - you are leaving with � "
											+ moneyBanked);
							dispose();
							new MainFrame().setVisible(true);
						}
					}
				}
			});
			anwserFourBtn.addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
					int answer = JOptionPane.showConfirmDialog(null,
							"Final Answer?", "", JOptionPane.YES_NO_OPTION);
					if (answer == JOptionPane.YES_OPTION) {
						String answerStr = anwserFourBtn.getText();
						if (answerStr.equalsIgnoreCase(correctAnswer)) {
							JOptionPane.showMessageDialog(null,
									"Well Done!, you have earned �1000");
							moneyEarned += 1000;
							moneyEarnedLbl.setText("Money Earned: �"
									+ moneyEarned);
							numberOfQuestions--;
							loadNewQuestion();
						} else {
							JOptionPane.showMessageDialog(null,
									"Incorrect answer, Game Over!! - you are leaving with � "
											+ moneyBanked);
							dispose();
							new MainFrame().setVisible(true);
						}
					}
				}
			});

			bankBtn.addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
					moneyBanked += moneyEarned;
					moneyEarned = 0;
					moneyBankedLbl.setText("Money Banked �" + moneyBanked);
					moneyEarnedLbl.setText("Money Earned �" + moneyEarned);
				}
			});

			fiftyFiftyBtn.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					MainFrame.isFiftyFiftyUsed = true;
					if ((question.getRemoveFirstAnswer() == 1)
							|| (question.getRemoveSecondAnswer() == 1)) {
						anwserOneBtn.setVisible(false);
					}
					if ((question.getRemoveFirstAnswer() == 2)
							|| (question.getRemoveSecondAnswer() == 2)) {
						answerTwoBtn.setVisible(false);
					}
					if ((question.getRemoveFirstAnswer() == 3)
							|| (question.getRemoveSecondAnswer() == 3)) {
						anwserThreeBtn.setVisible(false);
					}
					if ((question.getRemoveFirstAnswer() == 4)
							|| (question.getRemoveSecondAnswer() == 4)) {
						anwserFourBtn.setVisible(false);
					}
					fiftyFiftyBtn.setEnabled(false);
				}
			});

			askAudienceBtn.addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent arg0) {
					MainFrame.isAskAudienceUsed = true;
					JOptionPane.showMessageDialog(
							null,
							"The audience responses is as follows\n"
									+ question.getAnswerOne() + " "
									+ question.getAudienceResponseOne() +"%\n"
									+ question.getAnswerTwo() + " "
									+ question.getAudienceResponseTwo() + "%\n"
									+ question.getAnswerThree() + " "
									+ question.getAudienceResponseThree() + "%\n"
									+ question.getAnswerFour() + " "
									+ question.getAudienceResponseFour() + "%");
					askAudienceBtn.setEnabled(false);

				}
			});
			pack();
			setSize(400, 300);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void loadNewQuestion() {
		if (numberOfQuestions == 0) {
			JOptionPane
					.showMessageDialog(
							null,
							"You have answered all the questions correctly in the category and have automatically banked �3000");
			moneyBanked += moneyEarned;
			this.dispose();
			if (category == "General Knowledge") {
				MainFrame.categoryToBlank.set(0, 1);
			}
			if (category == "English") {
					MainFrame.categoryToBlank.set(1, 1);
			}
			if (category == "History") {
				MainFrame.categoryToBlank.set(2, 1);
			}
			if (category == "Maths") {
				MainFrame.categoryToBlank.set(3, 1);
				
			}
			if (category == "Geography") {
				MainFrame.categoryToBlank.set(4, 1);
			}
			if (category == "Science") {
				MainFrame.categoryToBlank.set(5, 1);
			}
			new CategoryFrame(CategoryFrame.playerOne, moneyBanked)
					.setVisible(true);
		} else {
			Question question = generateRandomQuestion();
			questionLabel.setText(question.getQuestion());
			anwserOneBtn.setText(question.getAnswerOne());
			answerTwoBtn.setText(question.getAnswerTwo());
			anwserThreeBtn.setText(question.getAnswerThree());
			anwserFourBtn.setText(question.getAnswerFour());
			correctAnswer = question.getRightAnswer();
			anwserOneBtn.setVisible(true);
			answerTwoBtn.setVisible(true);
			anwserThreeBtn.setVisible(true);
			anwserFourBtn.setVisible(true);
			this.question = question;

		}
	}

}
