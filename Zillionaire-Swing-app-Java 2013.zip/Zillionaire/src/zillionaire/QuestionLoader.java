

package zillionaire;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.StringTokenizer;

public class QuestionLoader {

	public static ArrayList<Question> getQuestions(String categoryFromScreen)
			throws FileNotFoundException {
		ArrayList<Question> questions = new ArrayList<Question>();
		File file = new File("Questions.txt");
		Scanner scanner = new Scanner(file);
		String line = null;
		while (scanner.hasNext()) {
			line = scanner.nextLine();
			StringTokenizer stringTokenizer = new StringTokenizer(line, ",");
			while (stringTokenizer.hasMoreTokens()) {
				String category = stringTokenizer.nextToken();
				String question = stringTokenizer.nextToken();
				String answer = stringTokenizer.nextToken();
				String answerOne = stringTokenizer.nextToken();
				String answerTwo = stringTokenizer.nextToken();
				String answerThree = stringTokenizer.nextToken();
				String answerFour = stringTokenizer.nextToken();
				int removeFirstAnswer = Integer.parseInt(stringTokenizer
						.nextToken());
				int removeSecondAnswer = Integer.parseInt(stringTokenizer.nextToken());
				int audienceResponseOne = Integer.parseInt(stringTokenizer.nextToken());
				int audienceResponseTwo = Integer.parseInt(stringTokenizer.nextToken());
				int audienceResponseThree = Integer.parseInt(stringTokenizer.nextToken());
				int audienceResponseFour = Integer.parseInt(stringTokenizer.nextToken());
				
				if (category.equalsIgnoreCase(categoryFromScreen)) {
					Question questionObj = new Question();
					questionObj.setQuestion(question);
					questionObj.setRightAnswer(answer);
					questionObj.setAnswerOne(answerOne);
					questionObj.setAnswerTwo(answerTwo);
					questionObj.setAnswerThree(answerThree);
					questionObj.setAnswerFour(answerFour);
					questionObj.setRemoveFirstAnswer(removeFirstAnswer);
					questionObj.setRemoveSecondAnswer(removeSecondAnswer);
					questionObj.setAudienceResponseOne(audienceResponseOne);
					questionObj.setAudienceResponseTwo(audienceResponseTwo);
					questionObj.setAudienceResponseThree(audienceResponseThree);
					questionObj.setAudienceResponseFour(audienceResponseFour);
					questions.add(questionObj);
				}
			}
		}
		scanner.close();
		return questions;

	}

}
