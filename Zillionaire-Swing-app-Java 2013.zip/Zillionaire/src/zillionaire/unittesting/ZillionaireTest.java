package zillionaire.unittesting;

import static org.junit.Assert.assertEquals;

import java.io.FileNotFoundException;
import java.util.ArrayList;

import org.junit.BeforeClass;
import org.junit.Test;

import zillionaire.Question;
import zillionaire.QuestionLoader;

public class ZillionaireTest {

	private QuestionLoader questionLoader = new QuestionLoader();

	@BeforeClass
	public static void beforeClass() {
	}

	/**
	 * Test Method to test the when a question is created and the fields are set
	 * then on getting the fields the correct values are retrieved
	 */
	@Test
	public void testQuestion() {
		Question question = new Question();
		question.setCategory("Test Category");
		question.setRightAnswer("Test Right Answer");
		question.setAnswerOne("Test Answer One");
		question.setAnswerTwo("Test Answer Two");
		question.setAnswerThree("Test Answer Three");
		question.setAnswerFour("Test Answer Four");
		question.setRemoveFirstAnswer(1);
		question.setRemoveSecondAnswer(2);
		question.setAudienceResponseOne(3);
		question.setAudienceResponseTwo(4);
		question.setAudienceResponseThree(5);
		question.setAudienceResponseFour(6);

		assertEquals("Invalid Category", "Test Category",
				question.getCategory());
		assertEquals("Invalid Right Answer", "Test Right Answer",
				question.getRightAnswer());
		assertEquals("Invalid Answer One", "Test Answer One",
				question.getAnswerOne());
		assertEquals("Invalid Answer Two", "Test Answer Two",
				question.getAnswerTwo());
		assertEquals("Invalid Answer Three", "Test Answer Three",
				question.getAnswerThree());
		assertEquals("Invalid Answer Four", "Test Answer Four",
				question.getAnswerFour());
		assertEquals("Invalid Remove First Answer", 1,
				question.getRemoveFirstAnswer());
		assertEquals("Invalid Remove Second Answer", 2,
				question.getRemoveSecondAnswer());
		assertEquals("Invalid Audience First Response", 3,
				question.getAudienceResponseOne());
		assertEquals("Invalid Audience Second Response", 4,
				question.getAudienceResponseTwo());
		assertEquals("Invalid Audience Third Response", 5,
				question.getAudienceResponseThree());
		assertEquals("Invalid Audience Four Response", 6,
				question.getAudienceResponseFour());
	}

	@Test
	public void testLoadAndAnswersForGeneralKnowdleQuestionsFromFile()
			throws FileNotFoundException {
		ArrayList<Question> questions = questionLoader
				.getQuestions("General Knowledge");
		assertEquals("Invalid number of General Knowledge Questions",
				questions.size(), 3);

		assertEquals("Invalid Question", questions.get(0).getQuestion(),
				"Who is Winston Churchill");
		assertEquals("Invalid Answer", questions.get(0).getRightAnswer(),
				"Famous Politician");

	}

	@Test
	public void testLoadAndAnswersForGeographyQuestionsFromFile()
			throws FileNotFoundException {
		ArrayList<Question> questions = questionLoader
				.getQuestions("Geography");
		assertEquals("Invalid number of Geography Questions", questions.size(),
				3);

		assertEquals("Invalid Question", questions.get(0).getQuestion(),
				"What is the capital of France");
		assertEquals("Invalid Answer", questions.get(0).getRightAnswer(),
				"Paris");
	}
	
	@Test
	public void testLoadAndAnswersForHistoryQuestionsFromFile() throws FileNotFoundException {
		ArrayList<Question> questions = questionLoader
				.getQuestions("History");
		assertEquals("Invalid number of Hostory Questions", questions.size(),
				3);

		assertEquals("Invalid Question", questions.get(0).getQuestion(),
				"Who was Elizabeth the First");
		assertEquals("Invalid Answer", questions.get(0).getRightAnswer(),
				"The queen of England");
		
	}

	public void testLoadAndAnswerForScienceQuestionFromFile() throws FileNotFoundException {
		ArrayList<Question> questions = questionLoader.getQuestions("Science");
		assertEquals("Invalid number of Science Questions", questions.size(), 3);
		
		assertEquals("Invalid Question", questions.get(0).getQuestion(),
				"What is the chemical name for Gold?");
		assertEquals("Invalid Answer", questions.get(0).getRightAnswer(),
				"AU");
	}

	public void testLoadAndAnswerForMathQuestionFromFile() throws FileNotFoundException {
		ArrayList<Question> questions = questionLoader.getQuestions("Math");
		assertEquals("Invalid number of Math Questions", questions.size(), 3);
		
		assertEquals("Invalid Question", questions.get(0).getQuestion(),
				"Whose formula do we use to calculate the velocity of a mass");
		assertEquals("Invalid Answer", questions.get(0).getRightAnswer(),
				"Isaac Newton");
	}
	
	public void testLoadAndAnswerForEnglishQuestionFromFile() throws FileNotFoundException {
		ArrayList<Question> questions = questionLoader.getQuestions("English");
		assertEquals("Invalid number of English Questions", questions.size(), 3);
		
		assertEquals("Invalid Question", questions.get(0).getQuestion(),
				"Who was William Shakespeare");
		assertEquals("Invalid Answer", questions.get(0).getRightAnswer(),
				"An English Playwright");
	}
	
	
}
