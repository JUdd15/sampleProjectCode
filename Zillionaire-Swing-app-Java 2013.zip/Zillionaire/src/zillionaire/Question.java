package zillionaire;

public class Question {
	private String category;
	private String question;
	private String rightAnswer;
	private String answerOne;
	private String answerTwo;
	private String answerThree;
	private String answerFour;
	private int removeFirstAnswer;
	private int removeSecondAnswer;
	private int audienceResponseOne;
	private int audienceResponseTwo;
	private int audienceResponseThree;
	private int audienceResponseFour;

	public Question() {

	}

	public String getCategory() {
		return this.category;
	}

	public void setCategory(String category) {
		this.category = category;
	}
	
	public String getQuestion() {
		return this.question;
	}
	
	public void setQuestion(String question) {
		this.question = question;
	}

	public String getRightAnswer() {
		return this.rightAnswer;
	}

	public void setRightAnswer(String rightAnswer) {
		this.rightAnswer = rightAnswer;
	}

	public String getAnswerOne() {
		return this.answerOne;
	}

	public void setAnswerOne(String answerOne) {
		this.answerOne = answerOne;
	}

	public String getAnswerTwo() {
		return this.answerTwo;
	}

	public void setAnswerTwo(String answerTwo) {
		this.answerTwo = answerTwo;
	}

	public String getAnswerThree() {
		return this.answerThree;
	}

	public void setAnswerThree(String answerThree) {
		this.answerThree = answerThree;
	}

	public String getAnswerFour() {
		return this.answerFour;
	}

	public void setAnswerFour(String answerFour) {
		this.answerFour = answerFour;
	}
	
	public int getRemoveFirstAnswer() {
		return this.removeFirstAnswer;
	}
	
	public void setRemoveFirstAnswer(int removeFirstAnswer) {
		this.removeFirstAnswer = removeFirstAnswer;
	}

	public int getRemoveSecondAnswer() {
		return this.removeSecondAnswer;
	}
	
	public void setRemoveSecondAnswer(int removeSecondAnswer) {
		this.removeSecondAnswer = removeSecondAnswer;
	}
	
	public int getAudienceResponseOne() {
		return this.audienceResponseOne;
	}
	
	public void setAudienceResponseOne(int audienceResponseOne) {
		this.audienceResponseOne = audienceResponseOne;
	}
	
	public int getAudienceResponseTwo() {
		return this.audienceResponseTwo;
	}
	
	public void setAudienceResponseTwo(int audienceResponseTwo) {
		this.audienceResponseTwo = audienceResponseTwo;
	}
	
	public int getAudienceResponseThree() {
		return this.audienceResponseThree;
	}
	
	public void setAudienceResponseThree(int audienceResponseThree) {
		this.audienceResponseThree = audienceResponseThree;
	}
	
	public int getAudienceResponseFour() {
		return this.audienceResponseFour;
	}
	
	public void setAudienceResponseFour(int audienceRespnse) {
		this.audienceResponseFour = audienceRespnse;
	}
}
